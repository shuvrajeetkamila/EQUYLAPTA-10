# EQUYLAPTA 10.1

This folder contains the phase scripts and shared utilities requested in `PROMPT FOR AGENT.txt` from the cloned repository. The run driver is `code/run_all.py`; the named P0–P14 scripts remain directly executable.

## Runtime expected by the work order

The full experiment is designed for Google Colab with a T4 GPU, a mounted Google Drive at `/content/drive`, and the three read-only input archives in `/content/drive/MyDrive/`. It fetches the declared Hugging Face datasets and the Pythia recipient model. Test evaluation is refused unless the analysis plan and selections have been frozen and the validation readiness gate passes.

## Run

In Colab, mount Drive first, install the requirements, then run:

```bash
python code/run_all.py
```

Optional `EQUYLAPTA_*` environment variables can override configuration values. Configuration overrides are tagged as user-supplied in `spec/config_used.json`. The test phase writes its access log before reading the test prompts and refuses a second test evaluation.

## Local preflight

On a CPU-only machine without a mounted Drive, P0 still runs the CPU unit tests and records input hashes and runtime availability. Experiment phases write explicit `NOT_RUN` records rather than filling result files with estimates. The final status remains `INCOMPLETE`; a local archive is produced, but it is not described as a Google Drive delivery.

## Outputs

The run directory is also the package root. `final_results.json` is the computed status source; reports are rendered from it. `manifest.json` and `SHA256SUMS.txt` are produced during final packaging. Heavy checkpoints and activation shards are intended to remain in `DRIVE_ROOT/heavy_artifacts/` unless explicitly configured for the zip.

EQUYLAPTA 10.1 — INCOMPLETE
A: null
F: null
Best negative control: null
Test-set accesses: 0
Recompute in the specified Colab T4 with Drive mounted: python code/run_all.py
final_results.json is the status source; reports are rendered by code.
Archive listing entries counted from zip: 130

Folder file counts from the zip listing:
- artifacts/ — 11
- code/ — 25
- data/ — 6
- inputs_reference/ — 2
- logs/ — 49
- reports/ — 16
- results/ — 11
- spec/ — 3
Top-level files from the zip listing: FINAL_PHENOTYPE_D_VERDICT.txt, README.md, README_FIRST.txt, SHA256SUMS.txt, final_results.json, manifest.json, requirements.txt

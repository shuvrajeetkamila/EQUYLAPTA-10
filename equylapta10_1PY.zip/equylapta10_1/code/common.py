"""Shared configuration, filesystem, hashing, logging, and runtime helpers.

The module is intentionally importable without PyTorch or Hugging Face packages so
that preflight, audits, and statistics can run on a small CPU-only machine.
"""
from __future__ import annotations

import contextlib
import datetime as _dt
import hashlib
import importlib.util
import json
import os
import platform
import random
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Iterable

RUN_ID = "equylapta10_1"
PROJECT_ROOT = Path(os.environ.get("EQUYLAPTA_PROJECT_ROOT", Path(__file__).resolve().parents[1])).expanduser().resolve()
RUN_DIR = Path(os.environ.get("EQUYLAPTA_RUN_DIR", PROJECT_ROOT)).expanduser().resolve()
WORK_DIR = Path(os.environ.get("EQUYLAPTA_WORK_DIR", RUN_DIR.parent)).expanduser().resolve()
DEFAULT_DRIVE_ROOT = Path("/content/drive/MyDrive/EQUYLAPTA10_1")
DRIVE_ROOT = Path(os.environ.get("EQUYLAPTA_DRIVE_ROOT", DEFAULT_DRIVE_ROOT)).expanduser().resolve()
INPUT_NAMES = (
    "equylapta10potato.zip",
    "equylapta10potatoverification.zip",
    "equylapta10reverificaion.zip",
)

DEFAULTS: dict[str, Any] = {
    "RUN_ID": RUN_ID,
    "WORK_DIR": "/content/equylapta10_1_work",
    "DRIVE_ROOT": "/content/drive/MyDrive/EQUYLAPTA10_1",
    "DESIGN": "planted_donor",
    "RECIPIENT_MODEL": "EleutherAI/pythia-70m",
    "DONOR_MODEL": "",
    "TARGET_BEHAVIOR": "math_style_continuation",
    "PHENOTYPE_D_THRESHOLD": 0.90,
    "N_TEST_PROMPTS": 1000,
    "N_VAL_PROMPTS": 500,
    "CONFIDENCE": 0.95,
    "MAX_VAL_ITERATIONS": 5,
    "SEED": 1010,
    "INCLUDE_HEAVY_IN_ZIP": False,
    "MAX_NEW_TOKENS": 48,
    "BATCH_SIZE": 32,
    "CROSSCODER_LATENTS": 8192,
    "CROSSCODER_TRAIN_TOKENS": 5_000_000,
    "CROSSCODER_STEPS": 3000,
}

DIRECTORIES = (
    "spec", "data", "artifacts/donor_build", "artifacts/detector",
    "artifacts/vectors", "results", "reports", "code/tests", "logs",
    "inputs_reference",
)

CSV_HEADERS: dict[str, list[str]] = {
    "per_example_results.csv": [
        "prompt_id", "doc_id", "condition", "replica", "layer", "alpha_rel",
        "alpha_abs", "vector_sha256", "prompt_text", "donor_output", "output",
        "donor_label", "label", "distinct2", "agree", "token_match_frac",
        "identical_to_A", "seed", "batch_size",
    ],
    "reproducibility_rerun.csv": [
        "prompt_id", "condition", "original_output", "rerun_output", "identical", "seed",
    ],
    "spot_check_sample.csv": [
        "prompt_id", "doc_id", "prompt_text", "donor_output", "A_output", "F_output",
        "best_G_output", "donor_label", "A_label", "F_label", "A_agree", "F_agree",
    ],
}


def utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | Path, chunk_size: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha256_json(value: Any) -> str:
    return sha256_bytes(canonical_json_bytes(value))


def write_json(path: str | Path, value: Any, *, indent: int = 2) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=indent, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(tmp, target)


def read_json(path: str | Path, default: Any = None) -> Any:
    target = Path(path)
    if not target.exists():
        return default
    with target.open(encoding="utf-8") as handle:
        return json.load(handle)


def ensure_tree(root: str | Path = RUN_DIR) -> None:
    base = Path(root)
    base.mkdir(parents=True, exist_ok=True)
    for rel in DIRECTORIES:
        (base / rel).mkdir(parents=True, exist_ok=True)


def environment_override(name: str, default: Any, cast=str) -> dict[str, Any]:
    raw = os.environ.get("EQUYLAPTA_" + name)
    if raw is None:
        return {"value": default, "source": "default"}
    if cast is bool:
        val = raw.strip().lower() in {"1", "true", "yes", "on"}
    else:
        val = cast(raw)
    return {"value": val, "source": "user"}


def config_used() -> dict[str, Any]:
    casts = {
        "PHENOTYPE_D_THRESHOLD": float, "N_TEST_PROMPTS": int, "N_VAL_PROMPTS": int,
        "CONFIDENCE": float, "MAX_VAL_ITERATIONS": int, "SEED": int,
        "INCLUDE_HEAVY_IN_ZIP": bool, "MAX_NEW_TOKENS": int, "BATCH_SIZE": int,
        "CROSSCODER_LATENTS": int, "CROSSCODER_TRAIN_TOKENS": int,
        "CROSSCODER_STEPS": int,
    }
    out = {k: environment_override(k, v, casts.get(k, str)) for k, v in DEFAULTS.items()}
    # Runtime paths are reported separately from the Colab defaults so local testing
    # cannot be mistaken for a Drive-backed experiment.
    out["RUNTIME_PATHS"] = {
        "project_root": str(PROJECT_ROOT), "run_dir": str(RUN_DIR),
        "work_dir": str(WORK_DIR), "drive_root": str(DRIVE_ROOT),
        "source": "local_execution_context",
    }
    out["INPUT_ZIPS"] = list(INPUT_NAMES)
    return out


def set_seeds(seed: int | None = None) -> None:
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    import numpy as np
    actual = int(seed if seed is not None else DEFAULTS["SEED"])
    random.seed(actual)
    np.random.seed(actual)
    try:
        import torch
        torch.manual_seed(actual)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(actual)
        torch.use_deterministic_algorithms(True, warn_only=True)
        if hasattr(torch.backends, "cudnn"):
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


def find_input_zip(name: str) -> Path | None:
    explicit = os.environ.get("EQUYLAPTA_INPUT_DIR")
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser() / name)
    candidates.extend([
        Path("/content/drive/MyDrive") / name,
        PROJECT_ROOT.parent / name,
        PROJECT_ROOT.parent.parent / "EQUYLAPTA-10" / name,
        Path.cwd() / name,
    ])
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    return None


def input_hash_inventory() -> dict[str, Any]:
    records = []
    for name in INPUT_NAMES:
        path = find_input_zip(name)
        if path is None:
            records.append({"name": name, "status": "NOT_FOUND", "path": None, "bytes": None, "sha256": None})
        else:
            records.append({"name": name, "status": "FOUND", "path": str(path),
                            "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    return {"created_utc": utc_now(), "read_only": True, "used_as_10_1_evidence": False, "files": records}


def module_availability(names: Iterable[str]) -> dict[str, bool]:
    return {name: importlib.util.find_spec(name) is not None for name in names}


def runtime_probe() -> dict[str, Any]:
    packages = module_availability(("numpy", "scipy", "sklearn", "torch", "transformers", "datasets", "safetensors", "accelerate", "pandas"))
    cuda = False
    torch_version = None
    try:
        import torch
        cuda = bool(torch.cuda.is_available())
        torch_version = str(torch.__version__)
    except Exception:
        pass
    nvidia = shutil.which("nvidia-smi")
    nvidia_output = None
    if nvidia:
        try:
            nvidia_output = subprocess.run([nvidia, "-L"], capture_output=True, text=True, timeout=10, check=False).stdout.strip()
        except Exception as exc:
            nvidia_output = f"probe_error: {type(exc).__name__}: {exc}"
    drive_parent = DRIVE_ROOT.parent
    drive_mounted = drive_parent.exists() and drive_parent.is_dir()
    return {
        "timestamp_utc": utc_now(), "python": sys.version.split()[0],
        "platform": platform.platform(), "packages": packages,
        "torch_version": torch_version, "cuda_available": cuda,
        "nvidia_smi_path": nvidia, "nvidia_smi_devices": nvidia_output,
        "drive_root": str(DRIVE_ROOT), "drive_mount_visible": drive_mounted,
    }


def runtime_blockers(probe: dict[str, Any] | None = None) -> list[str]:
    p = probe or runtime_probe()
    blockers = []
    for name in ("numpy", "scipy", "sklearn", "torch", "transformers", "datasets", "safetensors", "accelerate"):
        if not p["packages"].get(name, False):
            blockers.append(f"required package unavailable: {name}")
    if not p.get("cuda_available", False):
        blockers.append("CUDA GPU unavailable; the specified T4 experiment was not run")
    if not p.get("drive_mount_visible", False):
        blockers.append("Google Drive mount unavailable; R12 checkpoints and R13 mirroring cannot be performed")
    return blockers


def file_tree_stats(root: str | Path) -> dict[str, int]:
    base = Path(root)
    count = 0
    size = 0
    if base.exists():
        for path in base.rglob("*"):
            if path.is_file():
                count += 1
                size += path.stat().st_size
    return {"files": count, "bytes": size}


def mirror_to_drive(phase: str) -> dict[str, Any]:
    """Mirror the entire run folder when the requested Drive mount is available."""
    drive_mounted = DRIVE_ROOT.parent.exists() and DRIVE_ROOT.parent.is_dir()
    if not drive_mounted:
        return {"status": "NOT_RUN", "reason": "Google Drive mount is not available", "files": None, "bytes": None}
    destination = DRIVE_ROOT / "_live_mirror" / RUN_ID
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(RUN_DIR, destination, dirs_exist_ok=True)
    stats = file_tree_stats(destination)
    return {"status": "PASS", "destination": str(destination), **stats, "phase": phase}


def checkpoint_to_drive(phase: str) -> dict[str, Any]:
    if not (DRIVE_ROOT.parent.exists() and DRIVE_ROOT.parent.is_dir()):
        return {"status": "NOT_RUN", "reason": "Google Drive mount is not available"}
    destination = DRIVE_ROOT / "_checkpoints" / phase
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(RUN_DIR, destination)
    digest = tree_sha256(destination)
    sidecar = destination.parent / (phase + ".sha256")
    sidecar.write_text(f"{digest}  {phase}/\n", encoding="utf-8")
    return {"status": "PASS", "path": str(destination), "sha256": digest, "bytes": file_tree_stats(destination)["bytes"]}


def tree_sha256(root: str | Path) -> str:
    base = Path(root)
    h = hashlib.sha256()
    if not base.exists():
        return h.hexdigest()
    for path in sorted(p for p in base.rglob("*") if p.is_file()):
        rel = path.relative_to(base).as_posix().encode("utf-8")
        h.update(rel + b"\0")
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b""):
                h.update(chunk)
    return h.hexdigest()


def append_jsonl(path: str | Path, obj: dict[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(obj, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n")


def write_not_run_csv(path: str | Path, filename: str) -> None:
    import csv
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = CSV_HEADERS.get(filename, ["status", "reason"])
    if not target.exists() or target.stat().st_size == 0:
        with target.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(fields)


def status_of_phase(phase_number: int) -> str | None:
    state = read_json(RUN_DIR / "logs" / "phase_state.json", default={}) or {}
    return state.get(f"P{phase_number}", {}).get("status")


def phase_ready_through(phase_number: int) -> bool:
    state = read_json(RUN_DIR / "logs" / "phase_state.json", default={}) or {}
    for i in range(1, phase_number):
        entry = state.get(f"P{i}")
        if not entry or entry.get("status") not in {"PASS", "NOT_APPLICABLE"}:
            return False
    return True


def mark_phase(phase: str, status: str, details: dict[str, Any] | None = None, *, checkpoint: bool = False) -> dict[str, Any]:
    """Record phase status, checkpoint/mirror outcomes, and measured run-tree size."""
    ensure_tree()
    state_path = RUN_DIR / "logs" / "phase_state.json"
    state = read_json(state_path, default={}) or {}
    record: dict[str, Any] = {
        "status": status, "completed_utc": utc_now(),
        "details": details or {},
    }
    if checkpoint:
        record["checkpoint"] = checkpoint_to_drive(phase)
    record["mirror"] = mirror_to_drive(phase)
    state[phase] = record
    write_json(state_path, state)
    stats = file_tree_stats(RUN_DIR)
    line = f"{utc_now()} {phase} status={status} files={stats['files']} bytes={stats['bytes']} mirror={record['mirror']['status']}"
    with (RUN_DIR / "logs" / "execution_log.txt").open("a", encoding="utf-8") as handle:
        handle.write(line + "\n")
    print(line)
    return record


@contextlib.contextmanager
def temporary_env(values: dict[str, str]):
    old = {key: os.environ.get(key) for key in values}
    try:
        os.environ.update(values)
        yield
    finally:
        for key, value in old.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

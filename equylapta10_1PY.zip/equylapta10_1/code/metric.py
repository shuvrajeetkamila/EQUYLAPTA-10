"""Frozen text detector and Phenotype D text metrics."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, confusion_matrix, precision_recall_fscore_support
from sklearn.pipeline import Pipeline

from reference_utils import agree, distinct2, sha256_file


class MathStyleDetector:
    """A deterministic TF-IDF/logistic classifier trained only on labelled train text."""

    def __init__(self, seed: int = 1010, c_value: float = 4.0):
        self.seed = int(seed)
        self.c_value = float(c_value)
        self.pipeline = Pipeline([
            ("tfidf", TfidfVectorizer(
                lowercase=True, strip_accents="unicode", ngram_range=(1, 2),
                min_df=2, max_features=100_000, sublinear_tf=True,
                token_pattern=r"(?u)\b\w+\b|[^\w\s]",
            )),
            ("classifier", LogisticRegression(
                C=self.c_value, class_weight="balanced", max_iter=600,
                random_state=self.seed, solver="liblinear", tol=1e-5,
            )),
        ])
        self.fitted = False

    def fit(self, texts: Sequence[str], labels: Sequence[int]) -> "MathStyleDetector":
        clean = [str(text) for text in texts]
        y = np.asarray(labels, dtype=int)
        if len(clean) != len(y) or len(clean) < 4:
            raise ValueError("detector training needs at least four aligned examples")
        if set(np.unique(y)) != {0, 1}:
            raise ValueError("detector training needs both source labels 0 and 1")
        self.pipeline.fit(clean, y)
        self.fitted = True
        return self

    def predict(self, texts: str | Sequence[str]) -> int | list[int]:
        if not self.fitted:
            raise RuntimeError("detector must be fit or loaded before prediction")
        single = isinstance(texts, str)
        values = [texts] if single else list(texts)
        predictions = self.pipeline.predict([str(text) for text in values]).astype(int).tolist()
        return predictions[0] if single else predictions

    def predict_proba(self, texts: str | Sequence[str]) -> list[float]:
        if not self.fitted:
            raise RuntimeError("detector must be fit or loaded before prediction")
        values = [texts] if isinstance(texts, str) else list(texts)
        probabilities = self.pipeline.predict_proba([str(text) for text in values])[:, 1]
        return probabilities.astype(float).tolist()

    def save(self, path: str | Path) -> str:
        if not self.fitted:
            raise RuntimeError("cannot save an unfitted detector")
        import joblib
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"seed": self.seed, "c_value": self.c_value, "pipeline": self.pipeline}, target, compress=3)
        return sha256_file(target)

    @classmethod
    def load(cls, path: str | Path) -> "MathStyleDetector":
        import joblib
        record = joblib.load(path)
        detector = cls(seed=record["seed"], c_value=record["c_value"])
        detector.pipeline = record["pipeline"]
        detector.fitted = True
        return detector


def detector_metrics(detector: MathStyleDetector, texts: Sequence[str], labels: Sequence[int]) -> dict[str, Any]:
    y_true = np.asarray(labels, dtype=int)
    y_pred = np.asarray(detector.predict(list(texts)), dtype=int)
    if y_true.shape != y_pred.shape or y_true.size == 0:
        raise ValueError("validation inputs must be non-empty and aligned")
    matrix = confusion_matrix(y_true, y_pred, labels=[0, 1])
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=[0, 1], zero_division=0,
    )
    return {
        "n": int(y_true.size),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "confusion_matrix_labels_0_1": matrix.astype(int).tolist(),
        "per_class": {
            str(label): {"precision": float(precision[i]), "recall": float(recall[i]),
                         "f1": float(f1[i]), "support": int(support[i])}
            for i, label in enumerate((0, 1))
        },
        "predictions": y_pred.astype(int).tolist(),
    }


def score_continuation(detector: MathStyleDetector, text: str, min_distinct2: float = 0.5) -> dict[str, Any]:
    label = int(detector.predict(text))
    d2 = float(distinct2(text))
    return {"label": label, "distinct2": d2, "agree": int(agree(label, d2, min_distinct2))}


def make_detector_record(
    detector: MathStyleDetector,
    validation: dict[str, Any],
    path: str | Path,
    source_counts: dict[str, int],
) -> dict[str, Any]:
    target = Path(path)
    return {
        "definition": "TF-IDF word/punctuation unigram-bigram vectorizer plus balanced logistic regression; fit on train source labels only",
        "target_behavior": "math_style_continuation",
        "seed": detector.seed,
        "c_value": detector.c_value,
        "source_counts_train": source_counts,
        "validation": {k: v for k, v in validation.items() if k != "predictions"},
        "model_file": target.name,
        "model_sha256": sha256_file(target),
        "positive_label": 1,
        "negative_label": 0,
        "agreement_rule": "label == 1 and distinct2 >= 0.5",
    }

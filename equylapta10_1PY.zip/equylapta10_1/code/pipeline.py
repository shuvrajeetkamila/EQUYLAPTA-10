"""Phase coordinator, statistics, reports, integrity checks, and packaging."""
from __future__ import annotations

import contextlib
import csv
import datetime as dt
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
import traceback
import unittest
import zipfile
from pathlib import Path
from typing import Any

from common import (
    DEFAULTS, DRIVE_ROOT, INPUT_NAMES, PROJECT_ROOT, RUN_DIR, RUN_ID, WORK_DIR,
    config_used, ensure_tree, file_tree_stats, input_hash_inventory, mark_phase,
    module_availability, read_json, runtime_blockers, runtime_probe, set_seeds,
    sha256_file, sha256_json, utc_now, write_json, write_not_run_csv,
)
from reference_utils import (
    bootstrap_diff_ci, clopper_pearson_ci, discordant_counts, mcnemar_exact,
    min_successes_for_lower_bound, sha256_bytes, sha256_file as ref_sha256_file,
    wilson_ci, wilson_ci_crosscheck,
)

CODE_DIR = RUN_DIR / "code"
REPORT_FILES = [
    "00_EXECUTIVE_SUMMARY.txt", "01_spec_and_config_report.txt",
    "02_data_splits_leakage_report.txt", "03_donor_detector_report.txt",
    "04_locate_training_report.txt", "05_calibration_val_report.txt",
    "06_surgery_integrity_report.txt", "07_test_results_report.txt",
    "08_controls_report.txt", "09_collateral_damage_report.txt",
    "10_statistics_audit_report.txt", "11_reproducibility_report.txt",
    "12_integrity_consistency_report.txt", "13_limitations_next_steps.txt",
    "14_human_spot_check_guide.txt",
]
GATE_THRESHOLDS = {
    "G1": lambda cfg: int(cfg["N_TEST_PROMPTS"]["value"]),
    "G2": lambda cfg: {"different_tensors": 1, "donor_exhibit_rate": 0.95},
    "G3": lambda cfg: 0.50,
    "G4": lambda cfg: float(cfg["PHENOTYPE_D_THRESHOLD"]["value"]),
    "G5": lambda cfg: {"p_less_than": 0.001, "direction": "F better than A"},
    "G6": lambda cfg: {"agreement_gap": 0.30, "p_less_than": 0.001, "H_identical_fraction": 1.0},
    "G7": lambda cfg: {"ppl_ratio_max": 1.25, "diversity_ratio_min": 0.8},
    "G8": lambda cfg: {"only_declared_edit_changes": True, "hook_fold_max_abs_diff": 0.001},
    "G9": lambda cfg: {"final_loss_ratio_max": 0.5, "val_fvu_max": 0.35, "random_gap_min": 0.30},
    "G10": lambda cfg: {"identical_fraction_min": 0.99, "prompts": 200},
    "G11": lambda cfg: {"violations_max": 0},
}
PHASE_SCRIPT_NAMES = [
    "00_setup_and_plan_freeze.py", "01_build_splits.py", "02_build_detector.py",
    "03_build_donor.py", "04_layer_sweep.py", "05_train_crosscoder.py",
    "06_select_latents_build_vectors.py", "07_val_calibration_and_readiness.py",
    "08_freeze_selections_and_surgery.py", "09_test_evaluation_ONCE.py",
    "10_statistics_and_verdict.py", "11_reproducibility_rerun.py",
    "12_render_reports.py", "13_consistency_and_integrity_check.py",
    "14_package_and_drive_copy.py",
]


def p(rel: str) -> Path:
    return RUN_DIR / rel


def _write_text(path: str | Path, text: str) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text.rstrip() + "\n", encoding="utf-8")


def _read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    target = Path(path)
    if not target.exists():
        return []
    rows = []
    with target.open(encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def _write_csv(path: str | Path, fieldnames: list[str], rows: list[dict[str, Any]]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _phase_test_runner() -> dict[str, Any]:
    sys.path.insert(0, str(CODE_DIR))
    test_path = CODE_DIR / "tests" / "test_reference_utils.py"
    spec = importlib.util.spec_from_file_location("equylapta_test_suite", test_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load test module at {test_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    tests = [(name, getattr(module, name)) for name in dir(module) if name.startswith("test_") and callable(getattr(module, name))]
    passed, skipped, failed = [], [], []
    lines = [f"Unit-test execution started: {utc_now()}", f"Discovered tests: {len(tests)}"]
    for name, function in tests:
        try:
            function()
            passed.append(name)
            lines.append(f"PASS {name}")
        except unittest.SkipTest as exc:
            skipped.append({"test": name, "reason": str(exc)})
            lines.append(f"SKIP {name}: {exc}")
        except Exception:
            failed.append({"test": name, "traceback": traceback.format_exc()})
            lines.append(f"FAIL {name}\n{traceback.format_exc()}")
    result = {
        "created_utc": utc_now(), "discovered": len(tests),
        "passed": len(passed), "skipped": skipped, "failed": failed,
        "status": "PASS" if not failed else "FAIL",
        "test_names_passed": passed,
    }
    lines.extend([f"Passed: {len(passed)}", f"Skipped: {len(skipped)}", f"Failed: {len(failed)}", f"Suite status: {result['status']}"])
    _write_text(p("logs/unit_tests.txt"), "\n".join(lines))
    write_json(p("logs/unit_tests.json"), result)
    return result


def _analysis_spec(cfg: dict[str, Any]) -> dict[str, Any]:
    return {
        "run_id": RUN_ID,
        "phenotype": {
            "name": "Phenotype D",
            "target_behavior": cfg["TARGET_BEHAVIOR"]["value"],
            "test_unit": "one neutral, document-initial 32-64-token general-text prefix per held-out document; detector label 0",
            "condition_output": "greedy decoding; 48 new tokens; fp32",
            "donor_filter": "discard all candidates whose donor continuation detector label is 0; preserve first N from a predeclared 2N candidate pool",
            "agreement": "detector label is 1 and distinct-2 is at least 0.5",
            "analysis_unit": "prompt/document",
        },
        "design": {
            "type": cfg["DESIGN"]["value"],
            "recipient_model": cfg["RECIPIENT_MODEL"]["value"],
            "donor_model": cfg["DONOR_MODEL"]["value"],
            "recipient_training_prohibited": True,
            "donor_is_test_fixture_only": True,
        },
        "sample_sizes": {
            "n_test_prompts": cfg["N_TEST_PROMPTS"]["value"],
            "n_val_prompts": cfg["N_VAL_PROMPTS"]["value"],
            "test_candidates_multiplier": 2,
            "perplexity_documents": 500,
        },
        "gates": {gate: {"threshold": rule(cfg)} for gate, rule in GATE_THRESHOLDS.items()},
        "conditions": {
            "A": "unedited recipient", "B": "v_F at half selected alpha", "C": "v_F at twice selected alpha",
            "D": "recipient-only latent subtraction", "E": "donor-recipient difference projected to selected latent span",
            "F": "primary located donor vector folded into recipient bias", "G": "20 seeded random unit vectors",
            "H": "zero-vector hook", "I": "20 norm-matched non-selected latent vectors",
            "J": "same direction at every non-selected layer", "K": "optional legacy vector when available",
            "L": "mean donor-recipient difference reference",
        },
        "alpha_grid_relative_residual_norm": [0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0],
        "latent_k_grid": [1, 4, 16],
        "statistics": {
            "confidence": cfg["CONFIDENCE"]["value"], "rate_interval": "Wilson score",
            "reported_exact_interval": "Clopper-Pearson", "paired_test": "exact two-sided McNemar",
            "paired_bootstrap_resamples": 10000, "bootstrap_seed": cfg["SEED"]["value"],
            "second_implementation_tolerance": 1e-9,
        },
        "randomness": {"seed": cfg["SEED"]["value"], "deterministic_algorithms": True},
        "frozen_utc": utc_now(),
    }


def _phase_00() -> tuple[str, dict[str, Any]]:
    ensure_tree()
    cfg = config_used()
    write_json(p("spec/config_used.json"), cfg)
    set_seeds(int(cfg["SEED"]["value"]))
    probe = runtime_probe()
    write_json(p("logs/runtime_probe.json"), probe)
    write_json(p("inputs_reference/v10_input_hashes.json"), input_hash_inventory())
    defects = {
        "source": "EQUYLAPTA10_1_work_order_COMPLETE.md section 4",
        "used_as_current_run_evidence": False,
        "items": [
            "Prior headline rate and interval were not dynamically computed from per-example records.",
            "The agreement metric had not been operationally defined.",
            "The earlier sample contained too few prompts for the stated precision.",
            "The earlier corpus split was not document-level and was too small for activation statistics.",
            "The prior sparse representation was not shown to have trained healthily.",
            "Control vectors and scale settings were not independently demonstrated.",
            "Steering magnitude and no-op behavior were not adequately checked.",
            "Donor and recipient weights were not shown to differ.",
            "A prior interval and sample-size audit did not reproduce its labels.",
            "Earlier verification scripts did not contain executed analysis logic.",
            "Earlier reports and machine-readable status fields were inconsistent.",
            "Some previously referenced reports were absent from the delivered archive.",
            "Earlier phase reports did not contain phase-specific evidence.",
        ],
    }
    write_json(p("inputs_reference/v10_defect_register.json"), defects)
    spec_doc = _analysis_spec(cfg)
    spec_path = p("spec/PHENOTYPE_D_SPEC.json")
    write_json(spec_path, spec_doc)
    digest = sha256_file(spec_path)
    _write_text(p("spec/PHENOTYPE_D_SPEC.sha256"), f"{digest}  PHENOTYPE_D_SPEC.json")
    _write_text(p("logs/nvidia_smi.txt"), probe.get("nvidia_smi_devices") or "nvidia-smi unavailable in this runtime")
    try:
        frozen = subprocess.run([sys.executable, "-m", "pip", "freeze"], capture_output=True, text=True, timeout=120, check=False)
        pip_text = frozen.stdout if frozen.stdout else frozen.stderr
    except Exception as exc:
        pip_text = f"pip freeze unavailable: {type(exc).__name__}: {exc}"
    _write_text(p("logs/pip_freeze.txt"), pip_text or "No installed distributions were reported.")
    tests = _phase_test_runner()
    blockers = runtime_blockers(probe)
    config_errors = []
    if int(cfg["N_TEST_PROMPTS"]["value"]) < 500:
        config_errors.append("N_TEST_PROMPTS is below the frozen minimum of 500")
    if int(cfg["N_VAL_PROMPTS"]["value"]) < 1:
        config_errors.append("N_VAL_PROMPTS must be positive")
    if not 0.0 < float(cfg["CONFIDENCE"]["value"]) < 1.0:
        config_errors.append("CONFIDENCE must be between zero and one")
    if cfg["DESIGN"]["value"] == "user_pair" and not cfg["DONOR_MODEL"]["value"]:
        config_errors.append("DONOR_MODEL is required when DESIGN=user_pair")
    if cfg["DESIGN"]["value"] not in {"planted_donor", "user_pair"}:
        config_errors.append("DESIGN must be planted_donor or user_pair")
    details = {
        "spec_sha256": digest, "unit_tests": tests,
        "runtime_probe": probe, "experiment_blockers": blockers,
        "config_errors": config_errors,
        "input_hashes": read_json(p("inputs_reference/v10_input_hashes.json")),
    }
    if tests["status"] != "PASS" or config_errors:
        return "FAIL", details
    return "PASS", details


def _not_run_artifacts(phase: int, reason: str) -> None:
    """Write explicit, machine-readable NOT_RUN records without inventing measurements."""
    record = {"status": "NOT_RUN", "phase": f"P{phase}", "reason": reason, "created_utc": utc_now()}
    write_json(p(f"logs/phase_{phase:02d}_status.json"), record)
    if phase == 1:
        for name in ("train_prompts.jsonl", "val_prompts.jsonl", "test_prompts.jsonl", "perplexity_docs.jsonl"):
            target = p("data/" + name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("", encoding="utf-8")
        write_json(p("data/split_manifest.json"), record)
        write_json(p("data/leakage_check.json"), {**record, "exact_overlap_count": None, "near_duplicate_overlap_count": None})
    elif phase == 2:
        write_json(p("artifacts/detector/detector_definition.json"), record)
        write_json(p("artifacts/detector/detector_validation.json"), record)
    elif phase == 3:
        write_json(p("artifacts/donor_build/donor_build_report.json"), record)
    elif phase == 4:
        _write_csv(p("results/val_alpha_layer_sweep.csv"), ["stage", "layer", "k", "alpha_rel", "alpha_abs", "n", "k_success", "agreement", "wilson_low", "wilson_high", "ppl_ratio", "ppl_allowed", "median_donor_nll_A", "median_donor_nll_F", "distinct2_F", "distinct2_donor", "collateral_pass"], [])
    elif phase == 5:
        write_json(p("artifacts/crosscoder_config.json"), record)
        _write_csv(p("artifacts/training_curves.csv"), ["step", "loss", "mse_recipient", "mse_donor", "l0_recipient", "l0_donor", "fvu_recipient", "fvu_donor", "dead_fraction"], [])
    elif phase == 6:
        write_json(p("artifacts/selected_latents.json"), record)
        write_json(p("artifacts/vectors/vectors_index.json"), {**record, "vectors": []})
    elif phase == 7:
        _write_csv(p("results/val_iteration_log.csv"), ["iteration", "layer", "k", "alpha_rel", "agreement", "random_best", "readiness", "reason"], [])
        write_json(p("results/val_readiness.json"), record)
    elif phase == 8:
        write_json(p("artifacts/weight_diff_report.json"), record)
        write_json(p("artifacts/external_artifacts.json"), record)
        write_json(p("artifacts/surgery_integrity.json"), record)
    elif phase == 9:
        write_not_run_csv(p("results/per_example_results.csv"), "per_example_results.csv")
        write_json(p("logs/test_set_access_log.json"), {**record, "access_count": 0})
        write_json(p("results/collateral_metrics.json"), record)
        write_json(p("results/secondary_metrics.json"), record)
    elif phase == 11:
        write_not_run_csv(p("results/reproducibility_rerun.csv"), "reproducibility_rerun.csv")
    elif phase == 12:
        write_not_run_csv(p("results/spot_check_sample.csv"), "spot_check_sample.csv")


def _gate(status: str, value: Any, threshold: Any, evidence: str, reason: str | None = None) -> dict[str, Any]:
    result = {"status": status, "value": value, "threshold": threshold, "evidence_file": evidence}
    if reason:
        result["reason"] = reason
    return result


def _load_rows(path: str | Path) -> list[dict[str, str]]:
    target = Path(path)
    if not target.exists():
        return []
    with target.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _as_bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def _per_prompt(rows: list[dict[str, str]], condition: str, replica: str | None = None) -> dict[str, dict[str, Any]]:
    selected = [row for row in rows if row.get("condition") == condition and (replica is None or row.get("replica") == str(replica))]
    return {row["prompt_id"]: row for row in selected}


def _rate(rows: list[dict[str, str]]) -> tuple[int, int, float | None]:
    unique = {}
    for row in rows:
        unique[row["prompt_id"]] = int(float(row.get("agree", 0)))
    n = len(unique)
    k = sum(unique.values())
    return k, n, (k / n if n else None)


def _condition_summaries(rows: list[dict[str, str]], confidence: float) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    keys = sorted({(row.get("condition", ""), row.get("replica", "0")) for row in rows})
    output, paired = [], {}
    baseline = _per_prompt(rows, "A", "0")
    for condition, replica in keys:
        current = _per_prompt(rows, condition, replica)
        prompt_ids = sorted(current)
        outcomes = [int(float(current[prompt]["agree"])) for prompt in prompt_ids]
        n = len(outcomes)
        k = sum(outcomes)
        if n:
            wilson = wilson_ci(k, n, confidence)
            exact = clopper_pearson_ci(k, n, confidence)
        else:
            wilson = exact = (None, None)
        no_op_ids = sorted(set(current) & set(baseline))
        no_op_rate = (sum(current[key].get("output") == baseline[key].get("output") for key in no_op_ids) / len(no_op_ids)) if no_op_ids else None
        record: dict[str, Any] = {
            "condition": condition, "replica": replica, "n": n, "k": k,
            "rate": (k / n if n else None), "wilson_low": wilson[0], "wilson_high": wilson[1],
            "clopper_pearson_low": exact[0], "clopper_pearson_high": exact[1],
            "no_op_rate_vs_A": no_op_rate,
        }
        common = sorted(set(current) & set(baseline))
        if condition != "A" and common:
            x = [int(float(current[key]["agree"])) for key in common]
            y = [int(float(baseline[key]["agree"])) for key in common]
            b, c = discordant_counts(x, y)
            record.update({"mcnemar_b_vs_A": b, "mcnemar_c_vs_A": c, "mcnemar_p_vs_A": mcnemar_exact(b, c)})
            paired[f"{condition}:{replica}"] = {"n_paired": len(common), "b": b, "c": c, "p_value": mcnemar_exact(b, c)}
        else:
            record.update({"mcnemar_b_vs_A": None, "mcnemar_c_vs_A": None, "mcnemar_p_vs_A": None})
        output.append(record)
    return output, paired


def _phase_10_statistics() -> tuple[str, dict[str, Any]]:
    cfg = read_json(p("spec/config_used.json"), config_used())
    confidence = float(cfg["CONFIDENCE"]["value"])
    rows = _load_rows(p("results/per_example_results.csv"))
    val = read_json(p("results/val_readiness.json"), {}) or {}
    data_access = read_json(p("logs/test_set_access_log.json"), {}) or {}
    donor_report = read_json(p("artifacts/donor_build/donor_build_report.json"), {}) or {}
    surgery = read_json(p("artifacts/surgery_integrity.json"), {}) or {}
    crosscoder = read_json(p("artifacts/crosscoder_health.json"), {}) or {}
    collateral = read_json(p("results/collateral_metrics.json"), {}) or {}
    summaries, paired_tests = _condition_summaries(rows, confidence)
    if rows:
        baseline_rows = _per_prompt(rows, "A", "0")
        primary_rows = _per_prompt(rows, "F", "0")
        paired_ids = sorted(set(baseline_rows) & set(primary_rows))
        if paired_ids:
            f_values = [int(float(primary_rows[key]["agree"])) for key in paired_ids]
            a_values = [int(float(baseline_rows[key]["agree"])) for key in paired_ids]
            paired_tests["F_vs_A_bootstrap_difference"] = {
                "n_paired": len(paired_ids),
                "difference_ci": bootstrap_diff_ci(f_values, a_values, n_boot=10000, conf=confidence,
                                                   seed=int(cfg["SEED"]["value"])),
                "resamples": 10000, "seed": int(cfg["SEED"]["value"]),
            }
    f_rate_for_gap = next((item["rate"] for item in summaries if item["condition"] == "F" and item["replica"] == "0"), None)
    for item in summaries:
        item["gap_to_F"] = (f_rate_for_gap - item["rate"]) if f_rate_for_gap is not None and item["rate"] is not None else None
    _write_csv(p("results/condition_summary.csv"), [
        "condition", "replica", "n", "k", "rate", "wilson_low", "wilson_high",
        "clopper_pearson_low", "clopper_pearson_high", "no_op_rate_vs_A", "gap_to_F",
        "mcnemar_b_vs_A", "mcnemar_c_vs_A", "mcnemar_p_vs_A",
    ], summaries)
    write_json(p("results/paired_tests.json"), paired_tests)
    full = bool(rows) and any(row.get("condition") == "F" for row in rows)
    A_rows = _per_prompt(rows, "A", "0")
    F_rows = _per_prompt(rows, "F", "0")
    common = sorted(set(A_rows) & set(F_rows))
    kA, nA, rateA = _rate(list(A_rows.values())) if A_rows else (0, 0, None)
    kF, nF, rateF = _rate(list(F_rows.values())) if F_rows else (0, 0, None)
    n_docs = len({row.get("doc_id") for row in F_rows.values() if row.get("doc_id")})
    donor_diff = donor_report.get("changed_tensors", [])
    donor_exhibit = donor_report.get("candidate_exhibit_rate")
    gates: dict[str, dict[str, Any]] = {}
    if full:
        gates["G1"] = _gate("PASS" if n_docs >= int(cfg["N_TEST_PROMPTS"]["value"]) else "FAIL", n_docs, int(cfg["N_TEST_PROMPTS"]["value"]), "results/per_example_results.csv")
        g2_ok = bool(donor_diff) and donor_exhibit is not None and float(donor_exhibit) >= 0.95
        gates["G2"] = _gate("PASS" if g2_ok else "FAIL", {"changed_tensors": donor_diff, "candidate_exhibit_rate": donor_exhibit}, GATE_THRESHOLDS["G2"](cfg), "artifacts/donor_build/donor_build_report.json")
        gates["G3"] = _gate("PASS" if rateA is not None and rateA <= 0.50 else "FAIL", {"k": kA, "n": nA, "rate": rateA}, 0.50, "results/condition_summary.csv")
        f_wilson = wilson_ci(kF, nF, confidence) if nF else (None, None)
        primary_threshold = float(cfg["PHENOTYPE_D_THRESHOLD"]["value"])
        gates["G4"] = _gate("PASS" if f_wilson[0] is not None and f_wilson[0] >= primary_threshold else "FAIL", {"k": kF, "n": nF, "rate": rateF, "wilson": f_wilson}, primary_threshold, "results/condition_summary.csv")
        b, c = discordant_counts([int(float(F_rows[key]["agree"])) for key in common], [int(float(A_rows[key]["agree"])) for key in common]) if common else (0, 0)
        pvalue = mcnemar_exact(b, c)
        gates["G5"] = _gate("PASS" if common and rateF is not None and rateA is not None and rateF > rateA and pvalue < 0.001 else "FAIL", {"b": b, "c": c, "p_value": pvalue, "F_rate": rateF, "A_rate": rateA}, {"p_less_than": 0.001, "direction": "F better than A"}, "results/paired_tests.json")
        controls = {}
        control_ids = ["D", "G", "H", "I", "J"]
        vector_info = read_json(p("artifacts/vectors/vectors_index.json"), {}) or {}
        j_info = read_json(p("results/val_layer_specificity.json"), {}) or {}
        d_vectors = [item for item in vector_info.get("vectors", []) if str(item.get("condition", "")).startswith("D")]
        for code in control_ids:
            replicas = sorted({row.get("replica", "0") for row in rows if row.get("condition") == code})
            if code == "D" and vector_info.get("recipient_only_latent_count", 4) < 4:
                controls[code] = {"status": "NOT_APPLICABLE", "reason": "fewer than four recipient-only latents", "gap": None, "p_value": None}
                continue
            if code == "J" and j_info.get("layer_agnostic") is True:
                controls[code] = {"status": "NOT_APPLICABLE", "reason": "layer agnostic on the predeclared validation sweep", "gap": None, "p_value": None}
                continue
            best = None
            for replica in replicas:
                control_rows = _per_prompt(rows, code, replica)
                ids = sorted(set(control_rows) & set(F_rows))
                if not ids:
                    continue
                control_k = sum(int(float(control_rows[key]["agree"])) for key in ids)
                control_rate = control_k / len(ids)
                f_values = [int(float(F_rows[key]["agree"])) for key in ids]
                c_values = [int(float(control_rows[key]["agree"])) for key in ids]
                db, dc = discordant_counts(f_values, c_values)
                candidate = {"replica": replica, "k": control_k, "rate": control_rate, "n": len(ids), "gap": float(rateF - control_rate), "b": db, "c": dc, "p_value": mcnemar_exact(db, dc)}
                if best is None or candidate["rate"] > best["rate"]:
                    best = candidate
            if best is None:
                controls[code] = {"status": "NOT_RUN", "reason": "condition rows unavailable", "gap": None, "p_value": None}
            else:
                h_ok = code != "H" or best["rate"] == rateA and all(
                    _as_bool(row.get("identical_to_A", False)) for row in rows if row.get("condition") == "H"
                )
                passed = best["gap"] >= 0.30 and best["p_value"] < 0.001 and h_ok
                controls[code] = {"status": "PASS" if passed else "FAIL", **best, "identical_to_A": h_ok}
        controls_failed = any(item["status"] == "FAIL" for item in controls.values())
        controls_notrun = any(item["status"] == "NOT_RUN" for item in controls.values())
        gates["G6"] = _gate("FAIL" if controls_failed else ("NOT_RUN" if controls_notrun else "PASS"), controls, GATE_THRESHOLDS["G6"](cfg), "results/per_example_results.csv")
        collateral_ok = bool(collateral.get("g7_pass"))
        gates["G7"] = _gate("PASS" if collateral_ok else "FAIL", collateral.get("g7_values"), GATE_THRESHOLDS["G7"](cfg), "results/collateral_metrics.json")
        surgery_ok = surgery.get("status") == "PASS" and surgery.get("only_declared_edit_changed") is True and surgery.get("hook_fold_max_abs_diff") is not None and surgery.get("hook_fold_max_abs_diff") <= 1e-3
        gates["G8"] = _gate("PASS" if surgery_ok else "FAIL", surgery, GATE_THRESHOLDS["G8"](cfg), "artifacts/surgery_integrity.json")
        health_ok = crosscoder.get("g9_pass") is True
        gates["G9"] = _gate("PASS" if health_ok else "FAIL", crosscoder.get("g9_values"), GATE_THRESHOLDS["G9"](cfg), "artifacts/crosscoder_health.json")
        rerun_rows = _load_rows(p("results/reproducibility_rerun.csv"))
        compared = [row for row in rerun_rows if row.get("condition") in {"A", "F"}]
        identical_fraction = sum(_as_bool(row.get("identical")) for row in compared) / len(compared) if compared else None
        repro_ok = len(compared) >= 400 and identical_fraction is not None and identical_fraction >= 0.99
        gates["G10"] = _gate("PASS" if repro_ok else ("NOT_RUN" if not compared else "FAIL"), {"identical_fraction": identical_fraction, "rows": len(compared)}, GATE_THRESHOLDS["G10"](cfg), "results/reproducibility_rerun.csv")
        gates["G11"] = _gate("NOT_RUN", None, 0, "reports/12_integrity_consistency_report.txt", "P13 has not completed")
        verdict = _compute_verdict(gates, val)
        a_wilson = wilson_ci(kA, nA, confidence) if nA else (None, None)
        a_exact = clopper_pearson_ci(kA, nA, confidence) if nA else (None, None)
        f_exact = clopper_pearson_ci(kF, nF, confidence) if nF else (None, None)
        best_control = max((item for item in controls.values() if item.get("rate") is not None), key=lambda item: item["rate"], default=None)
        if best_control and best_control.get("n"):
            best_control = {**best_control,
                            "wilson": wilson_ci(int(best_control["k"]), int(best_control["n"]), confidence),
                            "clopper_pearson": clopper_pearson_ci(int(best_control["k"]), int(best_control["n"]), confidence)}
        summary = {
            "test_prompts": nF, "documents": n_docs,
            "A": {"k": kA, "n": nA, "rate": rateA, "wilson": a_wilson, "clopper_pearson": a_exact},
            "F": {"k": kF, "n": nF, "rate": rateF, "wilson": f_wilson, "clopper_pearson": f_exact},
            "best_negative_control": best_control,
        }
    else:
        for gate in GATE_THRESHOLDS:
            gates[gate] = _gate("NOT_RUN", None, GATE_THRESHOLDS[gate](cfg), "results/per_example_results.csv", "test evaluation did not complete in this runtime")
        if crosscoder.get("status") == "FAIL" or crosscoder.get("g9_pass") is False:
            gates["G9"] = _gate("FAIL", crosscoder.get("g9_values"), GATE_THRESHOLDS["G9"](cfg), "artifacts/crosscoder_health.json")
        if surgery.get("status") == "FAIL":
            gates["G8"] = _gate("FAIL", surgery, GATE_THRESHOLDS["G8"](cfg), "artifacts/surgery_integrity.json")
        verdict = _compute_verdict(gates, val)
        summary = {"test_prompts": None, "documents": None, "A": None, "F": None, "best_negative_control": None}
    second_impl = None
    if full:
        differences = []
        for item in summaries:
            if item["n"]:
                a = wilson_ci(int(item["k"]), int(item["n"]), confidence)
                b2 = wilson_ci_crosscheck(int(item["k"]), int(item["n"]), confidence)
                differences.extend([abs(a[0] - b2[0]), abs(a[1] - b2[1])])
        second_impl = {"method_a": "closed-form Wilson score interval", "method_b": "bisection Wilson score equation", "max_abs_difference": max(differences, default=None), "tolerance": 1e-9}
    minimum_successes = {str(n): min_successes_for_lower_bound(n, float(cfg["PHENOTYPE_D_THRESHOLD"]["value"]), confidence) for n in (500, 1000, 2000)}
    results = {
        "schema_version": "1.0", "run_id": RUN_ID, "generated_utc": utc_now(),
        "verdict": verdict, "gates": gates, "headline_numbers": summary,
        "statistics_crosscheck": second_impl,
        "minimum_successes_for_wilson_lower_bound": minimum_successes,
        "test_set_access_count": int(data_access.get("access_count", 0)),
        "not_run": data_access.get("reason") if data_access.get("status") == "NOT_RUN" else None,
        "evidence_files": {"per_example": "results/per_example_results.csv", "condition_summary": "results/condition_summary.csv"},
    }
    write_json(p("final_results.json"), results)
    print(json.dumps({"verdict": verdict, "gates": {key: value["status"] for key, value in gates.items()}}, sort_keys=True))
    return "PASS", {"rows_read": len(rows), "statistics_crosscheck": second_impl, "verdict": verdict}


def _compute_verdict(gates: dict[str, dict[str, Any]], readiness: dict[str, Any] | None = None) -> str:
    readiness = readiness or {}
    invalid = ["G1", "G2", "G8", "G9", "G10", "G11"]
    if any(gates.get(key, {}).get("status") == "FAIL" for key in invalid):
        return "RUN_INVALID"
    if readiness.get("status") == "FAIL" and readiness.get("test_set_untouched", True):
        return "STOPPED_BEFORE_TEST"
    statuses = [entry.get("status") for entry in gates.values()]
    if any(value == "NOT_RUN" for value in statuses):
        return "INCOMPLETE"
    if gates.get("G4", {}).get("status") == "FAIL":
        return "PHENOTYPE_D_NOT_REACHED"
    if any(gates.get(key, {}).get("status") == "FAIL" for key in ("G3", "G5", "G6", "G7")):
        return "PHENOTYPE_D_NOT_ESTABLISHED"
    if all(value in {"PASS", "NOT_APPLICABLE"} for value in statuses):
        return "PHENOTYPE_D_VERIFIED"
    return "INCOMPLETE"


def _render_table(gates: dict[str, dict[str, Any]]) -> str:
    lines = ["Gate | Status | Value | Threshold"]
    for gate in [f"G{i}" for i in range(1, 12)]:
        record = gates.get(gate, {})
        lines.append(f"{gate} | {record.get('status', 'NOT_RUN')} | {json.dumps(record.get('value'), sort_keys=True)} | {json.dumps(record.get('threshold'), sort_keys=True)}")
    return "\n".join(lines)


def _build_spot_check_sample() -> int:
    rows = _load_rows(p("results/per_example_results.csv"))
    f_rows = [row for row in rows if row.get("condition") == "F" and row.get("replica") == "0"]
    if not f_rows:
        return 0
    a_rows = _per_prompt(rows, "A", "0")
    f_map = _per_prompt(rows, "F", "0")
    g_rows = [row for row in rows if row.get("condition") == "G"]
    if not a_rows or not g_rows:
        return 0
    replica_scores = {}
    for row in g_rows:
        replica_scores.setdefault(row.get("replica", "0"), []).append(int(float(row.get("agree", 0))))
    best_replica = max(replica_scores, key=lambda name: (sum(replica_scores[name]) / len(replica_scores[name]), name))
    g_map = _per_prompt(rows, "G", best_replica)
    prompt_ids = sorted(set(a_rows) & set(f_map) & set(g_map))
    if not prompt_ids:
        return 0
    cfg = read_json(p("spec/config_used.json"), config_used())
    import random
    rng = random.Random(int(cfg["SEED"]["value"]) + 404)
    sample_ids = sorted(rng.sample(prompt_ids, min(30, len(prompt_ids))))
    output = []
    for prompt_id in sample_ids:
        a, f, g = a_rows[prompt_id], f_map[prompt_id], g_map[prompt_id]
        output.append({
            "prompt_id": prompt_id, "doc_id": a.get("doc_id", prompt_id),
            "prompt_text": a.get("prompt_text", ""), "donor_output": a.get("donor_output", ""),
            "A_output": a.get("output", ""), "F_output": f.get("output", ""),
            "best_G_output": g.get("output", ""), "donor_label": a.get("donor_label", ""),
            "A_label": a.get("label", ""), "F_label": f.get("label", ""),
            "A_agree": a.get("agree", ""), "F_agree": f.get("agree", ""),
        })
    _write_csv(p("results/spot_check_sample.csv"), [
        "prompt_id", "doc_id", "prompt_text", "donor_output", "A_output", "F_output",
        "best_G_output", "donor_label", "A_label", "F_label", "A_agree", "F_agree",
    ], output)
    return len(output)


def _phase_12_render() -> tuple[str, dict[str, Any]]:
    spot_sample_n = _build_spot_check_sample()
    results = read_json(p("final_results.json"), None)
    if results is None:
        return "FAIL", {"reason": "final_results.json is absent"}
    gates = results.get("gates", {})
    access = int(results.get("test_set_access_count", 0))
    headline = results.get("headline_numbers", {})
    f_value = headline.get("F")
    A_value = headline.get("A")
    condition_rows = _load_rows(p("results/condition_summary.csv"))
    condition_table = "\n".join(json.dumps(row, sort_keys=True) for row in condition_rows) or "NOT_RUN: no condition rows"
    sweep_rows = _load_rows(p("results/val_alpha_layer_sweep.csv"))
    iteration_rows = _load_rows(p("results/val_iteration_log.csv"))
    detector_definition = read_json(p("artifacts/detector/detector_definition.json"), {"status": "NOT_RUN"})
    detector_validation = read_json(p("artifacts/detector/detector_validation.json"), {"status": "NOT_RUN"})
    detector_examples = read_json(p("artifacts/detector/detector_examples.json"), {"status": "NOT_RUN"})
    crosscoder_config = read_json(p("artifacts/crosscoder_config.json"), {"status": "NOT_RUN"})
    crosscoder_health = read_json(p("artifacts/crosscoder_health.json"), {"status": "NOT_RUN"})
    selected_latents = read_json(p("artifacts/selected_latents.json"), {"status": "NOT_RUN"})
    training_curves = _load_rows(p("artifacts/training_curves.csv"))
    vector_index = read_json(p("artifacts/vectors/vectors_index.json"), {"status": "NOT_RUN"})
    collateral_values = read_json(p("results/collateral_metrics.json"), {"status": "NOT_RUN"})
    spot_rows = _load_rows(p("results/spot_check_sample.csv"))[:5]
    paired_values = read_json(p("results/paired_tests.json"), {"status": "NOT_RUN"})
    condition_availability = read_json(p("results/condition_availability.json"), {"status": "NOT_RUN"})
    gate_issues = [f"{name}: {record.get('status')} (evidence: {record.get('evidence_file')})"
                   for name, record in gates.items() if record.get("status") in {"FAIL", "NOT_RUN"}]
    runtime_info = read_json(p("logs/runtime_probe.json"), {}) or {}
    runtime_missing = [name for name, available in runtime_info.get("packages", {}).items() if not available]
    if not runtime_info.get("cuda_available", False):
        runtime_missing.append("CUDA GPU")
    if not runtime_info.get("drive_mount_visible", False):
        runtime_missing.append("Google Drive mount")
    best_negative = headline.get("best_negative_control")
    if access == 0 or f_value is None:
        interpretation = [
            "The frozen plan defines agreement from a fixed detector and distinct-2 threshold.",
            "No Phenotype D estimate is available because the test evaluation did not run.",
            "This package records implementation and preflight evidence, not a model-surgery outcome.",
        ]
    elif results.get("verdict") == "PHENOTYPE_D_VERIFIED":
        interpretation = [
            "The primary condition met the frozen lower-bound and causal-comparison gates in this run.",
            "The result applies to the declared model pair, donor construction, corpus, and detector.",
            "It does not establish behavior for other model families or target behaviors.",
        ]
    else:
        interpretation = [
            "The reported rates and intervals were computed from the frozen per-example test records.",
            "The computed gate table shows which predeclared requirements were or were not met.",
            "This run does not support a broader claim beyond the declared model pair and target behavior.",
        ]
    summary_lines = [
        f"EQUYLAPTA 10.1 — {results.get('verdict', 'INCOMPLETE')}",
        "", "Computed test summary:",
        f"A: {json.dumps(A_value, sort_keys=True)}",
        f"F: {json.dumps(f_value, sort_keys=True)}",
        f"Best negative control: {json.dumps(best_negative, sort_keys=True)}",
        f"Test-set accesses: {access}", "", _render_table(gates), "", *interpretation,
    ]
    summary = "\n".join(summary_lines)
    _write_text(p("reports/00_EXECUTIVE_SUMMARY.txt"), summary)
    spec_hash = (p("spec/PHENOTYPE_D_SPEC.sha256").read_text(encoding="utf-8").split() or ["NOT_RUN"])[0]
    selection_hash = (p("spec/SELECTIONS_FROZEN.sha256").read_text(encoding="utf-8").split() or ["NOT_RUN"])[0] if p("spec/SELECTIONS_FROZEN.sha256").exists() else "NOT_RUN"
    spec_record = read_json(p("spec/PHENOTYPE_D_SPEC.json"), {}) or {}
    selection_record = read_json(p("spec/SELECTIONS_FROZEN.json"), {}) or {}
    access_record = read_json(p("logs/test_set_access_log.json"), {}) or {}
    config = read_json(p("spec/config_used.json"), {})
    report_texts = {
        "01_spec_and_config_report.txt": f"Resolved configuration follows spec/config_used.json, with every field tagged by source.\nPhenotype D definition follows spec/PHENOTYPE_D_SPEC.json.\nAnalysis-plan SHA-256: {spec_hash}\nSelections SHA-256: {selection_hash}\nSpec frozen UTC: {spec_record.get('frozen_utc', 'NOT_RUN')}\nSelections frozen UTC: {selection_record.get('created_utc', 'NOT_RUN')}\nFirst test access UTC: {access_record.get('timestamp_utc', 'NOT_RUN')}\nSpec hash at first access: {access_record.get('analysis_spec_sha256', 'NOT_RUN')}\nSelections hash at first access: {access_record.get('selections_sha256', 'NOT_RUN')}\nTest access count: {access}\n",
        "02_data_splits_leakage_report.txt": f"Data split status: {json.dumps(read_json(p('data/split_manifest.json'), {'status': 'NOT_RUN'}), sort_keys=True)}\nLeakage status: {json.dumps(read_json(p('data/leakage_check.json'), {'status': 'NOT_RUN'}), sort_keys=True)}\nTest prefixes are predeclared as document-initial neutral general-text segments.\n",
        "03_donor_detector_report.txt": f"Donor build: {json.dumps({k: v for k, v in (read_json(p('artifacts/donor_build/donor_build_report.json'), {'status': 'NOT_RUN'}) or {}).items() if k != 'training_history'}, sort_keys=True)}\nDetector definition: {json.dumps(detector_definition, sort_keys=True)}\nDetector validation: {json.dumps({k: v for k, v in detector_validation.items() if k != 'predictions'}, sort_keys=True)}\nDetector examples: {json.dumps(detector_examples, sort_keys=True)}\n",
        "04_locate_training_report.txt": f"Crosscoder configuration: {json.dumps(crosscoder_config, sort_keys=True)}\nTraining curves: {json.dumps(training_curves, sort_keys=True)}\nCrosscoder health and initialization-signature checks: {json.dumps(crosscoder_health, sort_keys=True)}\nSelected latent scores: {json.dumps(selected_latents, sort_keys=True)}\n",
        "05_calibration_val_report.txt": f"Validation readiness: {json.dumps(read_json(p('results/val_readiness.json'), {'status': 'NOT_RUN'}), sort_keys=True)}\nLayer/alpha/k sweep rows: {json.dumps(sweep_rows, sort_keys=True)}\nValidation iterations: {json.dumps(iteration_rows, sort_keys=True)}\n",
        "06_surgery_integrity_report.txt": f"Surgery integrity: {json.dumps(read_json(p('artifacts/surgery_integrity.json'), {'status': 'NOT_RUN'}), sort_keys=True)}\nWeight difference evidence: artifacts/weight_diff_report.json\n",
        "07_test_results_report.txt": f"Condition summaries (including k/n, rates, Wilson/Clopper-Pearson intervals, no-op rate, paired tests, and gap to F):\n{condition_table}\nCondition availability: {json.dumps(condition_availability, sort_keys=True)}\nPaired tests: {json.dumps(paired_values, sort_keys=True)}\nTest access count: {access}\n",
        "08_controls_report.txt": f"Control outcomes are in final_results.json under gate G6.\n{json.dumps(gates.get('G6', {}), sort_keys=True)}\nVector hashes, norms, and cosines to primary: {json.dumps(vector_index, sort_keys=True)}\n",
        "09_collateral_damage_report.txt": f"Collateral metrics: {json.dumps(collateral_values, sort_keys=True)}\nFive seeded spot-check examples (prompt, A, F, donor, best-G): {json.dumps(spot_rows, sort_keys=True)}\n",
        "10_statistics_audit_report.txt": f"Intervals: Wilson score and Clopper-Pearson. Paired test: exact two-sided McNemar.\nCross-check: {json.dumps(results.get('statistics_crosscheck'), sort_keys=True)}\nComputed minimum successes for a Wilson lower bound at the configured threshold: {json.dumps(results.get('minimum_successes_for_wilson_lower_bound'), sort_keys=True)}\nRecomputed condition n/k table: {condition_table}\nEvery available headline number is derived by P10 from results/per_example_results.csv.\n",
        "11_reproducibility_report.txt": f"Reproducibility results: {json.dumps(read_json(p('results/reproducibility_summary.json'), {'status': 'NOT_RUN'}), sort_keys=True)}\nTest-set accesses: {access}.\n",
        "12_integrity_consistency_report.txt": f"P13 integrity status: {json.dumps(read_json(p('reports/integrity_audit.json'), {'status': 'NOT_RUN'}), sort_keys=True)}\n",
        "13_limitations_next_steps.txt": ("Limitations: one recipient/donor design, one target behavior, and dependence on detector validity.\n"
            + "Ranked gate diagnosis from final_results.json: " + json.dumps(gate_issues, ensure_ascii=False) + "\n"
            + ("Runtime prerequisites not available: " + json.dumps(runtime_missing) + ". Provide the specified Colab T4 and mounted Google Drive, install requirements.txt, then rerun the frozen plan before test access.\nNo test-set access was made in this run.\n" if access == 0 else "Use the gate evidence files above to plan the next experiment; any new attempt must use a fresh test pool.\nThe recorded test-set access count is included above.\n")),
        "14_human_spot_check_guide.txt": "Open results/spot_check_sample.csv. For each row, read the prompt and donor, baseline, primary, and best-random continuations. Independently label the continuation and compare it with the frozen detector label. Recompute distinct-2 as distinct adjacent word pairs divided by all adjacent word pairs, then confirm agree equals one only when the label is positive and distinct-2 is at least 0.5. A valid detector should match human labels on at least 90% of checked rows.\n",
    }
    for filename, text in report_texts.items():
        _write_text(p("reports") / filename, text)
    # Keep rendered README concise and derive the file map from the present tree.
    present = sorted(path.relative_to(RUN_DIR).as_posix() for path in RUN_DIR.rglob("*") if path.is_file() and path.name not in {"README_FIRST.txt", "FINAL_PHENOTYPE_D_VERDICT.txt"} and "__pycache__" not in path.parts and path.suffix not in {".pyc", ".pyo"})
    directory_counts: dict[str, int] = {}
    root_files = []
    for name in present:
        if "/" in name:
            first = name.split("/", 1)[0]
            directory_counts[first] = directory_counts.get(first, 0) + 1
        else:
            root_files.append(name)
    readme = [
        f"EQUYLAPTA 10.1 — {results.get('verdict', 'INCOMPLETE')}",
        f"A: {json.dumps(A_value, sort_keys=True)}",
        f"F: {json.dumps(f_value, sort_keys=True)}",
        f"Best negative control: {json.dumps(best_negative, sort_keys=True)}",
        f"Test-set accesses: {access}",
        "Recompute in the specified Colab T4 with Drive mounted: python code/run_all.py",
        "final_results.json is the status source; reports are rendered by code.",
        "", "Package map (folder counts generated from the current tree):",
    ] + [f"- {name}/ — {count} files" for name, count in sorted(directory_counts.items())]
    readme.append("Root files: " + ", ".join(root_files[:12]))
    _write_text(p("README_FIRST.txt"), "\n".join(readme[:25]))
    verdict = [
        f"EQUYLAPTA 10.1 — {results.get('verdict', 'INCOMPLETE')}",
        "", _render_table(gates), "",
        f"Headline numbers: {json.dumps(headline, sort_keys=True)}",
        f"Test-set accesses: {access}",
        "The verdict is computed from available evidence and does not substitute missing measurements.",
    ]
    _write_text(p("FINAL_PHENOTYPE_D_VERDICT.txt"), "\n".join(verdict))
    print(f"Rendered {len(report_texts)} reports from final_results.json; current verdict={results.get('verdict')}")
    return "PASS", {"reports_rendered": len(report_texts), "files_indexed": len(present), "spot_check_rows": spot_sample_n}


def _scan_integrity() -> dict[str, Any]:
    py_files = sorted((RUN_DIR / "code").rglob("*.py"))
    text_files = sorted(path for path in RUN_DIR.rglob("*") if path.is_file() and path.suffix.lower() in {".txt", ".json", ".csv"})
    too_short = []
    for path in py_files:
        meaningful = [line for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip() and not line.lstrip().startswith("#")]
        if len(meaningful) < 5:
            too_short.append(path.relative_to(RUN_DIR).as_posix())
    banned = ["in" + "ferred" + "_" + "sample" + "_" + "size", "TO" + "DO", "place" + "holder", "simu" + "lated"]
    banned_findings = []
    for path in py_files:
        text = path.read_text(encoding="utf-8", errors="replace").lower()
        for pattern in banned:
            if pattern.lower() in text:
                banned_findings.append({"file": path.relative_to(RUN_DIR).as_posix(), "pattern": pattern})
    malformed_json = []
    for path in text_files:
        if path.suffix.lower() == ".json":
            try:
                json.loads(path.read_text(encoding="utf-8"))
            except Exception as exc:
                malformed_json.append({"file": path.relative_to(RUN_DIR).as_posix(), "error": str(exc)})
    results = read_json(p("final_results.json"), {}) or {}
    full_data = bool(_load_rows(p("results/per_example_results.csv")))
    allowed_statuses = {"PASS", "FAIL", "NOT_RUN", "NOT_APPLICABLE"}
    gate_status_errors = {name: item.get("status") for name, item in results.get("gates", {}).items() if item.get("status") not in allowed_statuses}
    status_disagreements = []
    expected_table = _render_table(results.get("gates", {}))
    for rel in ("reports/00_EXECUTIVE_SUMMARY.txt", "FINAL_PHENOTYPE_D_VERDICT.txt"):
        target = p(rel)
        if target.exists() and expected_table not in target.read_text(encoding="utf-8", errors="replace"):
            status_disagreements.append(rel)
    computed_verdict = results.get("verdict")
    for target in text_files:
        content = target.read_text(encoding="utf-8", errors="replace")
        if "PHENOTYPE_D_VERIFIED" in content and computed_verdict != "PHENOTYPE_D_VERIFIED":
            status_disagreements.append(target.relative_to(RUN_DIR).as_posix())
    required_always = [
        "README_FIRST.txt", "FINAL_PHENOTYPE_D_VERDICT.txt", "final_results.json",
        "spec/PHENOTYPE_D_SPEC.json", "spec/PHENOTYPE_D_SPEC.sha256", "spec/config_used.json",
        "code/common.py", "code/metric.py", "code/hooks.py", "code/reference_utils.py",
        "code/model_utils.py", "code/crosscoder.py", "code/experiment.py", "code/pipeline.py", "code/run_all.py",
        "code/tests/test_reference_utils.py", "logs/execution_log.txt", "logs/unit_tests.txt",
        "inputs_reference/v10_input_hashes.json", "inputs_reference/v10_defect_register.json",
    ] + ["code/" + name for name in PHASE_SCRIPT_NAMES] + ["reports/" + name for name in REPORT_FILES]
    missing_always = [name for name in required_always if not p(name).exists()]
    required_full = [
        "spec/SELECTIONS_FROZEN.json", "spec/SELECTIONS_FROZEN.sha256",
        "data/train_prompts.jsonl", "data/val_prompts.jsonl", "data/test_prompts.jsonl",
        "data/split_manifest.json", "data/leakage_check.json", "data/perplexity_docs.jsonl",
        "artifacts/donor_build/donor_build_report.json", "artifacts/donor_build/donor_recipe.json",
        "artifacts/detector/detector_definition.json", "artifacts/detector/detector_validation.json",
        "artifacts/detector/math_style_detector.joblib", "artifacts/crosscoder_weights.safetensors",
        "artifacts/crosscoder_config.json", "artifacts/training_curves.csv", "artifacts/selected_latents.json",
        "artifacts/surgery_diff.safetensors", "artifacts/weight_diff_report.json", "artifacts/apply_surgery.py",
        "artifacts/external_artifacts.json", "artifacts/vectors/vectors_index.json",
        "artifacts/surgery_integrity.json", "artifacts/crosscoder_health.json",
        "results/per_example_results.csv", "results/val_alpha_layer_sweep.csv", "results/val_iteration_log.csv",
        "results/condition_summary.csv", "results/paired_tests.json", "results/collateral_metrics.json",
        "results/secondary_metrics.json", "results/reproducibility_rerun.csv", "results/reproducibility_summary.json",
        "results/spot_check_sample.csv", "results/val_readiness.json", "results/condition_availability.json",
        "logs/test_set_access_log.json", "logs/nvidia_smi.txt", "logs/pip_freeze.txt", "logs/unit_tests.txt",
        "inputs_reference/v10_input_hashes.json", "inputs_reference/v10_defect_register.json",
    ]
    missing_full = [name for name in required_full if not p(name).exists()] if full_data else []
    missing_refs = []
    path_pattern = re.compile(r"\b(?:code|data|results|artifacts|reports|logs|spec|inputs_reference)/[A-Za-z0-9_./-]+")
    for path in text_files:
        content = path.read_text(encoding="utf-8", errors="replace")
        for token in path_pattern.findall(content):
            token = token.rstrip(".,:;)]}")
            if token and not p(token).exists():
                missing_refs.append({"source": path.relative_to(RUN_DIR).as_posix(), "path": token})
    violations = []
    for label, items in (
        ("python_files_under_minimum_lines", too_short),
        ("banned_code_patterns", banned_findings),
        ("malformed_json", malformed_json),
        ("missing_required_files", missing_always),
        ("missing_referenced_files", missing_refs),
        ("invalid_gate_statuses", gate_status_errors),
        ("status_disagreements", status_disagreements),
    ):
        if items:
            violations.append({"check": label, "items": items})
    if missing_full:
        violations.append({"check": "missing_full_run_evidence", "items": missing_full})
    return {
        "created_utc": utc_now(), "status": "PASS" if not violations else "FAIL",
        "full_test_data_available": full_data, "python_files_scanned": len(py_files),
        "text_files_scanned": len(text_files), "violations": violations,
        "static_code_checks": {"short_python_files": too_short, "banned_findings": banned_findings, "malformed_json": malformed_json},
        "status_consistency_checks": {"invalid_gate_statuses": gate_status_errors, "report_table_disagreements": status_disagreements},
        "missing_full_run_evidence": missing_full,
        "gate_11_computable": bool(full_data and not violations),
    }


def _phase_13_integrity() -> tuple[str, dict[str, Any]]:
    audit = _scan_integrity()
    write_json(p("reports/integrity_audit.json"), audit)
    results = read_json(p("final_results.json"), {}) or {}
    gates = results.get("gates", {})
    if audit["gate_11_computable"]:
        gates["G11"] = _gate("PASS" if audit["status"] == "PASS" else "FAIL", len(audit["violations"]), 0, "reports/integrity_audit.json")
    else:
        gates["G11"] = _gate("NOT_RUN", None, 0, "reports/integrity_audit.json", "test evidence is absent, so full number-to-source traceability cannot be evaluated")
    results["gates"] = gates
    readiness = read_json(p("results/val_readiness.json"), {}) or {}
    results["verdict"] = _compute_verdict(gates, readiness)
    results["generated_utc"] = utc_now()
    write_json(p("final_results.json"), results)
    # Refresh the user-facing verdict and reports from the single source of truth.
    _phase_12_render()
    final_audit = _scan_integrity()
    write_json(p("reports/integrity_audit.json"), final_audit)
    _write_text(p("reports/12_integrity_consistency_report.txt"),
                "P13 integrity status: " + json.dumps(final_audit, sort_keys=True) + "\n")
    if final_audit["gate_11_computable"] and final_audit["status"] != "PASS":
        gates["G11"] = _gate("FAIL", len(final_audit["violations"]), 0, "reports/integrity_audit.json")
    elif not final_audit["gate_11_computable"]:
        gates["G11"] = _gate("NOT_RUN", None, 0, "reports/integrity_audit.json", "test evidence is absent")
    results["gates"] = gates
    results["verdict"] = _compute_verdict(gates, readiness)
    write_json(p("final_results.json"), results)
    _phase_12_render()
    print(f"P13 static audit status={final_audit['status']} violations={len(final_audit['violations'])}; G11={gates['G11']['status']}")
    return ("PASS" if final_audit["status"] == "PASS" else "FAIL"), final_audit


def _phase_14_prepare() -> tuple[str, dict[str, Any]]:
    drive_visible = DRIVE_ROOT.parent.exists() and DRIVE_ROOT.parent.is_dir()
    details = {
        "drive_visible": drive_visible,
        "archive_finalization": "run_all.py performs final archive refresh after phase stdout is saved",
        "drive_status": "NOT_RUN" if not drive_visible else "READY",
        "run_tree": str(RUN_DIR),
    }
    write_json(p("artifacts/package_plan.json"), details)
    print(json.dumps(details, sort_keys=True))
    return "PASS", details


def _phase_files_ready_for_package() -> None:
    ensure_tree()
    for name in ("train_prompts.jsonl", "val_prompts.jsonl", "test_prompts.jsonl", "perplexity_docs.jsonl"):
        target = p("data") / name
        if not target.exists():
            target.write_text("", encoding="utf-8")
    for name in ("per_example_results.csv", "reproducibility_rerun.csv", "spot_check_sample.csv", "val_alpha_layer_sweep.csv", "val_iteration_log.csv", "condition_summary.csv", "training_curves.csv"):
        target = p("results") / name if name != "training_curves.csv" else p("artifacts/training_curves.csv")
        if not target.exists():
            write_not_run_csv(target, name)


def _phase_for_experiment(phase: int) -> tuple[str, dict[str, Any]]:
    phase_state = read_json(p("logs/phase_state.json"), {}) or {}
    if phase_state.get("P0", {}).get("status") != "PASS":
        reason = "P0 setup and unit-test gate did not pass"
        _not_run_artifacts(phase, reason)
        return "NOT_RUN", {"reason": reason}
    if phase > 1:
        failed = [number for number in range(1, phase) if (read_json(p("logs/phase_state.json"), {}) or {}).get(f"P{number}", {}).get("status") not in {"PASS", "NOT_APPLICABLE"}]
        if failed:
            reason = f"upstream phases did not pass: {failed}"
            _not_run_artifacts(phase, reason)
            return "NOT_RUN", {"reason": reason}
    blockers = runtime_blockers()
    if blockers:
        reason = "; ".join(blockers)
        _not_run_artifacts(phase, reason)
        return "NOT_RUN", {"reason": reason, "blockers": blockers}
    from experiment import run_experiment_phase
    return run_experiment_phase(phase)


def run_phase(phase: int) -> int:
    """Run one numbered phase and persist its status, timing, and Drive-mirror attempt."""
    ensure_tree()
    phase_name = f"P{phase}"
    started = time.monotonic()
    try:
        if phase == 0:
            status, details = _phase_00()
        elif 1 <= phase <= 9:
            status, details = _phase_for_experiment(phase)
        elif phase == 10:
            status, details = _phase_10_statistics()
        elif phase == 11:
            if not p("results/per_example_results.csv").exists() or not _load_rows(p("results/per_example_results.csv")):
                _not_run_artifacts(11, "P9 did not produce test rows")
                write_json(p("results/reproducibility_summary.json"), {"status": "NOT_RUN", "reason": "P9 did not produce test rows"})
                status, details = "NOT_RUN", {"reason": "P9 did not produce test rows"}
            else:
                from experiment import run_reproducibility_rerun
                status, details = run_reproducibility_rerun()
                _phase_10_statistics()
        elif phase == 12:
            _phase_files_ready_for_package()
            status, details = _phase_12_render()
        elif phase == 13:
            status, details = _phase_13_integrity()
        elif phase == 14:
            status, details = _phase_14_prepare()
        else:
            raise ValueError(f"unknown phase number: {phase}")
    except Exception as exc:
        status = "FAIL"
        details = {"error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc()}
        _write_text(p(f"logs/phase_{phase:02d}_error.txt"), details["traceback"])
        print(f"{phase_name} error: {type(exc).__name__}: {exc}", file=sys.stderr)
    elapsed = time.monotonic() - started
    details = {**details, "duration_seconds": elapsed}
    checkpoint = phase in {1, 3, 5, 7, 9}
    mark_phase(phase_name, status, details, checkpoint=checkpoint)
    print(f"{phase_name} status={status} duration_seconds={elapsed:.3f}")
    return 0


def finalize_archive() -> dict[str, Any]:
    """Refresh manifest, derive its file map from a zip listing, then package and verify."""
    from reference_utils import build_manifest, make_zip, package_and_copy, write_drive_verification
    from common import sha256_file as common_sha256_file
    _phase_files_ready_for_package()
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    local_zip = WORK_DIR / f"{RUN_ID}.zip"
    preview_zip = WORK_DIR / f".{RUN_ID}_listing_preview.zip"
    build_manifest(RUN_DIR, RUN_ID)
    make_zip(RUN_DIR, RUN_ID, preview_zip)
    with zipfile.ZipFile(preview_zip) as archive:
        preview_listing = sorted(item.filename for item in archive.infolist() if not item.is_dir())
    preview_zip.unlink(missing_ok=True)
    results = read_json(p("final_results.json"), {}) or {}
    headline = results.get("headline_numbers", {})
    folder_counts: dict[str, int] = {}
    root_entries = []
    for member in preview_listing:
        relative = member.split("/", 1)[1] if "/" in member else member
        if "/" in relative:
            folder = relative.split("/", 1)[0]
            folder_counts[folder] = folder_counts.get(folder, 0) + 1
        else:
            root_entries.append(relative)
    readme = [
        f"EQUYLAPTA 10.1 — {results.get('verdict', 'INCOMPLETE')}",
        f"A: {json.dumps(headline.get('A'), sort_keys=True)}",
        f"F: {json.dumps(headline.get('F'), sort_keys=True)}",
        f"Best negative control: {json.dumps(headline.get('best_negative_control'), sort_keys=True)}",
        f"Test-set accesses: {results.get('test_set_access_count', 0)}",
        "Recompute in the specified Colab T4 with Drive mounted: python code/run_all.py",
        "final_results.json is the status source; reports are rendered by code.",
        f"Archive listing entries counted from zip: {len(preview_listing)}",
        "", "Folder file counts from the zip listing:",
    ] + [f"- {folder}/ — {count}" for folder, count in sorted(folder_counts.items())]
    readme.append("Top-level files from the zip listing: " + ", ".join(root_entries[:12]))
    _write_text(p("README_FIRST.txt"), "\n".join(readme[:25]))
    manifest = build_manifest(RUN_DIR, RUN_ID)
    drive_visible = DRIVE_ROOT.parent.exists() and DRIVE_ROOT.parent.is_dir()
    if drive_visible:
        result = package_and_copy(RUN_DIR, RUN_ID, DRIVE_ROOT, tmp_dir=WORK_DIR)
        write_drive_verification(result, DRIVE_ROOT, RUN_ID)
        result["manifest_file_count"] = manifest["n_files"]
        result["mode"] = "drive_copy"
    else:
        make_zip(RUN_DIR, RUN_ID, local_zip)
        with zipfile.ZipFile(local_zip) as archive:
            testzip = archive.testzip()
            listing = sorted(item.filename for item in archive.infolist() if not item.is_dir())
        expected_listing = sorted([f"{RUN_ID}/{item['path']}" for item in manifest["files"]] + [f"{RUN_ID}/manifest.json", f"{RUN_ID}/SHA256SUMS.txt"])
        result = {
            "run_id": RUN_ID, "local_zip": str(local_zip), "drive_zip": None,
            "bytes": local_zip.stat().st_size, "local_sha256": common_sha256_file(local_zip),
            "drive_sha256": None, "sha_match": None, "testzip_ok": testzip is None,
            "zip_matches_manifest": listing == expected_listing,
            "file_listing": listing, "status": ("LOCAL_ARCHIVE_OK_DRIVE_NOT_RUN" if testzip is None and listing == expected_listing else "FAILED_PACKAGING"),
            "manifest_file_count": manifest["n_files"], "mode": "local_only",
            "drive_reason": "Google Drive mount is unavailable in this runtime",
        }
    # Sidecar stays outside the self-contained archive because an archive cannot contain its own hash.
    sidecar = WORK_DIR / f"{RUN_ID}_package_verification.json"
    write_json(sidecar, result)
    print(json.dumps({"zip": str(local_zip), "status": result["status"], "bytes": result["bytes"], "sha256": result["local_sha256"], "files": len(result["file_listing"])}, sort_keys=True))
    return result

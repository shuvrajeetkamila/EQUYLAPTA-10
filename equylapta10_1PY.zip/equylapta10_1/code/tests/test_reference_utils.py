"""Appendix B regression tests plus detector and PyTorch surgery checks."""
import copy
import json
import os
import tempfile
import zipfile

import numpy as np
from scipy import stats

import reference_utils as R
from metric import MathStyleDetector, detector_metrics


def test_wilson_known():
    lo, hi = R.wilson_ci(231, 250)
    assert abs(lo - 0.884) < 0.001, lo
    assert abs(R.wilson_ci(0, 10)[0]) < 1e-12
    assert abs(R.wilson_ci(10, 10)[1] - 1.0) < 1e-12


def test_wilson_crosscheck():
    for n in (1, 7, 50, 250, 500, 1000, 2000):
        for k in sorted({0, 1, n // 3, n // 2, int(.92 * n), n - 1, n}):
            first = R.wilson_ci(k, n)
            second = R.wilson_ci_crosscheck(k, n)
            assert max(abs(first[0] - second[0]), abs(first[1] - second[1])) < 1e-9, (k, n, first, second)


def test_wilson_vs_scipy():
    expected = stats.binomtest(231, 250).proportion_ci(0.95, method="wilson")
    actual = R.wilson_ci(231, 250)
    assert abs(actual[0] - expected.low) < 1e-9
    assert abs(actual[1] - expected.high) < 1e-9


def test_clopper():
    expected = stats.binomtest(231, 250).proportion_ci(0.95, method="exact")
    actual = R.clopper_pearson_ci(231, 250)
    assert abs(actual[0] - expected.low) < 1e-9
    assert abs(actual[1] - expected.high) < 1e-9


def test_mcnemar():
    assert R.mcnemar_exact(0, 0) == 1.0
    assert abs(R.mcnemar_exact(10, 0) - 2 * 0.5 ** 10) < 1e-12
    assert abs(R.mcnemar_exact(5, 5) - 1.0) < 1e-12
    assert abs(R.mcnemar_exact(3, 9) - stats.binomtest(3, 12, 0.5).pvalue) < 1e-12
    assert R.discordant_counts([1, 0, 1], [0, 1, 1]) == (1, 1)


def test_min_successes_table():
    assert R.min_successes_for_lower_bound(500) == 464
    assert R.min_successes_for_lower_bound(1000) == 919
    assert R.min_successes_for_lower_bound(2000) == 1827


def test_bootstrap_deterministic():
    x = np.array([1] * 90 + [0] * 10)
    y = np.array([0] * 60 + [1] * 40)
    first = R.bootstrap_diff_ci(x, y, 500, seed=3)
    second = R.bootstrap_diff_ci(x, y, 500, seed=3)
    assert first == second and first[1] <= first[0] <= first[2]


def test_distinct2_and_agree():
    assert R.distinct2("a b c d") == 1.0
    assert R.distinct2("a a a a a a") < 0.5
    assert R.distinct2("a") == 0.0 and R.distinct2([]) == 0.0
    assert R.agree(1, 0.9) == 1 and R.agree(1, 0.49) == 0 and R.agree(0, 1.0) == 0
    assert R.agree(1, R.distinct2("x x x x x x x x")) == 0
    assert R.token_match_frac([1, 2, 3], [1, 2]) == 2 / 3


def test_init_signature():
    rng = np.random.default_rng(0)
    fan = 512
    bound = 1 / np.sqrt(fan)
    initial = rng.uniform(-bound, bound, (8192, fan))
    assert R.init_signature_test(initial)["looks_like_init"] is True
    assert abs(R.init_signature_test(initial)["excess_kurtosis"] + 1.2) < 0.05
    trained_like = initial + rng.normal(0, 0.05, initial.shape)
    assert R.init_signature_test(trained_like)["looks_like_init"] is False
    assert R.init_signature_test(trained_like, init_w=initial)["looks_like_init"] is False
    assert R.init_signature_test(initial * 1.0, init_w=initial)["looks_like_init"] is True
    assert R.init_signature_test(np.zeros(64))["looks_like_init"] is True


def test_weight_diff():
    before = {"x": np.ones(3), "y": np.zeros(2)}
    after = {"x": np.ones(3), "y": np.array([0., 1e-3])}
    result = R.weight_diff_report(before, after)
    assert result["changed"] == ["y"]
    assert abs(result["tensors"]["y"]["max_abs_diff"] - 1e-3) < 1e-12
    assert result["tensors"]["x"]["changed"] is False


def test_hashing():
    assert R.sha256_bytes(b"abc") == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"


def test_package_roundtrip():
    with tempfile.TemporaryDirectory() as temp:
        run = os.path.join(temp, "work", "rid")
        os.makedirs(run + "/sub")
        with open(run + "/a.txt", "w", encoding="utf-8") as handle:
            handle.write("hello")
        with open(run + "/sub/b.txt", "w", encoding="utf-8") as handle:
            handle.write("world")
        drive = os.path.join(temp, "drive")
        os.makedirs(drive)
        scratch = os.path.join(temp, "scratch")
        os.makedirs(scratch)
        result = R.package_and_copy(run, "rid", drive, tmp_dir=scratch)
        assert result["sha_match"] and result["testzip_ok"] and result["zip_matches_manifest"]
        assert result["status"] == "OK"
        R.write_drive_verification(result, drive, "rid")
        with open(drive + "/rid_SHA256.txt", encoding="utf-8") as handle:
            assert handle.read().split()[1] == "rid.zip"
        second = R.package_and_copy(run, "rid", drive, tmp_dir=scratch)
        assert any("_prev_" in filename for filename in os.listdir(drive))
        assert second["local_sha256"] == result["local_sha256"]


def test_detector_on_synthetic_strings():
    math_texts = [
        "Solve for x: 2x plus 3 equals 11. Subtract 3, then divide by 2.",
        "Compute the fraction 3 over 4 plus 1 over 4 to obtain one.",
        "The equation has two sides; isolate the variable using addition.",
        "A triangle has three angles whose sum is 180 degrees.",
        "If y equals 2x and x is 5, substitution gives y equal to 10.",
        "Multiply 7 by 8 to get 56, then check the arithmetic.",
    ]
    general_texts = [
        "The afternoon light crossed the quiet garden and warmed the old stone wall.",
        "A passenger waited near the station while rain moved over the rooftops.",
        "The small wooden boat drifted slowly along the green river at dusk.",
        "Several birds circled above the field before settling among the trees.",
        "The library opened its doors early for visitors from the nearby town.",
        "A cool breeze carried the scent of pine through the open window.",
    ]
    train_texts = math_texts[:4] + general_texts[:4]
    train_labels = [1] * 4 + [0] * 4
    detector = MathStyleDetector(seed=17).fit(train_texts, train_labels)
    validation = detector_metrics(detector, math_texts[4:] + general_texts[4:], [1, 1, 0, 0])
    assert validation["n"] == 4
    assert len(validation["confusion_matrix_labels_0_1"]) == 2
    assert set(detector.predict([math_texts[5], general_texts[5]])) <= {0, 1}


def test_hook_vs_fold_tiny_gpt_neox():
    """Check the prescribed hook edit against the same edit folded into the bias."""
    try:
        import torch
        from transformers import GPTNeoXConfig, GPTNeoXForCausalLM
    except ImportError as exc:
        raise __import__("unittest").SkipTest(f"optional hook test needs torch and transformers: {exc}")
    torch.manual_seed(19)
    config = GPTNeoXConfig(
        vocab_size=97, hidden_size=32, num_hidden_layers=2, num_attention_heads=4,
        intermediate_size=64, max_position_embeddings=64, rotary_pct=0.25,
        hidden_dropout=0.0, attention_dropout=0.0, use_parallel_residual=True,
    )
    base = GPTNeoXForCausalLM(config).eval()
    hooked = copy.deepcopy(base).eval()
    folded = copy.deepcopy(base).eval()
    vector = torch.randn(config.hidden_size)
    vector = vector / vector.norm()
    alpha_abs = 0.07
    from hooks import steering_context
    with steering_context(hooked, 0, vector, alpha_abs):
        hooked_logits = hooked(input_ids=torch.tensor([[1, 7, 12, 19]]), use_cache=False).logits
    from reference_utils import fold_bias
    fold_bias(folded, 0, vector, alpha_abs)
    folded_logits = folded(input_ids=torch.tensor([[1, 7, 12, 19]]), use_cache=False).logits
    maximum = (hooked_logits - folded_logits).abs().max().item()
    assert maximum <= 1e-3, maximum


def test_crosscoder_training_step():
    try:
        import torch
        from crosscoder import SparseCrosscoder, crosscoder_loss
    except ImportError as exc:
        raise __import__("unittest").SkipTest(f"optional crosscoder test needs torch: {exc}")
    torch.manual_seed(23)
    module = SparseCrosscoder(hidden_dim=8, latent_dim=16)
    optimizer = torch.optim.Adam(module.parameters(), lr=1e-3)
    recipient = torch.randn(12, 8)
    donor = torch.randn(12, 8)
    before = module.encoder_recipient.weight.detach().clone()
    optimizer.zero_grad(set_to_none=True)
    loss, metrics = crosscoder_loss(module, recipient, donor)
    loss.backward()
    optimizer.step()
    assert np.isfinite(metrics["loss"])
    assert not torch.equal(before, module.encoder_recipient.weight.detach())

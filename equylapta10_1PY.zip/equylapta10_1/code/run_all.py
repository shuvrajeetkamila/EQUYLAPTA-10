"""Execute P0-P14 in order, save all phase stdout/stderr, then finalize the archive."""
from __future__ import annotations

import contextlib
import io
import subprocess
import sys
from pathlib import Path

from common import RUN_DIR, RUN_ID, WORK_DIR, ensure_tree, file_tree_stats, read_json, utc_now, write_json
from pipeline import PHASE_SCRIPT_NAMES, finalize_archive


def _refresh_drive_copy(phase: str) -> dict:
    """Repeat the R13 mirror/checkpoint after the runner has saved the phase log."""
    from common import checkpoint_to_drive, mirror_to_drive
    mirrored = mirror_to_drive(phase)
    checkpoint = checkpoint_to_drive(phase) if phase in {"P1", "P3", "P5", "P7", "P9"} else None
    entry = {"timestamp_utc": utc_now(), "phase": phase, "mirror": mirrored, "checkpoint": checkpoint}
    write_json(RUN_DIR / "logs" / f"{phase.lower()}_runner_sync.json", entry)
    if mirrored.get("status") == "PASS":
        mirror_to_drive(phase)
    if checkpoint and checkpoint.get("status") == "PASS":
        checkpoint_to_drive(phase)
    return entry


def main() -> int:
    ensure_tree()
    access_path = RUN_DIR / "logs" / "test_set_access_log.json"
    prior_access = read_json(access_path, {}) or {}
    if int(prior_access.get("access_count", 0)) > 0:
        print("Refusing to restart P0-P14 after the frozen test set was accessed. Preserve this run and start a new run ID for any new evaluation.", file=sys.stderr)
        return 2
    if access_path.exists() and prior_access.get("status") == "NOT_RUN":
        archive = RUN_DIR / "logs" / "test_set_access_log_prior_NOT_RUN.json"
        archive.write_text(access_path.read_text(encoding="utf-8"), encoding="utf-8")
        access_path.unlink()
    code_dir = RUN_DIR / "code"
    results = []
    for number, script_name in enumerate(PHASE_SCRIPT_NAMES):
        script = code_dir / script_name
        command = [sys.executable, str(script)]
        completed = subprocess.run(command, cwd=RUN_DIR, capture_output=True, text=True, check=False)
        combined = completed.stdout
        if completed.stderr:
            combined += ("\n" if combined else "") + "[stderr]\n" + completed.stderr
        log_path = RUN_DIR / "logs" / f"phase_{number:02d}_stdout.txt"
        log_path.write_text(combined or "(no stdout or stderr)\n", encoding="utf-8")
        sync = _refresh_drive_copy(f"P{number}")
        results.append({
            "phase": f"P{number}", "script": script_name,
            "return_code": completed.returncode, "stdout_log": str(log_path.relative_to(RUN_DIR)),
            "runner_sync": sync,
        })
    (RUN_DIR / "logs" / "package_finalize.txt").write_text(
        "P14 archive finalization is executed after all phase stdout files are saved.\n"
        "The archive and any Drive copy are checked by code; the sidecar is outside the archive.\n",
        encoding="utf-8",
    )
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        package = finalize_archive()
    # R13 mirror happens after the final in-tree package log was written.
    from common import mirror_to_drive
    final_mirror = mirror_to_drive("P14")
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    write_json(WORK_DIR / f"{RUN_ID}_execution_summary.json", {
        "created_utc": utc_now(), "phases": results, "package": package,
        "final_mirror": final_mirror, "finalizer_stdout": buffer.getvalue(),
        "run_tree_stats": file_tree_stats(RUN_DIR),
    })
    print(f"EQUYLAPTA pipeline scripts executed: {len(results)}")
    print(f"Archive status: {package['status']}")
    print(f"Archive path: {package.get('local_zip')}")
    print(f"Archive bytes: {package.get('bytes')}")
    print(f"Archive SHA-256: {package.get('local_sha256')}")
    print(f"Drive copy: {package.get('drive_zip') or 'NOT_RUN (Google Drive unavailable)'}")
    return 0 if all(item["return_code"] == 0 for item in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())

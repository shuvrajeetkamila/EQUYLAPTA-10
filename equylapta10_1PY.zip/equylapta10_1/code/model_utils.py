"""Optional Transformers/PyTorch helpers used by the experiment phases."""
from __future__ import annotations

import contextlib
from typing import Any, Iterable, Sequence

import numpy as np

from common import DEFAULTS, set_seeds
from hooks import steering_context


def torch_modules():
    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as exc:
        raise RuntimeError(f"PyTorch and Transformers are required for model work: {exc}") from exc
    return torch, AutoModelForCausalLM, AutoTokenizer


def experiment_device():
    torch, _, _ = torch_modules()
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required by the EQUYLAPTA 10.1 work order")
    return torch.device("cuda")


def load_tokenizer(model_name: str | None = None):
    _, _, AutoTokenizer = torch_modules()
    name = model_name or DEFAULTS["RECIPIENT_MODEL"]
    tokenizer = AutoTokenizer.from_pretrained(name, use_fast=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    return tokenizer


def load_model(model_name: str | None = None, *, local_files_only: bool = False):
    torch, AutoModelForCausalLM, _ = torch_modules()
    name = model_name or DEFAULTS["RECIPIENT_MODEL"]
    model = AutoModelForCausalLM.from_pretrained(
        name, torch_dtype=torch.float32, local_files_only=local_files_only,
    )
    model.to(experiment_device())
    model.eval()
    return model


def model_layers(model: Any):
    try:
        return model.gpt_neox.layers
    except AttributeError as exc:
        raise TypeError("expected a GPT-NeoX model with gpt_neox.layers") from exc


def encode_text_batch(tokenizer: Any, texts: Sequence[str], *, max_length: int = 128):
    torch, _, _ = torch_modules()
    batch = tokenizer(
        list(texts), return_tensors="pt", padding=True, truncation=True,
        max_length=max_length, add_special_tokens=True,
    )
    device = experiment_device()
    return {key: value.to(device) for key, value in batch.items() if torch.is_tensor(value)}


def _steering(model: Any, edit: tuple[int, Any, float] | None):
    if edit is None:
        return contextlib.nullcontext(model)
    layer, vector, alpha_abs = edit
    return steering_context(model, int(layer), vector, float(alpha_abs))


def generate_texts(
    model: Any,
    tokenizer: Any,
    texts: Sequence[str],
    *,
    max_new_tokens: int = 48,
    batch_size: int = 32,
    edit: tuple[int, Any, float] | None = None,
    min_new_tokens: int | None = None,
    seed: int = 1010,
) -> list[dict[str, Any]]:
    """Greedy batched generation; steering stays attached through all decode steps."""
    torch, _, _ = torch_modules()
    if batch_size <= 0 or max_new_tokens <= 0:
        raise ValueError("batch_size and max_new_tokens must be positive")
    set_seeds(seed)
    model.eval()
    rows: list[dict[str, Any]] = []
    with torch.inference_mode(), _steering(model, edit):
        for start in range(0, len(texts), batch_size):
            batch_texts = list(texts[start:start + batch_size])
            encoded = encode_text_batch(tokenizer, batch_texts, max_length=512)
            prompt_width = encoded["input_ids"].shape[1]
            generated = model.generate(
                **encoded, do_sample=False, num_beams=1,
                max_new_tokens=int(max_new_tokens),
                min_new_tokens=int(min_new_tokens if min_new_tokens is not None else max_new_tokens),
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
                use_cache=True,
            )
            continuation_ids = generated[:, prompt_width:]
            for text, ids in zip(batch_texts, continuation_ids):
                token_ids = ids.detach().cpu().tolist()
                decoded = tokenizer.decode(token_ids, skip_special_tokens=True)
                rows.append({"prompt_text": text, "output": decoded, "token_ids": token_ids})
    return rows


def collect_layer_activations(
    model: Any,
    tokenizer: Any,
    texts: Sequence[str],
    layers: Sequence[int],
    *,
    max_tokens: int = 200_000,
    batch_size: int = 8,
    max_length: int = 128,
    exclude_position_zero: bool = True,
) -> dict[int, np.ndarray]:
    """Collect masked residual activations from selected GPT-NeoX block outputs."""
    torch, _, _ = torch_modules()
    blocks = model_layers(model)
    captured: dict[int, list[np.ndarray]] = {int(layer): [] for layer in layers}
    counts = {int(layer): 0 for layer in layers}
    handles = []
    for layer in layers:
        layer = int(layer)
        if layer < 0 or layer >= len(blocks):
            raise IndexError(f"layer {layer} outside model depth {len(blocks)}")

        def make_capture(index: int):
            def capture(module, inputs, output):
                hidden = output[0] if isinstance(output, tuple) else output
                stash[index] = hidden.detach()
            return capture

        stash: dict[int, Any] = {}
        handles.append(blocks[layer].register_forward_hook(make_capture(layer)))
    model.eval()
    try:
        with torch.inference_mode():
            for start in range(0, len(texts), batch_size):
                chunk = texts[start:start + batch_size]
                encoded = encode_text_batch(tokenizer, chunk, max_length=max_length)
                stash.clear()
                model(**encoded, use_cache=False)
                mask = encoded["attention_mask"].bool()
                if exclude_position_zero and mask.shape[1] > 0:
                    mask[:, 0] = False
                for layer in layers:
                    key = int(layer)
                    values = stash[key][mask].float().cpu().numpy()
                    remaining = max_tokens - counts[key]
                    if remaining > 0 and values.size:
                        values = values[:remaining]
                        captured[key].append(values)
                        counts[key] += values.shape[0]
                if min(counts.values(), default=0) >= max_tokens:
                    break
    finally:
        for handle in handles:
            handle.remove()
    result = {}
    for layer in layers:
        key = int(layer)
        if captured[key]:
            result[key] = np.concatenate(captured[key], axis=0)
        else:
            result[key] = np.empty((0, int(model.config.hidden_size)), dtype=np.float32)
    return result


def collect_paired_layer_activations(
    recipient: Any,
    donor: Any,
    tokenizer: Any,
    texts: Sequence[str],
    layers: Sequence[int],
    *,
    max_tokens: int = 200_000,
    batch_size: int = 8,
    max_length: int = 128,
) -> tuple[dict[int, np.ndarray], dict[int, np.ndarray]]:
    rec = collect_layer_activations(recipient, tokenizer, texts, layers, max_tokens=max_tokens, batch_size=batch_size, max_length=max_length)
    don = collect_layer_activations(donor, tokenizer, texts, layers, max_tokens=max_tokens, batch_size=batch_size, max_length=max_length)
    for layer in layers:
        if rec[int(layer)].shape != don[int(layer)].shape:
            raise RuntimeError(f"paired activation shapes differ at layer {layer}")
    return rec, don


def continuation_kl(
    donor: Any,
    comparison: Any,
    tokenizer: Any,
    prompts: Sequence[str],
    continuation_ids: Sequence[Sequence[int]],
    *,
    batch_size: int = 8,
) -> list[float]:
    """Per-example mean KL(p_donor || p_comparison) over teacher-forced continuation tokens."""
    torch, _, _ = torch_modules()
    if len(prompts) != len(continuation_ids):
        raise ValueError("prompts and continuation ids must be aligned")
    device = experiment_device()
    values: list[float] = []
    donor.eval(); comparison.eval()
    with torch.inference_mode():
        for start in range(0, len(prompts), batch_size):
            batch_prompts = list(prompts[start:start + batch_size])
            batch_cont = [list(map(int, ids)) for ids in continuation_ids[start:start + batch_size]]
            sequences = []
            starts = []
            for prompt, cont in zip(batch_prompts, batch_cont):
                prompt_ids = tokenizer(prompt, add_special_tokens=True, truncation=True, max_length=512)["input_ids"]
                if not cont:
                    cont = [int(tokenizer.eos_token_id)]
                sequences.append(prompt_ids + cont)
                starts.append(max(0, len(prompt_ids) - 1))
            max_len = max(len(seq) for seq in sequences)
            pad = int(tokenizer.pad_token_id)
            input_ids = torch.full((len(sequences), max_len), pad, dtype=torch.long, device=device)
            attention = torch.zeros_like(input_ids)
            for i, seq in enumerate(sequences):
                input_ids[i, :len(seq)] = torch.tensor(seq, dtype=torch.long, device=device)
                attention[i, :len(seq)] = 1
            donor_logits = donor(input_ids=input_ids, attention_mask=attention, use_cache=False).logits.float()
            comparison_logits = comparison(input_ids=input_ids, attention_mask=attention, use_cache=False).logits.float()
            for i, (seq, begin) in enumerate(zip(sequences, starts)):
                count = max(1, len(seq) - begin - 1)
                p_log = torch.log_softmax(donor_logits[i, begin:begin + count], dim=-1)
                q_log = torch.log_softmax(comparison_logits[i, begin:begin + count], dim=-1)
                p = p_log.exp()
                kl = torch.sum(p * (p_log - q_log), dim=-1).mean()
                values.append(float(kl.cpu()))
            del donor_logits, comparison_logits
    return values


def perplexity(model: Any, tokenizer: Any, texts: Sequence[str], *, batch_size: int = 8, max_length: int = 512) -> dict[str, float]:
    """Token-weighted causal-LM perplexity on a fixed text collection."""
    torch, _, _ = torch_modules()
    model.eval()
    total_loss = 0.0
    total_tokens = 0
    with torch.inference_mode():
        for start in range(0, len(texts), batch_size):
            batch = encode_text_batch(tokenizer, texts[start:start + batch_size], max_length=max_length)
            labels = batch["input_ids"].clone()
            labels[batch["attention_mask"] == 0] = -100
            output = model(**batch, labels=labels, use_cache=False)
            n = int((labels[:, 1:] != -100).sum().item())
            if n:
                total_loss += float(output.loss.item()) * n
                total_tokens += n
    mean_nll = total_loss / max(total_tokens, 1)
    return {"mean_nll": float(mean_nll), "perplexity": float(np.exp(min(mean_nll, 80.0))), "tokens": int(total_tokens)}

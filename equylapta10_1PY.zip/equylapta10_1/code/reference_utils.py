"""Auditable statistics, integrity, model-edit, and packaging utilities.

Numerical methods follow EQUYLAPTA 10.1 Appendix A. Every returned statistic is
computed from the provided data; this module does not contain study results.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
import time
import zipfile
from pathlib import Path
from statistics import NormalDist
from typing import Any, Mapping

import numpy as np
from scipy import stats


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | Path, chunk: int = 1 << 20) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(chunk), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_json(obj: Any) -> str:
    data = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    return sha256_bytes(data)


def sha256_array(array: Any) -> str:
    contiguous = np.ascontiguousarray(np.asarray(array))
    return sha256_bytes(contiguous.tobytes())


def _z(conf: float) -> float:
    if not 0.0 < conf < 1.0:
        raise ValueError("conf must be between zero and one")
    return NormalDist().inv_cdf(0.5 + conf / 2.0)


def wilson_ci(k: int, n: int, conf: float = 0.95) -> tuple[float, float]:
    """Wilson score interval for a binomial proportion."""
    if n <= 0 or not 0 <= k <= n:
        raise ValueError("need 0 <= k <= n and n > 0")
    z = _z(conf)
    p = k / n
    z2 = z * z
    denominator = 1.0 + z2 / n
    centre = (p + z2 / (2.0 * n)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / n + z2 / (4.0 * n * n)) / denominator
    return max(0.0, centre - half), min(1.0, centre + half)


def wilson_ci_crosscheck(k: int, n: int, conf: float = 0.95) -> tuple[float, float]:
    """Independent bisection solution to the Wilson score equation."""
    if n <= 0 or not 0 <= k <= n:
        raise ValueError("need 0 <= k <= n and n > 0")
    z2 = _z(conf) ** 2
    observed = k / n

    def score(p: float) -> float:
        return (observed - p) ** 2 - z2 * p * (1.0 - p) / n

    def bisect(left: float, right: float, inside_left: bool) -> float:
        for _ in range(220):
            midpoint = (left + right) / 2.0
            if (score(midpoint) <= 0.0) == inside_left:
                left = midpoint
            else:
                right = midpoint
        return (left + right) / 2.0

    low = 0.0 if k == 0 else bisect(0.0, observed, False)
    high = 1.0 if k == n else bisect(observed, 1.0, True)
    return low, high


def clopper_pearson_ci(k: int, n: int, conf: float = 0.95) -> tuple[float, float]:
    """Two-sided exact binomial interval (Clopper–Pearson)."""
    if n <= 0 or not 0 <= k <= n:
        raise ValueError("need 0 <= k <= n and n > 0")
    tail = (1.0 - conf) / 2.0
    low = 0.0 if k == 0 else float(stats.beta.ppf(tail, k, n - k + 1))
    high = 1.0 if k == n else float(stats.beta.ppf(1.0 - tail, k + 1, n - k))
    return low, high


def mcnemar_exact(b: int, c: int) -> float:
    """Exact two-sided McNemar test from discordant counts b and c."""
    if b < 0 or c < 0:
        raise ValueError("discordant counts must be non-negative")
    total = b + c
    if total == 0:
        return 1.0
    return float(min(1.0, 2.0 * stats.binom.cdf(min(b, c), total, 0.5)))


def discordant_counts(x: Any, y: Any) -> tuple[int, int]:
    """Return b=(x=1,y=0), c=(x=0,y=1) for paired binary arrays."""
    xa = np.asarray(x, dtype=int).reshape(-1)
    ya = np.asarray(y, dtype=int).reshape(-1)
    if xa.shape != ya.shape:
        raise ValueError("paired arrays must have identical shapes")
    if not np.isin(xa, [0, 1]).all() or not np.isin(ya, [0, 1]).all():
        raise ValueError("paired outcomes must be binary")
    b = int(np.logical_and(xa == 1, ya == 0).sum())
    c = int(np.logical_and(xa == 0, ya == 1).sum())
    return b, c


def min_successes_for_lower_bound(n: int, threshold: float = 0.90, conf: float = 0.95) -> int | None:
    """Smallest k for which the Wilson lower bound reaches threshold."""
    if n <= 0:
        raise ValueError("n must be positive")
    if not 0.0 <= threshold <= 1.0:
        raise ValueError("threshold must be in [0, 1]")
    low, high = 0, n
    while low < high:
        mid = (low + high) // 2
        if wilson_ci(mid, n, conf)[0] >= threshold:
            high = mid
        else:
            low = mid + 1
    return low if wilson_ci(low, n, conf)[0] >= threshold else None


def bootstrap_diff_ci(x: Any, y: Any, n_boot: int = 10000, conf: float = 0.95, seed: int = 1010) -> tuple[float, float, float]:
    """Paired bootstrap CI for mean(x-y), resampling prompts with replacement."""
    xa = np.asarray(x, dtype=float).reshape(-1)
    ya = np.asarray(y, dtype=float).reshape(-1)
    if xa.shape != ya.shape or xa.size == 0:
        raise ValueError("paired arrays must have the same non-zero length")
    if n_boot < 1:
        raise ValueError("n_boot must be positive")
    differences = xa - ya
    rng = np.random.default_rng(seed)
    estimates = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        estimates[i] = differences[rng.integers(0, differences.size, differences.size)].mean()
    tail = (1.0 - conf) / 2.0
    return float(differences.mean()), float(np.quantile(estimates, tail)), float(np.quantile(estimates, 1.0 - tail))


def distinct2(tokens: Any) -> float:
    """Distinct bigrams divided by all bigrams; strings are whitespace-tokenized."""
    if isinstance(tokens, str):
        tokens = tokens.split()
    seq = list(tokens)
    if len(seq) < 2:
        return 0.0
    bigrams = zip(seq[:-1], seq[1:])
    return len(set(bigrams)) / (len(seq) - 1)


def agree(label: Any, d2: float, min_distinct2: float = 0.5) -> int:
    """Phenotype D agreement: detector positive and continuation has sufficient diversity."""
    return int(int(label) == 1 and float(d2) >= min_distinct2)


def token_match_frac(a_ids: Any, b_ids: Any) -> float:
    a = list(a_ids)
    b = list(b_ids)
    denominator = max(len(a), len(b))
    if denominator == 0:
        return 1.0
    common = min(len(a), len(b))
    return sum(int(a[i] == b[i]) for i in range(common)) / denominator


def ngrams13(text: str) -> set[str]:
    words = text.split()
    return {" ".join(words[i:i + 13]) for i in range(max(0, len(words) - 12))}


def excess_kurtosis(values: Any) -> float:
    array = np.asarray(values, dtype=np.float64).ravel()
    if array.size < 4:
        return float("nan")
    mean = array.mean()
    variance = ((array - mean) ** 2).mean()
    if variance <= 0.0:
        return float("nan")
    return float(((array - mean) ** 4).mean() / (variance ** 2) - 3.0)


def init_signature_test(w: Any, init_w: Any | None = None, kurt_tol: float = 0.15) -> dict[str, Any]:
    """Flag zero or likely untouched uniform-default tensors, with evidence fields."""
    array = np.asarray(w.detach().cpu().numpy() if hasattr(w, "detach") else w, dtype=np.float64)
    if array.size == 0:
        raise ValueError("weight tensor cannot be empty")
    kurtosis = excess_kurtosis(array)
    out: dict[str, Any] = {
        "shape": list(array.shape), "max_abs": float(np.abs(array).max()),
        "excess_kurtosis": kurtosis,
    }
    rel = None
    if init_w is not None:
        initial = np.asarray(init_w.detach().cpu().numpy() if hasattr(init_w, "detach") else init_w, dtype=np.float64)
        if initial.shape != array.shape:
            raise ValueError("initial and final tensors must have the same shape")
        rel = float(np.linalg.norm(array - initial) / (np.linalg.norm(initial) + 1e-12))
    out["rel_dist_from_init"] = rel
    all_zero = bool(np.max(np.abs(array)) == 0.0)
    bound_ok = False
    if array.ndim >= 2:
        bound_ok = any(out["max_abs"] <= 1.0 / math.sqrt(int(dim)) + 1e-9 for dim in array.shape if dim > 0)
    kurtosis_ok = bool(np.isfinite(kurtosis) and abs(kurtosis + 1.2) <= kurt_tol)
    out["looks_like_init"] = bool((rel is not None and rel < 1e-3) or all_zero or (bound_ok and kurtosis_ok))
    return out


def _as_numpy(value: Any) -> np.ndarray:
    if hasattr(value, "detach"):
        return value.detach().cpu().numpy()
    if hasattr(value, "cpu") and hasattr(value, "numpy"):
        return value.cpu().numpy()
    return np.asarray(value)


def weight_diff_report(state_a: Mapping[str, Any], state_b: Mapping[str, Any]) -> dict[str, Any]:
    """Compare state dictionaries bitwise and report per-tensor hashes/differences."""
    report: dict[str, Any] = {}
    changed: list[str] = []
    names = sorted(set(state_a) | set(state_b))
    for name in names:
        if name not in state_a or name not in state_b:
            report[name] = {"changed": True, "reason": "missing in one state"}
            changed.append(name)
            continue
        before = _as_numpy(state_a[name])
        after = _as_numpy(state_b[name])
        equal = before.shape == after.shape and before.dtype == after.dtype and np.array_equal(before, after)
        if equal:
            max_diff: float | None = 0.0
        elif before.shape == after.shape:
            max_diff = float(np.max(np.abs(before.astype(np.float64) - after.astype(np.float64))))
        else:
            max_diff = None
        report[name] = {
            "changed": not equal, "max_abs_diff": max_diff,
            "sha256_before": sha256_array(before), "sha256_after": sha256_array(after),
        }
        if not equal:
            changed.append(name)
    return {"tensors": report, "changed": changed, "n_tensors": len(names)}


def make_block_output_hook(vector: Any, alpha_abs: float):
    """Create a GPT-NeoX block hook that steers every token position."""
    import torch
    vector_tensor = torch.as_tensor(vector)
    scale = float(alpha_abs)

    def hook(module: Any, inputs: Any, output: Any) -> Any:
        if isinstance(output, tuple):
            hidden = output[0]
            if hidden.shape[-1] != vector_tensor.numel():
                raise ValueError("steering vector dimension does not match block output")
            delta = (scale * vector_tensor).to(device=hidden.device, dtype=hidden.dtype)
            return (hidden + delta,) + tuple(output[1:])
        if not torch.is_tensor(output):
            raise TypeError("block output must be a tensor or tuple with hidden states first")
        if output.shape[-1] != vector_tensor.numel():
            raise ValueError("steering vector dimension does not match block output")
        delta = (scale * vector_tensor).to(device=output.device, dtype=output.dtype)
        return output + delta
    return hook


def fold_bias(model: Any, layer: int, vector: Any, alpha_abs: float) -> str:
    """Fold a constant residual edit into GPT-NeoX's post-MLP output bias."""
    import torch
    bias = model.gpt_neox.layers[layer].mlp.dense_4h_to_h.bias
    vector_tensor = torch.as_tensor(vector, device=bias.device, dtype=bias.dtype).reshape(-1)
    if vector_tensor.numel() != bias.numel():
        raise ValueError("steering vector dimension does not match target bias")
    with torch.no_grad():
        bias.add_(float(alpha_abs) * vector_tensor)
    return f"gpt_neox.layers.{layer}.mlp.dense_4h_to_h.bias"


def _walk(root: str | Path) -> list[str]:
    base = Path(root)
    files: list[str] = []
    ignored_dirs = {"__pycache__", ".git", ".venv", "node_modules"}
    for current, dirs, filenames in os.walk(base):
        dirs[:] = sorted(name for name in dirs if name not in ignored_dirs)
        for filename in sorted(filenames):
            if filename.endswith((".pyc", ".pyo")):
                continue
            files.append((Path(current) / filename).relative_to(base).as_posix())
    return sorted(files)


def build_manifest(run_dir: str | Path, run_id: str) -> dict[str, Any]:
    """Write a content manifest and checksum list, excluding self-referential files."""
    base = Path(run_dir)
    base.mkdir(parents=True, exist_ok=True)
    skip = {"manifest.json", "SHA256SUMS.txt"}
    files = [name for name in _walk(base) if name not in skip]
    manifest = {
        "run_id": run_id,
        "n_files": len(files),
        "files": [
            {"path": name, "bytes": (base / name).stat().st_size, "sha256": sha256_file(base / name)}
            for name in files
        ],
    }
    (base / "manifest.json").write_text(json.dumps(manifest, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    sums = [name for name in _walk(base) if name != "SHA256SUMS.txt"]
    (base / "SHA256SUMS.txt").write_text(
        "".join(f"{sha256_file(base / name)}  {run_id}/{name}\n" for name in sums), encoding="utf-8"
    )
    return manifest


def make_zip(run_dir: str | Path, run_id: str, zip_path: str | Path) -> str:
    """Create a sorted archive with stable timestamps and a run-id top folder."""
    base = Path(run_dir)
    target = Path(zip_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for rel in _walk(base):
            info = zipfile.ZipInfo(f"{run_id}/{rel}", date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, (base / rel).read_bytes())
    return str(target)


def package_and_copy(run_dir: str | Path, run_id: str, drive_root: str | Path, tmp_dir: str | Path = "/content") -> dict[str, Any]:
    """Build, verify, copy, and re-verify the deterministic archive on Drive."""
    run_dir = Path(run_dir)
    drive_root = Path(drive_root)
    tmp_dir = Path(tmp_dir)
    drive_root.mkdir(parents=True, exist_ok=True)
    tmp_dir.mkdir(parents=True, exist_ok=True)
    manifest = build_manifest(run_dir, run_id)
    local_zip = tmp_dir / f"{run_id}.zip"
    make_zip(run_dir, run_id, local_zip)
    with zipfile.ZipFile(local_zip) as archive:
        local_testzip = archive.testzip()
        local_listing = sorted(item.filename for item in archive.infolist() if not item.is_dir())
    expected = sorted([f"{run_id}/{item['path']}" for item in manifest["files"]] + [f"{run_id}/manifest.json", f"{run_id}/SHA256SUMS.txt"])
    local_sha = sha256_file(local_zip)
    destination = drive_root / f"{run_id}.zip"
    if destination.exists():
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup = drive_root / f"{run_id}_prev_{timestamp}.zip"
        suffix = 1
        while backup.exists():
            backup = drive_root / f"{run_id}_prev_{timestamp}_{suffix}.zip"
            suffix += 1
        destination.rename(backup)
    drive_sha: str | None = None
    drive_testzip: str | None = "missing"
    drive_listing: list[str] = []
    copied_ok = False
    for _attempt in range(2):
        shutil.copy2(local_zip, destination)
        descriptor = os.open(destination, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        drive_sha = sha256_file(destination)
        with zipfile.ZipFile(destination) as archive:
            drive_testzip = archive.testzip()
            drive_listing = sorted(item.filename for item in archive.infolist() if not item.is_dir())
        copied_ok = drive_sha == local_sha and drive_testzip is None
        if copied_ok:
            break
        destination.unlink(missing_ok=True)
    exists = destination.exists()
    result = {
        "run_id": run_id, "local_zip": str(local_zip), "drive_zip": str(destination),
        "bytes": destination.stat().st_size if exists else None,
        "local_sha256": local_sha, "drive_sha256": drive_sha,
        "sha_match": drive_sha == local_sha, "testzip_ok": drive_testzip is None and local_testzip is None,
        "zip_matches_manifest": drive_listing == expected, "local_listing": local_listing,
        "file_listing": drive_listing,
        "status": "OK" if copied_ok and drive_listing == expected else "FAILED_PACKAGING",
    }
    return result


def write_drive_verification(result: dict[str, Any], drive_root: str | Path, run_id: str) -> None:
    """Write sidecar checksum and verification details beside the archive."""
    root = Path(drive_root)
    root.mkdir(parents=True, exist_ok=True)
    (root / f"{run_id}_SHA256.txt").write_text(f"{result['drive_sha256']}  {run_id}.zip\n", encoding="utf-8")
    lines = [
        f"run_id: {run_id}", f"drive_path: {result['drive_zip']}", f"bytes: {result['bytes']}",
        f"local_sha256: {result['local_sha256']}", f"drive_sha256: {result['drive_sha256']}",
        f"sha_match: {result['sha_match']}", f"testzip_ok: {result['testzip_ok']}",
        f"zip_matches_manifest: {result['zip_matches_manifest']}", f"status: {result['status']}",
        f"files_in_zip: {len(result['file_listing'])}", "", "file listing:", *result["file_listing"],
    ]
    (root / f"{run_id}_DRIVE_VERIFICATION.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

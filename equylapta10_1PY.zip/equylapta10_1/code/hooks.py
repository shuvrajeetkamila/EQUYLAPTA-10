"""GPT-NeoX residual-stream steering hooks and surgery helpers."""
from __future__ import annotations

import contextlib
from typing import Any, Iterable

from reference_utils import fold_bias, make_block_output_hook


def get_neox_blocks(model: Any):
    """Return GPT-NeoX transformer blocks or raise a helpful architecture error."""
    try:
        return model.gpt_neox.layers
    except AttributeError as exc:
        raise TypeError("model must expose model.gpt_neox.layers (GPT-NeoX architecture)") from exc


def attach_steering_hook(model: Any, layer: int, vector: Any, alpha_abs: float):
    """Attach one block-output hook; caller owns and must remove the returned handle."""
    blocks = get_neox_blocks(model)
    if not 0 <= int(layer) < len(blocks):
        raise IndexError(f"layer {layer} is outside [0, {len(blocks) - 1}]")
    return blocks[int(layer)].register_forward_hook(make_block_output_hook(vector, alpha_abs))


@contextlib.contextmanager
def steering_context(model: Any, layer: int, vector: Any, alpha_abs: float):
    """Temporarily steer every position (including autoregressive generated tokens)."""
    handle = attach_steering_hook(model, layer, vector, alpha_abs)
    try:
        yield model
    finally:
        handle.remove()


@contextlib.contextmanager
def multiple_steering_context(model: Any, edits: Iterable[tuple[int, Any, float]]):
    """Install a set of layer-local edits and remove every hook even on exceptions."""
    handles = []
    try:
        for layer, vector, alpha_abs in edits:
            handles.append(attach_steering_hook(model, layer, vector, alpha_abs))
        yield model
    finally:
        for handle in reversed(handles):
            handle.remove()


def add_folded_edit(model: Any, layer: int, vector: Any, alpha_abs: float) -> str:
    """Apply the declared edit to the GPT-NeoX MLP output bias in place."""
    get_neox_blocks(model)
    return fold_bias(model, layer, vector, alpha_abs)

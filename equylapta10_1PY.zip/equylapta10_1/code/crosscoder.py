"""Two-branch sparse crosscoder for paired recipient/donor residual activations."""
from __future__ import annotations

from typing import Any


def torch_components():
    try:
        import torch
        from torch import nn
        from torch.nn import functional as F
    except ImportError as exc:
        raise RuntimeError(f"PyTorch is required for the crosscoder: {exc}") from exc
    return torch, nn, F


_torch, _nn, _F = torch_components()


class SparseCrosscoder(_nn.Module):
    """Separate encoders/decoders whose latent coordinates are shared by both models."""

    def __init__(self, hidden_dim: int, latent_dim: int):
        super().__init__()
        self.hidden_dim = int(hidden_dim)
        self.latent_dim = int(latent_dim)
        if self.hidden_dim <= 0 or self.latent_dim < 2:
            raise ValueError("crosscoder dimensions must be positive")
        self.encoder_recipient = _nn.Linear(hidden_dim, latent_dim, bias=True)
        self.encoder_donor = _nn.Linear(hidden_dim, latent_dim, bias=True)
        self.decoder_recipient = _nn.Linear(latent_dim, hidden_dim, bias=False)
        self.decoder_donor = _nn.Linear(latent_dim, hidden_dim, bias=False)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        _nn.init.kaiming_uniform_(self.encoder_recipient.weight, a=5 ** 0.5)
        _nn.init.kaiming_uniform_(self.encoder_donor.weight, a=5 ** 0.5)
        _nn.init.zeros_(self.encoder_recipient.bias)
        _nn.init.zeros_(self.encoder_donor.bias)
        _nn.init.normal_(self.decoder_recipient.weight, mean=0.0, std=self.hidden_dim ** -0.5)
        _nn.init.normal_(self.decoder_donor.weight, mean=0.0, std=self.hidden_dim ** -0.5)
        with _torch.no_grad():
            self.decoder_recipient.weight.div_(self.decoder_recipient.weight.norm(dim=1, keepdim=True).clamp_min(1e-8))
            self.decoder_donor.weight.div_(self.decoder_donor.weight.norm(dim=1, keepdim=True).clamp_min(1e-8))

    def encode_recipient(self, values):
        return _F.relu(self.encoder_recipient(values))

    def encode_donor(self, values):
        return _F.relu(self.encoder_donor(values))

    def decode_recipient(self, latent):
        return self.decoder_recipient(latent)

    def decode_donor(self, latent):
        return self.decoder_donor(latent)

    def forward(self, recipient_values, donor_values):
        recipient_latent = self.encode_recipient(recipient_values)
        donor_latent = self.encode_donor(donor_values)
        return {
            "recipient_latent": recipient_latent,
            "donor_latent": donor_latent,
            "recipient_reconstruction": self.decode_recipient(recipient_latent),
            "donor_reconstruction": self.decode_donor(donor_latent),
        }

    def decoder_directions(self, model: str = "recipient"):
        if model == "recipient":
            return self.decoder_recipient.weight.T
        if model == "donor":
            return self.decoder_donor.weight.T
        raise ValueError("model must be recipient or donor")


def crosscoder_loss(module: SparseCrosscoder, recipient_values: Any, donor_values: Any, sparsity: float = 1e-4):
    """MSE reconstruction plus decoder-norm-weighted L1 activation sparsity."""
    torch, _, F = torch_components()
    outputs = module(recipient_values, donor_values)
    rec_recon = outputs["recipient_reconstruction"]
    don_recon = outputs["donor_reconstruction"]
    rec_mse = F.mse_loss(rec_recon, recipient_values)
    don_mse = F.mse_loss(don_recon, donor_values)
    rec_norm = module.decoder_recipient.weight.norm(dim=0).detach()
    don_norm = module.decoder_donor.weight.norm(dim=0).detach()
    rec_sparse = (outputs["recipient_latent"].abs() * rec_norm).mean()
    don_sparse = (outputs["donor_latent"].abs() * don_norm).mean()
    total = rec_mse + don_mse + float(sparsity) * (rec_sparse + don_sparse)
    return total, {
        "loss": float(total.detach().cpu()),
        "mse_recipient": float(rec_mse.detach().cpu()),
        "mse_donor": float(don_mse.detach().cpu()),
        "l0_recipient": float((outputs["recipient_latent"] > 0).float().sum(dim=1).mean().detach().cpu()),
        "l0_donor": float((outputs["donor_latent"] > 0).float().sum(dim=1).mean().detach().cpu()),
    }

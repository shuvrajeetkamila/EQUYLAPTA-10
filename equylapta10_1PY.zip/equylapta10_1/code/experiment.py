"""Executable data/model phases P1-P9 and reproducibility re-run.

The routines require the specified Colab T4, mounted Google Drive, and optional ML
packages. They fail closed before test access if any precondition is absent.
"""
from __future__ import annotations

import copy
import csv
import hashlib
import json
import math
import os
import random
import re
import shutil
import time
import traceback
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np

from common import (
    DEFAULTS, DRIVE_ROOT, RUN_DIR, RUN_ID, WORK_DIR, append_jsonl,
    config_used, read_json, set_seeds, sha256_file, sha256_json, tree_sha256, utc_now, write_json,
)
from metric import MathStyleDetector, detector_metrics, score_continuation
from reference_utils import (
    distinct2, init_signature_test, sha256_array, token_match_frac,
    weight_diff_report, wilson_ci,
)
from model_utils import (
    collect_layer_activations, collect_paired_layer_activations,
    continuation_kl, encode_text_batch, experiment_device, generate_texts,
    load_model, load_tokenizer, model_layers, perplexity, torch_modules,
)


def path(rel: str) -> Path:
    return RUN_DIR / rel


def read_jsonl(filename: str) -> list[dict[str, Any]]:
    target = path(filename)
    if not target.exists():
        return []
    result = []
    with target.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                result.append(json.loads(line))
    return result


def write_jsonl(filename: str, records: Iterable[dict[str, Any]]) -> None:
    target = path(filename)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n")


def write_csv(filename: str, fields: list[str], rows: Iterable[dict[str, Any]]) -> None:
    target = path(filename)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def read_csv(filename: str) -> list[dict[str, str]]:
    target = path(filename)
    if not target.exists():
        return []
    with target.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _merge_external_artifact(entry: dict[str, Any]) -> None:
    target = path("artifacts/external_artifacts.json")
    current = read_json(target, {}) or {}
    files = list(current.get("files", []))
    files = [item for item in files if item.get("path") != entry.get("path")]
    files.append(entry)
    write_json(target, {"status": "PASS", "files": files, "updated_utc": utc_now()})


def _directory_bytes(root: Path) -> int:
    return sum(item.stat().st_size for item in root.rglob("*") if item.is_file()) if root.exists() else 0


def _stable_doc_id(source: str, index: int, text: str) -> str:
    digest = hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()[:20]
    return f"{source}:{index}:{digest}"


def _normalize_text(text: Any) -> str:
    value = str(text or "")
    value = value.replace("\x00", " ")
    value = re.sub(r"\s+", " ", value).strip()
    return value


def _to_docs(rows: Iterable[dict[str, Any]], source: str, label: int) -> list[dict[str, Any]]:
    output = []
    for index, row in enumerate(rows):
        if source == "pile":
            text = row.get("text", row.get("content", ""))
        elif source == "gsm8k":
            text = f"Question: {row.get('question', '')} Answer: {row.get('answer', '')}"
        else:
            problem = row.get("problem", row.get("question", ""))
            solution = row.get("solution", row.get("answer", ""))
            text = f"Problem: {problem} Solution: {solution}"
        text = _normalize_text(text)
        if len(text.split()) < 20:
            continue
        output.append({"doc_id": _stable_doc_id(source, index, text), "source": source, "source_label": int(label), "text": text})
    return output


def _prefix_at_sentence_boundary(text: str, tokenizer: Any, low: int = 32, high: int = 64) -> str | None:
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())
    chosen = []
    chosen_len = 0
    for sentence in sentences:
        if not sentence:
            continue
        candidate = " ".join(chosen + [sentence])
        ids = tokenizer(candidate, add_special_tokens=False, truncation=False)["input_ids"]
        if len(ids) > high:
            break
        chosen.append(sentence)
        chosen_len = len(ids)
        if chosen_len >= low:
            return " ".join(chosen)
    # A single sentence longer than the token cap has no legal boundary prefix.
    return None


def _stable_ngram_hashes(text: str, n: int = 13) -> set[int]:
    """Stable 64-bit FNV hashes for exact 13-word shingles, used for leakage checks."""
    words = text.lower().split()
    if len(words) < n:
        return set()
    word_hashes = []
    for word in words:
        digest = hashlib.blake2b(word.encode("utf-8"), digest_size=8).digest()
        word_hashes.append(int.from_bytes(digest, "little"))
    mask = (1 << 64) - 1
    output = set()
    for start in range(len(word_hashes) - n + 1):
        rolling = 1469598103934665603
        for value in word_hashes[start:start + n]:
            rolling = ((rolling ^ value) * 1099511628211) & mask
        output.add(rolling)
    return output


def _remove_leakage(pools: dict[str, list[dict[str, Any]]]) -> tuple[dict[str, list[dict[str, Any]]], dict[str, Any]]:
    priority = ["train", "val", "test_candidates", "perplexity"]
    exact_seen: set[str] = set()
    shingle_seen: set[int] = set()
    cleaned: dict[str, list[dict[str, Any]]] = {}
    removed: dict[str, dict[str, int]] = {}
    for pool_name in priority:
        kept = []
        duplicate_exact = 0
        duplicate_near = 0
        for record in pools.get(pool_name, []):
            text = record["text"]
            exact = hashlib.sha256(text.lower().encode("utf-8")).hexdigest()
            if exact in exact_seen:
                duplicate_exact += 1
                continue
            grams = _stable_ngram_hashes(text)
            if grams and not grams.isdisjoint(shingle_seen):
                duplicate_near += 1
                continue
            exact_seen.add(exact)
            shingle_seen.update(grams)
            kept.append(record)
        cleaned[pool_name] = kept
        removed[pool_name] = {"exact_hash": duplicate_exact, "13gram_near_duplicate": duplicate_near}
    overlaps = sum(item["exact_hash"] + item["13gram_near_duplicate"] for item in removed.values())
    return cleaned, {
        "method": "exact normalized-text SHA-256 plus cross-pool rolling hashes of 13-word shingles",
        "pool_priority": priority, "removed_by_pool": removed,
        "remaining_counts": {key: len(value) for key, value in cleaned.items()},
        "removed_document_count": overlaps, "exact_overlap_count_after_removal": 0,
        "near_duplicate_overlap_count_after_removal": 0,
        "hash_collision_note": "13-gram shingles use stable 64-bit BLAKE2b word hashes and a 64-bit rolling hash",
    }


def _split_docs(general: list[dict[str, Any]], math_docs: list[dict[str, Any]], tokenizer: Any, n_test: int, n_val: int, seed: int) -> dict[str, Any]:
    rng = random.Random(seed)
    general = list(general)
    math_docs = list(math_docs)
    rng.shuffle(general)
    rng.shuffle(math_docs)
    candidate_count = 2 * n_test
    needed_general = candidate_count + 500 + n_val
    if len(general) < needed_general:
        raise RuntimeError(f"general corpus has {len(general)} usable documents; {needed_general} are required by the frozen design")
    test_docs = general[:candidate_count]
    perplexity_docs = general[candidate_count:candidate_count + 500]
    val_docs = general[candidate_count + 500:candidate_count + 500 + n_val]
    train_general = general[candidate_count + 500 + n_val:]
    math_cut = max(1, int(0.9 * len(math_docs)))
    train_math = math_docs[:math_cut]
    val_math = math_docs[math_cut:]
    train = train_general + train_math
    val = val_docs + val_math
    pools = {
        "train": train, "val": val,
        "test_candidates": test_docs, "perplexity": perplexity_docs,
    }
    pools, leakage = _remove_leakage(pools)
    if len(pools["test_candidates"]) < candidate_count:
        raise RuntimeError("leakage removal left too few held-out candidate documents; no test evaluation was started")
    def with_prefix(records):
        result = []
        for record in records:
            prefix = _prefix_at_sentence_boundary(record["text"], tokenizer)
            if prefix is not None:
                result.append({**record, "prefix": prefix})
        return result
    test_prefixes = with_prefix(pools["test_candidates"])
    val_prefixes = with_prefix([record for record in pools["val"] if record["source_label"] == 0])
    if len(test_prefixes) < candidate_count:
        raise RuntimeError(f"only {len(test_prefixes)} legal test prefixes could be built; {candidate_count} are required")
    if len(val_prefixes) < n_val:
        raise RuntimeError(f"only {len(val_prefixes)} legal val prefixes could be built; {n_val} are required")
    train_records = [{**record, "prefix": _prefix_at_sentence_boundary(record["text"], tokenizer)} for record in pools["train"]]
    train_records = [record for record in train_records if record["prefix"] is not None]
    val_records = [{**record, "prefix": _prefix_at_sentence_boundary(record["text"], tokenizer)} for record in pools["val"]]
    val_records = [record for record in val_records if record["prefix"] is not None]
    return {
        "train": train_records, "val": val_records, "test_candidates": test_prefixes[:candidate_count],
        "perplexity": pools["perplexity"], "leakage": leakage,
        "counts": {"train": len(train_records), "val": len(val_records), "test_candidates": len(test_prefixes[:candidate_count]),
                   "val_neutral_prefixes": len(val_prefixes), "perplexity_documents": len(pools["perplexity"]),
                   "train_math": sum(r["source_label"] == 1 for r in train_records),
                   "train_general": sum(r["source_label"] == 0 for r in train_records)},
    }


def _load_source_corpora() -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    try:
        from datasets import get_dataset_config_names, load_dataset
    except ImportError as exc:
        raise RuntimeError(f"datasets package unavailable: {exc}") from exc
    source_log = {}
    general_ds = load_dataset("NeelNanda/pile-10k", split="train")
    general = _to_docs(general_ds, "pile", 0)
    source_log["NeelNanda/pile-10k"] = {"status": "FOUND", "documents": len(general)}
    math_docs = []
    gsm_ds = load_dataset("openai/gsm8k", "main", split="train")
    gsm_docs = _to_docs(gsm_ds, "gsm8k", 1)
    math_docs.extend(gsm_docs)
    source_log["openai/gsm8k"] = {"status": "FOUND", "documents": len(gsm_docs)}
    hendrycks_name = "EleutherAI/hendrycks_math"
    configs = get_dataset_config_names(hendrycks_name)
    hendrycks_count = 0
    for config_name in configs:
        dataset = load_dataset(hendrycks_name, config_name, split="train")
        extracted = _to_docs(dataset, "hendrycks_math", 1)
        math_docs.extend(extracted)
        hendrycks_count += len(extracted)
    source_log[hendrycks_name] = {"status": "FOUND", "configs": configs, "documents": hendrycks_count}
    # Remove exact duplicates within each source before the cross-pool audit.
    for collection in (general, math_docs):
        seen = set()
        unique = []
        for record in collection:
            key = hashlib.sha256(record["text"].lower().encode("utf-8")).hexdigest()
            if key not in seen:
                seen.add(key)
                unique.append(record)
        collection[:] = unique
    return general, math_docs, source_log


def phase_01_build_splits() -> tuple[str, dict[str, Any]]:
    cfg = read_json(path("spec/config_used.json"), config_used())
    set_seeds(int(cfg["SEED"]["value"]))
    tokenizer = load_tokenizer(cfg["RECIPIENT_MODEL"]["value"])
    general, math_docs, sources = _load_source_corpora()
    split = _split_docs(general, math_docs, tokenizer, int(cfg["N_TEST_PROMPTS"]["value"]), int(cfg["N_VAL_PROMPTS"]["value"]), int(cfg["SEED"]["value"]))
    write_jsonl("data/train_prompts.jsonl", split["train"])
    write_jsonl("data/val_prompts.jsonl", split["val"])
    write_jsonl("data/test_prompts.jsonl", split["test_candidates"])
    write_jsonl("data/perplexity_docs.jsonl", split["perplexity"])
    hashes = {name: sha256_file(path("data/" + name)) for name in ("train_prompts.jsonl", "val_prompts.jsonl", "test_prompts.jsonl", "perplexity_docs.jsonl")}
    manifest = {
        "created_utc": utc_now(), "source_datasets": sources,
        "counts": split["counts"], "test_candidates_per_planned_prompt": 2,
        "document_ids": {pool: [item["doc_id"] for item in split[pool]] for pool in ("train", "val", "test_candidates")},
        "file_sha256": hashes, "seed": int(cfg["SEED"]["value"]),
    }
    write_json(path("data/split_manifest.json"), manifest)
    write_json(path("data/leakage_check.json"), split["leakage"])
    print(json.dumps({"sources": sources, "counts": split["counts"], "split_sha256": hashes}, sort_keys=True))
    return "PASS", {"counts": split["counts"], "source_datasets": sources, "file_sha256": hashes}


def _training_segments(records: Sequence[dict[str, Any]], tokenizer: Any, max_tokens: int = 96) -> tuple[list[str], list[int]]:
    texts, labels = [], []
    for record in records:
        text = record.get("text", record.get("prefix", ""))
        if not text:
            continue
        ids = tokenizer(text, add_special_tokens=False, truncation=True, max_length=max_tokens)["input_ids"]
        segment = tokenizer.decode(ids, skip_special_tokens=True)
        if len(segment.split()) >= 5:
            texts.append(segment)
            labels.append(int(record["source_label"]))
    return texts, labels


def phase_02_build_detector() -> tuple[str, dict[str, Any]]:
    cfg = read_json(path("spec/config_used.json"), config_used())
    tokenizer = load_tokenizer(cfg["RECIPIENT_MODEL"]["value"])
    train_records = read_jsonl("data/train_prompts.jsonl")
    val_records = read_jsonl("data/val_prompts.jsonl")
    train_texts, train_labels = _training_segments(train_records, tokenizer)
    val_texts, val_labels = _training_segments(val_records, tokenizer, max_tokens=48)
    candidates = []
    for c_value in (0.5, 1.0, 2.0, 4.0, 8.0):
        detector = MathStyleDetector(seed=int(cfg["SEED"]["value"]), c_value=c_value).fit(train_texts, train_labels)
        metrics = detector_metrics(detector, val_texts, val_labels)
        candidates.append((metrics["balanced_accuracy"], -c_value, detector, metrics))
    _, _, best, metrics = max(candidates, key=lambda item: (item[0], item[1]))
    model_path = path("artifacts/detector/math_style_detector.joblib")
    model_sha = best.save(model_path)
    definition = {
        "definition": "TF-IDF word/punctuation unigram-bigram features and balanced logistic regression",
        "fit_pool": "train only", "validation_pool": "val source labels only",
        "seed": int(cfg["SEED"]["value"]), "c_value": best.c_value,
        "positive_label": 1, "negative_label": 0, "model_sha256": model_sha,
        "frozen_utc": utc_now(),
    }
    write_json(path("artifacts/detector/detector_definition.json"), definition)
    write_json(path("artifacts/detector/detector_validation.json"), metrics)
    misses = []
    hits = []
    predictions = metrics["predictions"]
    for index, (segment, truth, predicted) in enumerate(zip(val_texts, val_labels, predictions)):
        target = hits if predicted == int(truth) else misses
        if len(target) < 5:
            target.append({"validation_index": index, "source_label": int(truth), "predicted_label": int(predicted), "text": segment})
    write_json(path("artifacts/detector/detector_examples.json"), {"hits": hits, "misses": misses})
    result_status = "PASS" if metrics["balanced_accuracy"] >= 0.95 else "FAIL"
    print(json.dumps({"status": result_status, "balanced_accuracy": metrics["balanced_accuracy"], "n": metrics["n"], "c_value": best.c_value}, sort_keys=True))
    return result_status, {"validation": {k: v for k, v in metrics.items() if k != "predictions"}, "model_sha256": model_sha}


def _state_hash(state_dict: Any) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(state_dict.items()):
        array = tensor.detach().cpu().contiguous().numpy()
        digest.update(name.encode("utf-8") + b"\0")
        digest.update(array.tobytes())
    return digest.hexdigest()


def _load_detector():
    return MathStyleDetector.load(path("artifacts/detector/math_style_detector.joblib"))


def _filter_donor_positive(model: Any, tokenizer: Any, detector: MathStyleDetector, prompts: Sequence[dict[str, Any]], max_count: int | None = None) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    texts = [item.get("prefix", item.get("text", "")) for item in prompts]
    generations = generate_texts(model, tokenizer, texts, max_new_tokens=int(DEFAULTS["MAX_NEW_TOKENS"]), batch_size=int(DEFAULTS["BATCH_SIZE"]), seed=int(DEFAULTS["SEED"]))
    keep, all_rows = [], []
    for prompt, generated in zip(prompts, generations):
        scored = score_continuation(detector, generated["output"])
        row = {**prompt, **generated, **scored}
        all_rows.append(row)
        if scored["label"] == 1:
            keep.append(row)
            if max_count is not None and len(keep) >= max_count:
                break
    return keep, all_rows


def phase_03_build_donor() -> tuple[str, dict[str, Any]]:
    torch, _, AutoTokenizer = torch_modules()
    from transformers import AutoModelForCausalLM
    cfg = read_json(path("spec/config_used.json"), config_used())
    seed = int(cfg["SEED"]["value"])
    set_seeds(seed)
    model_name = cfg["RECIPIENT_MODEL"]["value"]
    tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=True)
    tokenizer.padding_side = "left"
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    recipient = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch.float32).to(experiment_device()).eval()
    donor = copy.deepcopy(recipient).train()
    original_hash = _state_hash(recipient.state_dict())
    train_math = [row["text"] for row in read_jsonl("data/train_prompts.jsonl") if int(row["source_label"]) == 1]
    val_neutral = [row for row in read_jsonl("data/val_prompts.jsonl") if int(row["source_label"]) == 0]
    detector = _load_detector()
    if not train_math or not val_neutral:
        raise RuntimeError("donor training requires train-pool math text and neutral validation prefixes")
    learning_rate = float(os.environ.get("EQUYLAPTA_DONOR_LR", "0.00005"))
    requested_steps = int(os.environ.get("EQUYLAPTA_DONOR_STEPS", "400"))
    batch = int(os.environ.get("EQUYLAPTA_DONOR_BATCH", "8"))
    optimizer = torch.optim.AdamW(donor.parameters(), lr=learning_rate, weight_decay=0.0)
    rng = random.Random(seed)
    history = []
    for step in range(1, requested_steps + 1):
        selected = [train_math[rng.randrange(len(train_math))] for _ in range(batch)]
        inputs = tokenizer(selected, return_tensors="pt", padding=True, truncation=True, max_length=128).to(experiment_device())
        labels = inputs["input_ids"].clone()
        labels[inputs["attention_mask"] == 0] = -100
        optimizer.zero_grad(set_to_none=True)
        loss = donor(**inputs, labels=labels, use_cache=False).loss
        loss.backward()
        torch.nn.utils.clip_grad_norm_(donor.parameters(), 1.0)
        optimizer.step()
        history.append({"step": step, "loss": float(loss.detach().cpu())})
        if step % 50 == 0 or step == requested_steps:
            candidate = val_neutral[:min(200, len(val_neutral))]
            positive, all_outputs = _filter_donor_positive(donor, tokenizer, detector, candidate)
            rate = len(positive) / max(1, len(candidate))
            print(f"donor_step={step} train_loss={history[-1]['loss']:.6f} val_exhibit_rate={rate:.6f}")
            if rate >= 0.95:
                break
    donor.eval()
    final_hash = _state_hash(donor.state_dict())
    diff = weight_diff_report(recipient.state_dict(), donor.state_dict())
    changed_tensors = diff["changed"]
    changed = bool(changed_tensors)
    donor_dir = DRIVE_ROOT / "heavy_artifacts" / "donor_model"
    donor_dir.mkdir(parents=True, exist_ok=True)
    donor.save_pretrained(donor_dir, safe_serialization=True)
    tokenizer.save_pretrained(donor_dir)
    donor_hash = _state_hash(donor.state_dict())
    write_json(path("artifacts/donor_build/recipient_vs_donor_diff.json"), diff)
    _merge_external_artifact({"path": str(donor_dir), "bytes": _directory_bytes(donor_dir),
                              "sha256": tree_sha256(donor_dir), "state_sha256": donor_hash,
                              "kind": "planted_donor_checkpoint"})
    val_candidate = val_neutral[:min(200, len(val_neutral))]
    donor_positive, donor_all = _filter_donor_positive(donor, tokenizer, detector, val_candidate)
    exhibit_rate = len(donor_positive) / max(1, len(val_candidate))
    report = {
        "status": "PASS" if changed and exhibit_rate >= 0.95 else "FAIL",
        "design": "planted_donor", "recipient_model": model_name,
        "donor_path": str(donor_dir), "recipient_state_sha256": original_hash,
        "donor_state_sha256": donor_hash, "changed_tensors": changed_tensors,
        "val_exhibit_rate": exhibit_rate, "candidate_exhibit_rate": None,
        "validation_n": len(val_candidate), "training_steps": len(history),
        "learning_rate": learning_rate, "batch_sequences": batch,
        "training_history": history, "trained_copy_only": True,
        "recipe_file": "artifacts/donor_build/donor_recipe.json",
        "created_utc": utc_now(),
    }
    write_json(path("artifacts/donor_build/donor_build_report.json"), report)
    write_json(path("artifacts/donor_build/donor_recipe.json"), {k: report[k] for k in ("design", "recipient_model", "training_steps", "learning_rate", "batch_sequences", "trained_copy_only", "recipient_state_sha256", "donor_state_sha256")})
    return report["status"], {"val_exhibit_rate": exhibit_rate, "changed": changed, "steps": len(history), "donor_path": str(donor_dir)}


def _load_pair_and_tokenizer():
    cfg = read_json(path("spec/config_used.json"), config_used())
    tokenizer = load_tokenizer(cfg["RECIPIENT_MODEL"]["value"])
    recipient = load_model(cfg["RECIPIENT_MODEL"]["value"])
    donor_path = DRIVE_ROOT / "heavy_artifacts" / "donor_model"
    if not donor_path.exists():
        raise RuntimeError(f"donor checkpoint is missing: {donor_path}")
    donor = load_model(str(donor_path), local_files_only=True)
    return recipient, donor, tokenizer, cfg


def _neutral_val_records() -> list[dict[str, Any]]:
    return [row for row in read_jsonl("data/val_prompts.jsonl") if int(row.get("source_label", 0)) == 0 and row.get("prefix")]


def _positive_donor_val(recipient: Any, donor: Any, tokenizer: Any, limit: int = 200) -> tuple[list[dict[str, Any]], float]:
    detector = _load_detector()
    candidates = _neutral_val_records()
    rows = generate_texts(donor, tokenizer, [row["prefix"] for row in candidates], max_new_tokens=48, batch_size=32)
    all_count = len(candidates)
    positives = []
    for prompt, generated in zip(candidates, rows):
        score = score_continuation(detector, generated["output"])
        if score["label"] == 1:
            positives.append({**prompt, **generated, **score})
    return positives[:limit], len(positives) / max(all_count, 1)


def _alpha_grid() -> list[float]:
    return [0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]


def _generate_scores(model: Any, tokenizer: Any, detector: MathStyleDetector, prompts: Sequence[dict[str, Any]], edit: tuple[int, Any, float] | None = None, batch_size: int = 32) -> tuple[list[dict[str, Any]], float]:
    generated = generate_texts(model, tokenizer, [row["prefix"] for row in prompts], max_new_tokens=48, batch_size=batch_size, edit=edit)
    scored = []
    for prompt, output in zip(prompts, generated):
        score = score_continuation(detector, output["output"])
        scored.append({**prompt, **output, **score})
    rate = sum(row["agree"] for row in scored) / max(1, len(scored))
    return scored, rate


def phase_04_layer_sweep() -> tuple[str, dict[str, Any]]:
    recipient, donor, tokenizer, cfg = _load_pair_and_tokenizer()
    train_records = read_jsonl("data/train_prompts.jsonl")
    train_texts = [row["text"] for row in train_records[:4000]]
    if not train_texts:
        raise RuntimeError("no train-pool text is available for the layer sweep")
    layers = list(range(min(6, len(model_layers(recipient)))))
    rec_acts, don_acts = collect_paired_layer_activations(
        recipient, donor, tokenizer, train_texts, layers, max_tokens=200_000, batch_size=8, max_length=128,
    )
    means: dict[int, np.ndarray] = {}
    norms: dict[int, float] = {}
    for layer in layers:
        difference = don_acts[layer].mean(axis=0) - rec_acts[layer].mean(axis=0)
        norm = float(np.linalg.norm(difference))
        if norm <= 1e-12:
            raise RuntimeError(f"donor-recipient mean activation difference is degenerate at layer {layer}")
        means[layer] = difference / norm
        norms[layer] = float(np.median(np.linalg.norm(rec_acts[layer], axis=1)))
    prompts, donor_rate = _positive_donor_val(recipient, donor, tokenizer, limit=200)
    if len(prompts) < 100:
        raise RuntimeError(f"only {len(prompts)} donor-positive val prompts remain for the frozen sweep")
    detector = _load_detector()
    records = []
    for layer in layers:
        for alpha_rel in _alpha_grid():
            alpha_abs = alpha_rel * norms[layer]
            _, rate = _generate_scores(recipient, tokenizer, detector, prompts, (layer, means[layer], alpha_abs), batch_size=32)
            k = int(round(rate * len(prompts)))
            interval = wilson_ci(k, len(prompts))
            records.append({"stage": "layer_sweep", "layer": layer, "k": "", "alpha_rel": alpha_rel, "alpha_abs": alpha_abs,
                            "n": len(prompts), "k_success": k, "agreement": rate,
                            "wilson_low": interval[0], "wilson_high": interval[1], "ppl_ratio": "",
                            "ppl_allowed": "", "median_donor_nll_A": "", "median_donor_nll_F": "",
                            "distinct2_F": "", "distinct2_donor": "", "collateral_pass": ""})
    sweep_fields = ["stage", "layer", "k", "alpha_rel", "alpha_abs", "n", "k_success", "agreement", "wilson_low", "wilson_high",
                    "ppl_ratio", "ppl_allowed", "median_donor_nll_A", "median_donor_nll_F", "distinct2_F", "distinct2_donor", "collateral_pass"]
    write_csv("results/val_alpha_layer_sweep.csv", sweep_fields, records)
    best_by_layer = {layer: max((row["agreement"] for row in records if row["layer"] == layer), default=0.0) for layer in layers}
    chosen = max(layers, key=lambda layer: (best_by_layer[layer], -layer))
    best_values = list(best_by_layer.values())
    layer_agnostic = max(best_values) - min(best_values) < 0.30
    np.savez(path("artifacts/vectors/layer_sweep_vectors.npz"), **{f"layer_{layer}": means[layer] for layer in layers}, **{f"median_norm_{layer}": np.asarray(norms[layer]) for layer in layers})
    choice = {"selected_layer": chosen, "best_val_agreement_by_layer": {str(k): v for k, v in best_by_layer.items()},
              "median_residual_norm_by_layer": {str(k): v for k, v in norms.items()},
              "layer_agnostic": layer_agnostic, "val_donor_exhibit_rate": donor_rate,
              "val_prompts": len(prompts), "vectors_file_sha256": sha256_file(path("artifacts/vectors/layer_sweep_vectors.npz"))}
    write_json(path("results/layer_choice.json"), choice)
    write_json(path("results/val_layer_specificity.json"), {"layer_agnostic": layer_agnostic, "agreement_range": max(best_values) - min(best_values), "best_by_layer": choice["best_val_agreement_by_layer"]})
    print(json.dumps(choice, sort_keys=True))
    return "PASS", choice


def _text_windows(texts: Sequence[str], tokenizer: Any, window_tokens: int = 512) -> list[str]:
    windows = []
    for text in texts:
        ids = tokenizer(text, add_special_tokens=False, truncation=False)["input_ids"]
        for start in range(0, len(ids), window_tokens):
            chunk = ids[start:start + window_tokens]
            if len(chunk) >= 32:
                windows.append(tokenizer.decode(chunk, skip_special_tokens=True))
    return windows


def _collect_activation_shards(model: Any, tokenizer: Any, texts: Sequence[str], layer: int, destination: Path, target_tokens: int, *, max_length: int = 512, batch_size: int = 4, shard_rows: int = 50000, prefix: str) -> dict[str, Any]:
    torch, _, _ = torch_modules()
    destination.mkdir(parents=True, exist_ok=True)
    block = model_layers(model)[layer]
    captured = {}
    handle = block.register_forward_hook(lambda module, inputs, output: captured.update({"hidden": (output[0] if isinstance(output, tuple) else output).detach()}))
    shards = []
    buffer = []
    buffered = 0
    total = 0
    model.eval()
    try:
        with torch.inference_mode():
            for start in range(0, len(texts), batch_size):
                batch_texts = texts[start:start + batch_size]
                if not batch_texts:
                    continue
                batch = tokenizer(list(batch_texts), return_tensors="pt", padding=True, truncation=True, max_length=max_length).to(experiment_device())
                captured.clear()
                model(**batch, use_cache=False)
                mask = batch["attention_mask"].bool()
                if mask.shape[1] > 0:
                    mask[:, 0] = False
                values = captured["hidden"][mask].float().cpu().numpy()
                remaining = target_tokens - total
                if remaining <= 0:
                    break
                values = values[:remaining]
                cursor = 0
                while cursor < len(values):
                    take = min(shard_rows - buffered, len(values) - cursor)
                    buffer.append(values[cursor:cursor + take].astype(np.float16, copy=False))
                    buffered += take
                    total += take
                    cursor += take
                    if buffered >= shard_rows:
                        shard_path = destination / f"{prefix}_{len(shards):05d}.npy"
                        np.save(shard_path, np.concatenate(buffer, axis=0), allow_pickle=False)
                        shards.append({"path": str(shard_path), "rows": buffered, "sha256": sha256_file(shard_path)})
                        buffer, buffered = [], 0
                if total >= target_tokens:
                    break
    finally:
        handle.remove()
    if buffered:
        shard_path = destination / f"{prefix}_{len(shards):05d}.npy"
        np.save(shard_path, np.concatenate(buffer, axis=0), allow_pickle=False)
        shards.append({"path": str(shard_path), "rows": buffered, "sha256": sha256_file(shard_path)})
    return {"layer": layer, "count": total, "dtype": "float16", "shards": shards}


class _ShardSampler:
    def __init__(self, record: dict[str, Any]):
        self.arrays = [np.load(item["path"], mmap_mode="r", allow_pickle=False) for item in record["shards"]]
        self.lengths = np.asarray([len(array) for array in self.arrays], dtype=np.int64)
        self.cumulative = np.cumsum(self.lengths)
        self.total = int(self.cumulative[-1]) if len(self.cumulative) else 0
        if self.total == 0:
            raise RuntimeError("crosscoder activation cache is empty")

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        indexes = rng.integers(0, self.total, size=n)
        shard_indexes = np.searchsorted(self.cumulative, indexes, side="right")
        starts = np.concatenate(([0], self.cumulative[:-1]))
        values = np.stack([self.arrays[int(si)][int(index - starts[int(si)])] for si, index in zip(shard_indexes, indexes)])
        return values.astype(np.float32, copy=False)


def _crosscoder_state_load(pathname: Path, hidden_dim: int, latent_dim: int):
    torch, _, _ = torch_modules()
    from crosscoder import SparseCrosscoder
    from safetensors.torch import load_file
    module = SparseCrosscoder(hidden_dim, latent_dim)
    state = load_file(str(pathname), device="cpu")
    module.load_state_dict(state)
    module.to(experiment_device()).eval()
    return module


def phase_05_train_crosscoder() -> tuple[str, dict[str, Any]]:
    torch, _, _ = torch_modules()
    from crosscoder import SparseCrosscoder, crosscoder_loss
    from safetensors.torch import save_file
    cfg = read_json(path("spec/config_used.json"), config_used())
    recipient, donor, tokenizer, _ = _load_pair_and_tokenizer()
    layer = int(read_json(path("results/layer_choice.json"), {})["selected_layer"])
    all_train = read_jsonl("data/train_prompts.jsonl")
    train_texts = [row["text"] for row in all_train]
    windows = _text_windows(train_texts, tokenizer, 512)
    target_tokens = int(cfg["CROSSCODER_TRAIN_TOKENS"]["value"])
    scratch = WORK_DIR / "_scratch" / f"activations_layer_{layer}"
    rec_cache = _collect_activation_shards(recipient, tokenizer, windows, layer, scratch / "recipient", target_tokens, prefix="recipient")
    don_cache = _collect_activation_shards(donor, tokenizer, windows, layer, scratch / "donor", target_tokens, prefix="donor")
    if rec_cache["count"] < target_tokens or don_cache["count"] < target_tokens:
        raise RuntimeError(f"activation token count below frozen minimum: recipient={rec_cache['count']} donor={don_cache['count']} required={target_tokens}")
    # Heavy activation shards are copied to Drive and excluded from the downloadable archive by default.
    drive_cache = DRIVE_ROOT / "heavy_artifacts" / f"activations_layer_{layer}"
    if drive_cache.exists():
        shutil.rmtree(drive_cache)
    shutil.copytree(scratch, drive_cache)
    rec_cache["shards"] = [{**item, "path": str(Path(item["path"]).relative_to(scratch))} for item in rec_cache["shards"]]
    don_cache["shards"] = [{**item, "path": str(Path(item["path"]).relative_to(scratch))} for item in don_cache["shards"]]
    _merge_external_artifact({"path": str(drive_cache), "bytes": _directory_bytes(drive_cache),
                              "sha256": tree_sha256(drive_cache), "kind": "paired_activation_shards",
                              "recipient_tokens": rec_cache["count"], "donor_tokens": don_cache["count"]})
    # Train on local scratch shards for throughput; the durable copies remain on Drive.
    rec_local = {**rec_cache, "shards": [{**item, "path": str(scratch / "recipient" / Path(item["path"]).name)} for item in rec_cache["shards"]]}
    don_local = {**don_cache, "shards": [{**item, "path": str(scratch / "donor" / Path(item["path"]).name)} for item in don_cache["shards"]]}
    rec_sampler, don_sampler = _ShardSampler(rec_local), _ShardSampler(don_local)
    hidden = int(recipient.config.hidden_size)
    latent = int(cfg["CROSSCODER_LATENTS"]["value"])
    module = SparseCrosscoder(hidden, latent).to(experiment_device())
    initial_state = {name: tensor.detach().cpu().clone() for name, tensor in module.state_dict().items()}
    optimizer = torch.optim.Adam(module.parameters(), lr=float(os.environ.get("EQUYLAPTA_CROSSCODER_LR", "0.0002")))
    batch_tokens = int(os.environ.get("EQUYLAPTA_CROSSCODER_BATCH_TOKENS", "1024"))
    steps = int(cfg["CROSSCODER_STEPS"]["value"])
    rng = np.random.default_rng(int(cfg["SEED"]["value"]))
    curves = []
    initial_sample_rec = torch.from_numpy(rec_sampler.sample(batch_tokens, rng)).to(experiment_device())
    initial_sample_don = torch.from_numpy(don_sampler.sample(batch_tokens, rng)).to(experiment_device())
    _, initial_metrics = crosscoder_loss(module, initial_sample_rec, initial_sample_don)
    best_metrics = initial_metrics
    for step in range(1, steps + 1):
        rec_batch = torch.from_numpy(rec_sampler.sample(batch_tokens, rng)).to(experiment_device())
        don_batch = torch.from_numpy(don_sampler.sample(batch_tokens, rng)).to(experiment_device())
        optimizer.zero_grad(set_to_none=True)
        loss, metrics = crosscoder_loss(module, rec_batch, don_batch, sparsity=float(os.environ.get("EQUYLAPTA_CROSSCODER_SPARSITY", "0.0001")))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(module.parameters(), 1.0)
        optimizer.step()
        best_metrics = metrics
        if step % 100 == 0 or step == 1 or step == steps:
            item = {"step": step, **metrics}
            curves.append(item)
            print(f"crosscoder_step={step} loss={metrics['loss']:.6f} l0_rec={metrics['l0_recipient']:.2f} l0_donor={metrics['l0_donor']:.2f}")
    val_general = [row["text"] for row in read_jsonl("data/val_prompts.jsonl") if int(row["source_label"]) == 0]
    val_math = [row["text"] for row in read_jsonl("data/val_prompts.jsonl") if int(row["source_label"]) == 1]
    rec_val = collect_layer_activations(recipient, tokenizer, (val_general + val_math)[:500], [layer], max_tokens=20000, batch_size=8, max_length=128)[layer]
    don_val = collect_layer_activations(donor, tokenizer, (val_general + val_math)[:500], [layer], max_tokens=20000, batch_size=8, max_length=128)[layer]
    module.eval()
    with torch.inference_mode():
        rec_values = torch.as_tensor(rec_val, dtype=torch.float32, device=experiment_device())
        don_values = torch.as_tensor(don_val, dtype=torch.float32, device=experiment_device())
        outputs = module(rec_values, don_values)
        rec_fvu = float(((rec_values - outputs["recipient_reconstruction"]) ** 2).sum() / ((rec_values - rec_values.mean(0)) ** 2).sum().clamp_min(1e-12))
        don_fvu = float(((don_values - outputs["donor_reconstruction"]) ** 2).sum() / ((don_values - don_values.mean(0)) ** 2).sum().clamp_min(1e-12))
        dead_fraction = float(((outputs["recipient_latent"] == 0).all(0) & (outputs["donor_latent"] == 0).all(0)).float().mean())
    init_signature = {}
    for name, tensor in module.state_dict().items():
        if name.endswith("weight"):
            init_signature[name] = init_signature_test(tensor, init_w=initial_state[name])
    module.eval()
    with torch.inference_mode():
        _, final_metrics = crosscoder_loss(module, initial_sample_rec, initial_sample_don)
    final_loss = final_metrics["loss"]
    health_pass = (
        all(not result["looks_like_init"] for result in init_signature.values())
        and final_loss <= 0.5 * initial_metrics["loss"]
        and rec_fvu <= 0.35 and don_fvu <= 0.35
    )
    from safetensors.torch import save_file
    weights_path = path("artifacts/crosscoder_weights.safetensors")
    save_file({name: tensor.detach().cpu().contiguous() for name, tensor in module.state_dict().items()}, str(weights_path))
    write_csv("artifacts/training_curves.csv", ["step", "loss", "mse_recipient", "mse_donor", "l0_recipient", "l0_donor", "fvu_recipient", "fvu_donor", "dead_fraction"], [
        {**row, "fvu_recipient": rec_fvu, "fvu_donor": don_fvu, "dead_fraction": dead_fraction} for row in curves
    ])
    config = {"hidden_dim": hidden, "latent_dim": latent, "layer": layer, "train_tokens": target_tokens,
              "optimizer_steps": steps, "batch_tokens": batch_tokens, "sparsity": float(os.environ.get("EQUYLAPTA_CROSSCODER_SPARSITY", "0.0001")),
              "activation_dtype": "float16", "weight_sha256": sha256_file(weights_path), "activation_cache": str(drive_cache)}
    write_json(path("artifacts/crosscoder_config.json"), config)
    health = {
        "status": "PASS" if health_pass else "FAIL", "g9_pass": health_pass,
        "g9_values": {"initial_loss": initial_metrics["loss"], "final_loss": final_loss,
                      "final_to_initial_loss_ratio": final_loss / max(initial_metrics["loss"], 1e-12),
                      "fvu_recipient": rec_fvu, "fvu_donor": don_fvu, "dead_fraction": dead_fraction,
                      "init_signature": init_signature, "trained_tokens_per_model": target_tokens,
                      "optimizer_steps": steps},
        "weight_sha256": sha256_file(weights_path), "created_utc": utc_now(),
    }
    write_json(path("artifacts/crosscoder_health.json"), health)
    return health["status"], health


def _encoded_means(module: Any, activations: np.ndarray, kind: str, batch_size: int = 8192) -> tuple[np.ndarray, np.ndarray]:
    torch, _, _ = torch_modules()
    outputs = []
    encoder = module.encode_donor if kind == "donor" else module.encode_recipient
    with torch.inference_mode():
        for start in range(0, len(activations), batch_size):
            batch = torch.as_tensor(activations[start:start + batch_size], dtype=torch.float32, device=experiment_device())
            outputs.append(encoder(batch).detach().cpu().numpy())
    joined = np.concatenate(outputs, axis=0) if outputs else np.empty((0, module.latent_dim), dtype=np.float32)
    return joined.mean(axis=0), joined


def _save_vector(name: str, vector: np.ndarray) -> dict[str, Any]:
    target = path(f"artifacts/vectors/{name}.npy")
    target.parent.mkdir(parents=True, exist_ok=True)
    np.save(target, np.asarray(vector, dtype=np.float32), allow_pickle=False)
    return {"name": name, "path": target.relative_to(RUN_DIR).as_posix(), "sha256": sha256_file(target), "l2_norm": float(np.linalg.norm(vector))}


def phase_06_select_latents() -> tuple[str, dict[str, Any]]:
    torch, _, _ = torch_modules()
    from crosscoder import SparseCrosscoder
    from safetensors.torch import load_file
    recipient, donor, tokenizer, cfg = _load_pair_and_tokenizer()
    layer = int(read_json(path("results/layer_choice.json"), {})["selected_layer"])
    cc_cfg = read_json(path("artifacts/crosscoder_config.json"), {})
    module = SparseCrosscoder(int(cc_cfg["hidden_dim"]), int(cc_cfg["latent_dim"]))
    module.load_state_dict(load_file(str(path("artifacts/crosscoder_weights.safetensors")), device="cpu"))
    module.to(experiment_device()).eval()
    train = read_jsonl("data/train_prompts.jsonl")
    math_texts = [row["text"] for row in train if int(row["source_label"]) == 1][:1000]
    general_texts = [row["text"] for row in train if int(row["source_label"]) == 0][:1000]
    math_don = collect_layer_activations(donor, tokenizer, math_texts, [layer], max_tokens=100000, batch_size=8, max_length=128)[layer]
    neutral_rec = collect_layer_activations(recipient, tokenizer, general_texts, [layer], max_tokens=100000, batch_size=8, max_length=128)[layer]
    paired_train_texts = [row["text"] for row in train[:2000]]
    paired_rec, paired_don = collect_paired_layer_activations(recipient, donor, tokenizer, paired_train_texts, [layer], max_tokens=100000, batch_size=8, max_length=128)
    _, z_math_donor = _encoded_means(module, math_don, "donor")
    _, z_general_rec = _encoded_means(module, neutral_rec, "recipient")
    mean_math_d = z_math_donor.mean(0)
    mean_general_r = z_general_rec.mean(0)
    donor_dirs = module.decoder_directions("donor").detach().cpu().numpy()
    recipient_dirs = module.decoder_directions("recipient").detach().cpu().numpy()
    donor_norm = np.linalg.norm(donor_dirs, axis=1)
    recipient_norm = np.linalg.norm(recipient_dirs, axis=1)
    rho = donor_norm / np.maximum(donor_norm + recipient_norm, 1e-12)
    activation_gap = mean_math_d - mean_general_r
    scores = rho * activation_gap
    order = np.argsort(scores)[::-1]
    top = order[:16]
    vectors = {}
    vector_meta = []
    for k in (1, 4, 16):
        chosen = top[:k]
        vector = recipient_dirs[chosen].sum(axis=0)
        norm = np.linalg.norm(vector)
        if norm <= 1e-12:
            raise RuntimeError(f"selected latent vector is degenerate at k={k}")
        vector = vector / norm
        name = f"F_k{k}"
        vectors[name] = vector
        vector_meta.append({**_save_vector(name, vector), "condition": name, "latent_ids": chosen.astype(int).tolist(), "score_sum": float(scores[chosen].sum())})
    recipient_only = np.flatnonzero(rho < 0.1)
    selected_d = recipient_only[np.argsort(mean_general_r[recipient_only])[::-1][:16]] if len(recipient_only) else np.asarray([], dtype=int)
    if len(recipient_only) >= 4:
        for d_k in (1, 4, 16):
            d_latents = selected_d[:min(d_k, len(selected_d))]
            d_vec = -recipient_dirs[d_latents].sum(axis=0)
            d_vec /= max(float(np.linalg.norm(d_vec)), 1e-12)
            d_name = f"D_k{d_k}"
            vectors[d_name] = d_vec
            vector_meta.append({**_save_vector(d_name, d_vec), "condition": "D", "latent_ids": d_latents.astype(int).tolist(), "requested_k": d_k})
    mean_diff = paired_don[layer].mean(0) - paired_rec[layer].mean(0)
    for e_k in (1, 4, 16):
        selected_dirs = recipient_dirs[top[:e_k]]
        basis, _ = np.linalg.qr(selected_dirs.T)
        e_vec = basis @ (basis.T @ mean_diff)
        e_vec /= max(float(np.linalg.norm(e_vec)), 1e-12)
        e_name = f"E_k{e_k}"
        vectors[e_name] = e_vec
        vector_meta.append({**_save_vector(e_name, e_vec), "condition": "E", "latent_ids": top[:e_k].astype(int).tolist(), "requested_k": e_k})
    layer_npz = np.load(path("artifacts/vectors/layer_sweep_vectors.npz"))
    l_vec = np.asarray(layer_npz[f"layer_{layer}"], dtype=np.float32)
    vectors["L"] = l_vec / max(float(np.linalg.norm(l_vec)), 1e-12)
    vector_meta.append({**_save_vector("L", vectors["L"]), "condition": "L"})
    rng = np.random.default_rng(int(cfg["SEED"]["value"]))
    hidden = recipient_dirs.shape[1]
    for index in range(20):
        vec = rng.normal(size=hidden).astype(np.float32)
        vec /= max(float(np.linalg.norm(vec)), 1e-12)
        vectors[f"G_{index:02d}"] = vec
        vector_meta.append({**_save_vector(f"G_{index:02d}", vec), "condition": "G", "replica": index})
    available = np.setdiff1d(np.arange(len(recipient_dirs)), top)
    if len(available) < 20:
        raise RuntimeError("crosscoder has too few non-selected latents for the frozen control set")
    random_latents = rng.choice(available, size=20, replace=False)
    for index, latent_id in enumerate(random_latents):
        vec = recipient_dirs[int(latent_id)].astype(np.float32)
        vec /= max(float(np.linalg.norm(vec)), 1e-12)
        vectors[f"I_{index:02d}"] = vec
        vector_meta.append({**_save_vector(f"I_{index:02d}", vec), "condition": "I", "replica": index, "latent_id": int(latent_id)})
    f_ref = vectors["F_k16"]
    for item in vector_meta:
        vector = vectors.get(item["name"])
        if vector is None:
            continue
        item["cosine_to_vF_k16"] = float(np.dot(vector, f_ref))
    for item in vector_meta:
        if item.get("condition") in {"G", "I"} and abs(item.get("cosine_to_vF_k16", 0.0)) >= 0.5:
            raise RuntimeError(f"negative-control vector {item['name']} is too aligned with primary direction")
    scores_doc = [{"latent_id": int(index), "score": float(scores[index]), "rho": float(rho[index]),
                   "activation_gap": float(activation_gap[index]), "recipient_decoder_norm": float(recipient_norm[index]),
                   "donor_decoder_norm": float(donor_norm[index])} for index in top]
    record = {
        "status": "PASS", "layer": layer, "top_latents": scores_doc,
        "recipient_only_latent_count": int(len(recipient_only)),
        "recipient_only_latent_ids": recipient_only.astype(int).tolist(),
        "selected_latent_ids_by_k": {str(k): top[:k].astype(int).tolist() for k in (1, 4, 16)},
        "vectors": vector_meta, "train_activation_rows": {"math_donor": len(math_don), "general_recipient": len(neutral_rec)},
        "selection_rule": "rank rho_j times mean donor-math minus recipient-neutral latent activation on train pool",
    }
    write_json(path("artifacts/selected_latents.json"), record)
    write_json(path("artifacts/vectors/vectors_index.json"), {"vectors": vector_meta, "recipient_only_latent_count": int(len(recipient_only))})
    return "PASS", {"selected_layer": layer, "top_latent_ids": top.astype(int).tolist(), "vector_count": len(vector_meta)}


def _sequence_nll(model: Any, tokenizer: Any, prompts: Sequence[str], continuation_ids: Sequence[Sequence[int]], batch_size: int = 8) -> list[float]:
    torch, _, _ = torch_modules()
    device = experiment_device()
    scores = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(prompts), batch_size):
            prompt_chunk = prompts[start:start + batch_size]
            cont_chunk = continuation_ids[start:start + batch_size]
            sequences, begins = [], []
            for prompt, continuation in zip(prompt_chunk, cont_chunk):
                prefix_ids = tokenizer(prompt, add_special_tokens=True, truncation=True, max_length=512)["input_ids"]
                continuation = list(map(int, continuation))
                if not continuation:
                    continuation = [int(tokenizer.eos_token_id)]
                sequences.append(prefix_ids + continuation)
                begins.append(len(prefix_ids))
            width = max(map(len, sequences))
            inputs = torch.full((len(sequences), width), int(tokenizer.pad_token_id), dtype=torch.long, device=device)
            attention = torch.zeros_like(inputs)
            for row, sequence in enumerate(sequences):
                inputs[row, :len(sequence)] = torch.tensor(sequence, dtype=torch.long, device=device)
                attention[row, :len(sequence)] = 1
            logits = model(input_ids=inputs, attention_mask=attention, use_cache=False).logits.float()
            log_probs = torch.log_softmax(logits, dim=-1)
            for row, (sequence, begin) in enumerate(zip(sequences, begins)):
                targets = torch.tensor(sequence[begin:], dtype=torch.long, device=device)
                start_pos = max(0, begin - 1)
                pred = log_probs[row, start_pos:start_pos + len(targets)]
                token_nll = -pred.gather(1, targets[:, None]).squeeze(1)
                scores.append(float(token_nll.mean().cpu()))
            del logits, log_probs
    return scores


def _corpus_distinct2(texts: Sequence[str]) -> float:
    tokens = []
    for text in texts:
        tokens.extend(str(text).split())
    return float(distinct2(tokens))


def _evaluate_collateral(
    recipient: Any, donor: Any, tokenizer: Any, prompts: Sequence[dict[str, Any]],
    baseline_outputs: Sequence[dict[str, Any]], donor_outputs: Sequence[dict[str, Any]],
    edited_outputs: Sequence[dict[str, Any]], layer: int, vector: np.ndarray, alpha_abs: float,
) -> dict[str, Any]:
    from hooks import steering_context
    general_docs = [row["text"] for row in read_jsonl("data/val_prompts.jsonl") if int(row["source_label"]) == 0][:200]
    base_ppl = perplexity(recipient, tokenizer, general_docs, batch_size=8)
    donor_ppl = perplexity(donor, tokenizer, general_docs, batch_size=8)
    with steering_context(recipient, layer, vector, alpha_abs):
        edit_ppl = perplexity(recipient, tokenizer, general_docs, batch_size=8)
    prompt_texts = [row["prefix"] for row in prompts]
    base_nll = _sequence_nll(donor, tokenizer, prompt_texts, [row["token_ids"] for row in baseline_outputs])
    edit_nll = _sequence_nll(donor, tokenizer, prompt_texts, [row["token_ids"] for row in edited_outputs])
    donor_d2 = _corpus_distinct2([row["output"] for row in donor_outputs])
    edit_d2 = _corpus_distinct2([row["output"] for row in edited_outputs])
    base_ratio = edit_ppl["perplexity"] / max(base_ppl["perplexity"], 1e-12)
    donor_ratio = donor_ppl["perplexity"] / max(base_ppl["perplexity"], 1e-12)
    max_ratio = max(1.25, donor_ratio)
    g7_pass = (base_ratio <= max_ratio and float(np.median(edit_nll)) <= float(np.median(base_nll)) and edit_d2 >= 0.8 * donor_d2)
    return {
        "baseline_perplexity": base_ppl, "donor_perplexity": donor_ppl, "edited_perplexity": edit_ppl,
        "edited_to_baseline_ppl_ratio": base_ratio, "donor_to_baseline_ppl_ratio": donor_ratio,
        "max_allowed_ppl_ratio": max_ratio, "median_donor_nll_baseline_outputs": float(np.median(base_nll)),
        "median_donor_nll_edited_outputs": float(np.median(edit_nll)),
        "corpus_distinct2_baseline": _corpus_distinct2([row["output"] for row in baseline_outputs]),
        "corpus_distinct2_donor": donor_d2, "corpus_distinct2_edited": edit_d2,
        "g7_pass": bool(g7_pass),
    }


def phase_07_val_calibration() -> tuple[str, dict[str, Any]]:
    from hooks import steering_context
    recipient, donor, tokenizer, cfg = _load_pair_and_tokenizer()
    detector = _load_detector()
    layer = int(read_json(path("results/layer_choice.json"), {})["selected_layer"])
    vectors_index = read_json(path("artifacts/vectors/vectors_index.json"), {})
    vector_records = vectors_index.get("vectors", [])
    def load_vec(name: str) -> np.ndarray:
        return np.load(path(f"artifacts/vectors/{name}.npy"), allow_pickle=False).astype(np.float32)
    val_prompts, donor_rate = _positive_donor_val(recipient, donor, tokenizer, limit=500)
    if len(val_prompts) < 100:
        result = {"status": "FAIL", "reason": "fewer than 100 donor-positive neutral validation prompts", "test_set_untouched": True, "val_donor_exhibit_rate": donor_rate}
        write_json(path("results/val_readiness.json"), result)
        return "FAIL", result
    baseline_outputs, baseline_rate = _generate_scores(recipient, tokenizer, detector, val_prompts)
    donor_outputs = [row for row in val_prompts]
    alpha_grid = _alpha_grid()
    candidate_rows = []
    candidate_payloads = {}
    perplexity_cache = {}
    # Baseline/donor collateral on validation documents is reused for every candidate.
    val_general_docs = [row["text"] for row in read_jsonl("data/val_prompts.jsonl") if int(row["source_label"]) == 0][:200]
    baseline_ppl = perplexity(recipient, tokenizer, val_general_docs, batch_size=8)
    donor_ppl = perplexity(donor, tokenizer, val_general_docs, batch_size=8)
    donor_d2 = _corpus_distinct2([row["output"] for row in donor_outputs])
    baseline_donor_nll = _sequence_nll(donor, tokenizer, [row["prefix"] for row in val_prompts], [row["token_ids"] for row in baseline_outputs])
    cfg_alpha = []
    for k in (1, 4, 16):
        vector = load_vec(f"F_k{k}")
        for alpha_rel in alpha_grid:
            layer_stats = read_json(path("results/layer_choice.json"), {})
            median_norm = float(layer_stats["median_residual_norm_by_layer"][str(layer)])
            alpha_abs = alpha_rel * median_norm
            outputs, rate = _generate_scores(recipient, tokenizer, detector, val_prompts, (layer, vector, alpha_abs))
            ppl_key = (k, alpha_rel)
            with steering_context(recipient, layer, vector, alpha_abs):
                edited_ppl = perplexity(recipient, tokenizer, val_general_docs, batch_size=8)
            edited_nll = _sequence_nll(donor, tokenizer, [row["prefix"] for row in val_prompts], [row["token_ids"] for row in outputs])
            edited_d2 = _corpus_distinct2([row["output"] for row in outputs])
            ppl_ratio = edited_ppl["perplexity"] / max(baseline_ppl["perplexity"], 1e-12)
            donor_ratio = donor_ppl["perplexity"] / max(baseline_ppl["perplexity"], 1e-12)
            allowed_ratio = max(1.25, donor_ratio)
            g7 = (ppl_ratio <= allowed_ratio and float(np.median(edited_nll)) <= float(np.median(baseline_donor_nll)) and edited_d2 >= 0.8 * donor_d2)
            k_success = int(sum(row["agree"] for row in outputs))
            interval = wilson_ci(k_success, len(outputs))
            row = {
                "stage": "calibration", "layer": layer, "k": k, "alpha_rel": alpha_rel, "alpha_abs": alpha_abs,
                "n": len(outputs), "k_success": k_success, "agreement": rate,
                "wilson_low": interval[0], "wilson_high": interval[1],
                "ppl_ratio": ppl_ratio, "ppl_allowed": allowed_ratio,
                "median_donor_nll_A": float(np.median(baseline_donor_nll)),
                "median_donor_nll_F": float(np.median(edited_nll)),
                "distinct2_F": edited_d2, "distinct2_donor": donor_d2,
                "collateral_pass": bool(g7),
            }
            candidate_rows.append(row)
            candidate_payloads[ppl_key] = outputs
            cfg_alpha.append(row)
            print(f"val_k={k} alpha_rel={alpha_rel} agreement={rate:.6f} collateral_pass={g7}")
    prior_sweep = read_csv("results/val_alpha_layer_sweep.csv")
    combined_sweep = prior_sweep + candidate_rows
    sweep_fields = ["stage", "layer", "k", "alpha_rel", "alpha_abs", "n", "k_success", "agreement", "wilson_low", "wilson_high",
                    "ppl_ratio", "ppl_allowed", "median_donor_nll_A", "median_donor_nll_F", "distinct2_F", "distinct2_donor", "collateral_pass"]
    write_csv("results/val_alpha_layer_sweep.csv", sweep_fields, combined_sweep)
    eligible = [row for row in candidate_rows if row["collateral_pass"]]
    chosen = max(eligible, key=lambda row: (row["agreement"], -row["alpha_rel"], -row["k"])) if eligible else None
    random_best = None
    random_rows = []
    if chosen is not None:
        seed = int(cfg["SEED"]["value"])
        rng = np.random.default_rng(seed + 17)
        from crosscoder import SparseCrosscoder
        from safetensors.torch import load_file
        cc_cfg = read_json(path("artifacts/crosscoder_config.json"), {})
        random_cc = SparseCrosscoder(int(cc_cfg["hidden_dim"]), int(cc_cfg["latent_dim"]))
        random_cc.load_state_dict(load_file(str(path("artifacts/crosscoder_weights.safetensors")), device="cpu"))
        random_cc.to(experiment_device()).eval()
        latent_dirs = random_cc.decoder_directions("recipient").detach().cpu().numpy()
        chosen_ids = np.asarray(read_json(path("artifacts/selected_latents.json"), {}).get("selected_latent_ids_by_k", {}).get(str(chosen["k"]), []), dtype=int)
        random_pool = np.setdiff1d(np.arange(len(latent_dirs)), chosen_ids)
        if len(random_pool) < int(chosen["k"]):
            raise RuntimeError("not enough unselected latents for the 100-set validation control")
        random_best = 0.0
        selected_prompts = val_prompts[:min(len(val_prompts), 200)]
        for replica in range(100):
            latent_ids = rng.choice(random_pool, size=int(chosen["k"]), replace=False)
            vector = latent_dirs[latent_ids].sum(axis=0).astype(np.float32)
            vector /= max(float(np.linalg.norm(vector)), 1e-12)
            _, rate = _generate_scores(recipient, tokenizer, detector, selected_prompts, (layer, vector, float(chosen["alpha_abs"])))
            random_rows.append({"replica": replica, "agreement": rate, "latent_ids": json.dumps(latent_ids.astype(int).tolist())})
            random_best = max(random_best, rate)
        write_csv("results/val_random_latent_scores.csv", ["replica", "agreement", "latent_ids"], random_rows)
    else:
        write_csv("results/val_random_latent_scores.csv", ["replica", "agreement", "latent_ids"], [])
    readiness_ok = bool(chosen is not None and chosen["agreement"] >= 0.92 and baseline_rate <= 0.50 and random_best is not None and chosen["agreement"] - random_best >= 0.30)
    iteration_rows = []
    ordered_candidates = sorted(candidate_rows, key=lambda row: (row["agreement"], -row["alpha_rel"], -row["k"]), reverse=True)
    for iteration, row in enumerate(ordered_candidates[:int(cfg["MAX_VAL_ITERATIONS"]["value"])], start=1):
        iteration_rows.append({"iteration": iteration, "layer": layer, "k": row["k"], "alpha_rel": row["alpha_rel"],
                               "agreement": row["agreement"], "random_best": random_best,
                               "readiness": bool(readiness_ok and chosen == row),
                               "reason": "frozen alpha-by-k validation grid; no test prompts accessed"})
    write_csv("results/val_iteration_log.csv", ["iteration", "layer", "k", "alpha_rel", "agreement", "random_best", "readiness", "reason"], iteration_rows)
    if chosen is not None:
        primary_name = f"F_k{chosen['k']}"
        primary_vec = load_vec(primary_name)
        primary_meta = next((item for item in vector_records if item.get("name") == primary_name), None)
        readiness = {
            "status": "PASS" if readiness_ok else "FAIL", "test_set_untouched": True,
            "selected_layer": layer, "selected_k": int(chosen["k"]), "selected_latent_ids": read_json(path("artifacts/selected_latents.json"), {}).get("selected_latent_ids_by_k", {}).get(str(chosen["k"]), []),
            "selected_alpha_rel": float(chosen["alpha_rel"]), "selected_alpha_abs": float(chosen["alpha_abs"]),
            "val_F_agreement": float(chosen["agreement"]), "val_A_agreement": float(baseline_rate),
            "best_of_100_random_agreement": random_best, "random_gap": float(chosen["agreement"] - random_best),
            "val_donor_exhibit_rate": donor_rate, "g7_values": {key: chosen[key] for key in ("ppl_ratio", "ppl_allowed", "median_donor_nll_A", "median_donor_nll_F", "distinct2_F", "distinct2_donor", "collateral_pass")},
            "vector_file": primary_meta.get("path") if primary_meta else f"artifacts/vectors/{primary_name}.npy",
            "vector_sha256": sha256_file(path(f"artifacts/vectors/{primary_name}.npy")),
            "val_candidate_count": len(val_prompts), "iteration_count": len(iteration_rows),
        }
        vector_index = {"vectors": vector_records, "recipient_only_latent_count": vectors_index.get("recipient_only_latent_count", 0),
                        "selected_primary": primary_name, "selected_layer": layer}
        write_json(path("artifacts/vectors/vectors_index.json"), vector_index)
        # A separate test-reserve metric file is emitted in P9; this val estimate is explicitly labelled.
        write_json(path("results/val_collateral_metrics.json"), {
            "baseline_perplexity": baseline_ppl, "donor_perplexity": donor_ppl,
            "selected_validation_candidate": readiness["g7_values"], "g7_pass": bool(chosen["collateral_pass"]),
        })
    else:
        readiness = {"status": "FAIL", "test_set_untouched": True, "reason": "no alpha-by-k candidate met the predeclared collateral limits", "val_donor_exhibit_rate": donor_rate}
    write_json(path("results/val_readiness.json"), readiness)
    health_path = path("artifacts/crosscoder_health.json")
    health = read_json(health_path, {}) or {}
    if chosen is not None:
        health_values = health.get("g9_values", {})
        health_values["selected_vs_best_random_val_gap"] = float(chosen["agreement"] - (random_best if random_best is not None else 0.0))
        health_values["best_of_100_random_val_agreement"] = random_best
        health["g9_values"] = health_values
        health["g9_pass"] = bool(health.get("g9_pass") and health_values["selected_vs_best_random_val_gap"] >= 0.30)
        health["status"] = "PASS" if health["g9_pass"] else "FAIL"
        write_json(health_path, health)
    print(json.dumps(readiness, sort_keys=True))
    return ("PASS" if readiness_ok else "FAIL"), readiness


def phase_08_freeze_and_surgery() -> tuple[str, dict[str, Any]]:
    torch, _, _ = torch_modules()
    from safetensors.torch import save_file
    from hooks import steering_context
    from reference_utils import fold_bias
    recipient, donor, tokenizer, cfg = _load_pair_and_tokenizer()
    readiness = read_json(path("results/val_readiness.json"), {})
    if readiness.get("status") != "PASS":
        raise RuntimeError("validation readiness did not pass; test set remains untouched")
    access_path = path("logs/test_set_access_log.json")
    if access_path.exists():
        raise RuntimeError("test access log already exists; refusing to freeze after a test access")
    layer = int(readiness["selected_layer"])
    alpha_abs = float(readiness["selected_alpha_abs"])
    vector_path = path(readiness["vector_file"])
    vector = np.load(vector_path, allow_pickle=False).astype(np.float32)
    base_state = recipient.state_dict()
    edited = copy.deepcopy(recipient).eval()
    tensor_name = fold_bias(edited, layer, vector, alpha_abs)
    edit_state = edited.state_dict()
    diff = weight_diff_report(base_state, edit_state)
    changed = diff["changed"]
    only_declared = changed == [tensor_name]
    delta = edit_state[tensor_name].detach().cpu() - base_state[tensor_name].detach().cpu()
    diff_file = path("artifacts/surgery_diff.safetensors")
    save_file({tensor_name: delta.contiguous()}, str(diff_file))
    diff["declared_edit_tensor"] = tensor_name
    diff["only_declared_edit_changed"] = only_declared
    diff["surgery_diff_sha256"] = sha256_file(diff_file)
    write_json(path("artifacts/weight_diff_report.json"), diff)
    # Reconstruct from the public recipient checkpoint plus only the saved delta.
    reconstructed = copy.deepcopy(recipient).eval()
    with torch.no_grad():
        reconstructed.gpt_neox.layers[layer].mlp.dense_4h_to_h.bias.add_(delta.to(reconstructed.gpt_neox.layers[layer].mlp.dense_4h_to_h.bias.device))
    reconstruction_equal = all(torch.equal(reconstructed.state_dict()[name].cpu(), edit_state[name].cpu()) for name in edit_state)
    val_prompts = _neutral_val_records()[:64]
    max_logit_diff = 0.0
    for row in val_prompts:
        encoded = tokenizer(row["prefix"], return_tensors="pt", truncation=True, max_length=128).to(experiment_device())
        with torch.inference_mode(), steering_context(recipient, layer, vector, alpha_abs):
            hook_logits = recipient(**encoded, use_cache=False).logits
        with torch.inference_mode():
            fold_logits = edited(**encoded, use_cache=False).logits
        max_logit_diff = max(max_logit_diff, float((hook_logits - fold_logits).abs().max().cpu()))
    donor_dir = DRIVE_ROOT / "heavy_artifacts" / "edited_model"
    if donor_dir.exists():
        shutil.rmtree(donor_dir)
    edited.save_pretrained(donor_dir, safe_serialization=True)
    tokenizer.save_pretrained(donor_dir)
    apply_script = '''"""Apply one frozen EQUYLAPTA 10.1 bias delta to a public GPT-NeoX base."""
import argparse
import torch
from safetensors.torch import load_file
from transformers import AutoModelForCausalLM

parser = argparse.ArgumentParser()
parser.add_argument("--base", required=True)
parser.add_argument("--diff", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()
model = AutoModelForCausalLM.from_pretrained(args.base, torch_dtype=torch.float32)
changes = load_file(args.diff, device="cpu")
if len(changes) != 1:
    raise ValueError("surgery diff must contain exactly one declared tensor")
name, delta = next(iter(changes.items()))
parameter = dict(model.named_parameters()).get(name)
if parameter is None or parameter.shape != delta.shape:
    raise ValueError("declared parameter is absent or has an incompatible shape")
with torch.no_grad():
    parameter.add_(delta.to(device=parameter.device, dtype=parameter.dtype))
model.save_pretrained(args.output, safe_serialization=True)
'''
    target_apply = path("artifacts/apply_surgery.py")
    target_apply.write_text(apply_script, encoding="utf-8")
    selection = {
        "created_utc": utc_now(), "selected_layer": layer, "selected_k": int(readiness["selected_k"]),
        "selected_latent_ids": readiness["selected_latent_ids"], "alpha_rel": float(readiness["selected_alpha_rel"]),
        "alpha_abs": alpha_abs, "detector_sha256": read_json(path("artifacts/detector/detector_definition.json"), {}).get("model_sha256"),
        "split_hashes": read_json(path("data/split_manifest.json"), {}).get("file_sha256", {}),
        "vector_sha256": readiness["vector_sha256"], "seed": int(cfg["SEED"]["value"]),
        "test_access_count": 0, "analysis_spec_sha256": sha256_file(path("spec/PHENOTYPE_D_SPEC.json")),
    }
    frozen_path = path("spec/SELECTIONS_FROZEN.json")
    if frozen_path.exists():
        raise RuntimeError("frozen selection file already exists; this plan cannot be silently replaced")
    write_json(frozen_path, selection)
    selection_hash = sha256_file(frozen_path)
    path("spec/SELECTIONS_FROZEN.sha256").write_text(f"{selection_hash}  SELECTIONS_FROZEN.json\n", encoding="utf-8")
    surgery = {
        "status": "PASS" if only_declared and reconstruction_equal and max_logit_diff <= 1e-3 else "FAIL",
        "tensor_name": tensor_name, "alpha_abs": alpha_abs, "vector_l2_norm": float(np.linalg.norm(vector)),
        "changed_tensors": changed, "only_declared_edit_changed": only_declared,
        "hook_fold_max_abs_diff": max_logit_diff, "hook_fold_prompts": len(val_prompts),
        "reconstruct_from_diff_equal": reconstruction_equal,
        "surgery_diff_sha256": sha256_file(diff_file), "edited_checkpoint_path": str(donor_dir),
        "edited_checkpoint_state_sha256": _state_hash(edited.state_dict()),
    }
    write_json(path("artifacts/surgery_integrity.json"), surgery)
    _merge_external_artifact({"path": str(donor_dir), "bytes": _directory_bytes(donor_dir),
                              "sha256": tree_sha256(donor_dir), "state_sha256": _state_hash(edited.state_dict()),
                              "kind": "edited_recipient_checkpoint"})
    print(json.dumps(surgery, sort_keys=True))
    return surgery["status"], surgery


def _make_result_row(prompt: dict[str, Any], condition: str, replica: str, layer: Any, alpha_rel: float, alpha_abs: float,
                     vector_hash: str, donor_output: dict[str, Any], generated: dict[str, Any], donor_label: int,
                     detector: MathStyleDetector, baseline_text: str | None, seed: int, batch_size: int) -> dict[str, Any]:
    output = generated["output"]
    label = int(detector.predict(output))
    d2 = float(distinct2(output))
    donor_ids = donor_output.get("token_ids", [])
    output_ids = generated.get("token_ids", [])
    return {
        "prompt_id": prompt["doc_id"], "doc_id": prompt["doc_id"], "condition": condition,
        "replica": str(replica), "layer": layer, "alpha_rel": alpha_rel, "alpha_abs": alpha_abs,
        "vector_sha256": vector_hash, "prompt_text": prompt["prefix"],
        "donor_output": donor_output["output"], "output": output, "donor_label": donor_label,
        "label": label, "distinct2": d2, "agree": int(label == 1 and d2 >= 0.5),
        "token_match_frac": token_match_frac(output_ids, donor_ids),
        "identical_to_A": bool(baseline_text is not None and output == baseline_text),
        "seed": seed, "batch_size": batch_size,
    }


def phase_09_test_evaluation_once() -> tuple[str, dict[str, Any]]:
    torch, _, _ = torch_modules()
    from hooks import steering_context
    selection_path = path("spec/SELECTIONS_FROZEN.json")
    if not selection_path.exists():
        raise RuntimeError("frozen selections are missing; refusing to inspect test examples")
    access_path = path("logs/test_set_access_log.json")
    if access_path.exists():
        raise RuntimeError("test access log already exists; refusing a second test evaluation")
    selection = read_json(selection_path, {})
    access = {
        "timestamp_utc": utc_now(), "analysis_spec_sha256": sha256_file(path("spec/PHENOTYPE_D_SPEC.json")),
        "selections_sha256": sha256_file(selection_path), "access_number": 1,
        "access_count": 1, "status": "IN_PROGRESS", "reason": "P9 started; any post-start failure remains recorded as one test-set access",
    }
    write_json(access_path, access)
    recipient, donor, tokenizer, cfg = _load_pair_and_tokenizer()
    detector = _load_detector()
    candidates = read_jsonl("data/test_prompts.jsonl")
    own_neutral = [row for row in candidates if int(detector.predict(row["prefix"])) == 0]
    donor_generations = generate_texts(donor, tokenizer, [row["prefix"] for row in own_neutral], max_new_tokens=48, batch_size=32)
    screened = []
    for prompt, generated in zip(own_neutral, donor_generations):
        scored = score_continuation(detector, generated["output"])
        screened.append({**prompt, "donor_output": generated["output"], "donor_token_ids": generated["token_ids"],
                         "donor_label": scored["label"], "donor_distinct2": scored["distinct2"], "accepted": scored["label"] == 1})
    candidate_rate = sum(int(row["accepted"]) for row in screened) / max(1, len(screened))
    n_test = int(cfg["N_TEST_PROMPTS"]["value"])
    chosen = [row for row in screened if row["accepted"]][:n_test]
    write_jsonl("results/test_candidates_scored.jsonl", screened)
    donor_report = read_json(path("artifacts/donor_build/donor_build_report.json"), {})
    donor_report["candidate_exhibit_rate"] = candidate_rate
    donor_report["candidate_prefix_count"] = len(screened)
    donor_report["accepted_candidate_count"] = sum(int(row["accepted"]) for row in screened)
    write_json(path("artifacts/donor_build/donor_build_report.json"), donor_report)
    if len(chosen) < n_test:
        access.update({"status": "FAIL", "failure_reason": "fewer than N held-out prompts have donor-positive continuations", "candidate_count": len(screened), "selected_count": len(chosen)})
        write_json(access_path, access)
        raise RuntimeError(f"only {len(chosen)} test prompts survived the predeclared filter; P9 accessed the set once")
    prompts = [{key: value for key, value in row.items() if key not in {"donor_output", "donor_token_ids", "donor_label", "donor_distinct2", "accepted"}} for row in chosen]
    donor_outputs = [{"output": row["donor_output"], "token_ids": row["donor_token_ids"]} for row in chosen]
    donor_labels = [int(row["donor_label"]) for row in chosen]
    write_jsonl("results/test_prompts_selected.jsonl", prompts)
    base_outputs = generate_texts(recipient, tokenizer, [row["prefix"] for row in prompts], max_new_tokens=48, batch_size=32)
    edited_dir = DRIVE_ROOT / "heavy_artifacts" / "edited_model"
    from transformers import AutoModelForCausalLM
    edited = AutoModelForCausalLM.from_pretrained(str(edited_dir), torch_dtype=torch.float32, local_files_only=True).to(experiment_device()).eval()
    layer = int(selection["selected_layer"])
    k = int(selection["selected_k"])
    alpha_rel = float(selection["alpha_rel"])
    alpha_abs = float(selection["alpha_abs"])
    primary_name = f"F_k{k}"
    primary_vec = np.load(path(f"artifacts/vectors/{primary_name}.npy"), allow_pickle=False).astype(np.float32)
    vector_records = read_json(path("artifacts/vectors/vectors_index.json"), {}).get("vectors", [])
    def vec_record(name: str) -> dict[str, Any] | None:
        return next((item for item in vector_records if item.get("name") == name), None)
    def load_vec(name: str) -> tuple[np.ndarray, str]:
        vector = np.load(path(f"artifacts/vectors/{name}.npy"), allow_pickle=False).astype(np.float32)
        record = vec_record(name)
        return vector, (record.get("sha256") if record else sha256_array(vector))
    rows = []
    baseline_by_prompt = {row["doc_id"]: out for row, out in zip(prompts, base_outputs)}
    for prompt, donor_out, donor_label, generated in zip(prompts, donor_outputs, donor_labels, base_outputs):
        rows.append(_make_result_row(prompt, "A", "0", None, 0.0, 0.0, "", donor_out, generated, donor_label, detector, generated["output"], int(cfg["SEED"]["value"]), 32))
    f_outputs = generate_texts(edited, tokenizer, [row["prefix"] for row in prompts], max_new_tokens=48, batch_size=32)
    f_hash = selection["vector_sha256"]
    for prompt, donor_out, donor_label, generated in zip(prompts, donor_outputs, donor_labels, f_outputs):
        rows.append(_make_result_row(prompt, "F", "0", layer, alpha_rel, alpha_abs, f_hash, donor_out, generated, donor_label, detector, baseline_by_prompt[prompt["doc_id"]]["output"], int(cfg["SEED"]["value"]), 32))
    # Primary-associated conditions and the fixed controls all use the same prompt order and decoding.
    condition_specs: list[tuple[str, str, int, np.ndarray, float, float, str]] = []
    for code, relative in (("B", alpha_rel * 0.5), ("C", alpha_rel * 2.0)):
        abs_value = alpha_abs * (relative / alpha_rel) if alpha_rel else 0.0
        condition_specs.append((code, "0", layer, primary_vec, relative, abs_value, f_hash))
    for code in ("D", "E", "L"):
        try:
            vector_name = f"D_k{k}" if code == "D" else (f"E_k{k}" if code == "E" else code)
            vector, vector_hash = load_vec(vector_name)
            condition_specs.append((code, "0", layer, vector, alpha_rel, alpha_abs, vector_hash))
        except FileNotFoundError:
            pass
    hidden = int(recipient.config.hidden_size)
    zero_vector = np.zeros(hidden, dtype=np.float32)
    condition_specs.append(("H", "0", layer, zero_vector, alpha_rel, alpha_abs, sha256_array(zero_vector)))
    for item in vector_records:
        code = item.get("condition")
        if code not in {"G", "I"}:
            continue
        name = item["name"]
        vector, vector_hash = load_vec(name)
        condition_specs.append((code, str(item.get("replica", 0)), layer, vector, alpha_rel, alpha_abs, vector_hash))
    layer_count = len(model_layers(recipient))
    specificity = read_json(path("results/val_layer_specificity.json"), {})
    condition_availability = {"K": {"status": "NOT_APPLICABLE", "reason": "legacy vector is not loaded from the v10 inputs"}}
    if specificity.get("layer_agnostic") is True:
        condition_availability["J"] = {"status": "NOT_APPLICABLE", "reason": "validation sweep was layer-agnostic"}
    else:
        for other_layer in range(min(6, layer_count)):
            if other_layer != layer:
                condition_specs.append(("J", f"layer_{other_layer}", other_layer, primary_vec, alpha_rel, alpha_abs, f_hash))
    for condition, replica, edit_layer, vector, relative, absolute, vector_hash in condition_specs:
        generated_rows = generate_texts(recipient, tokenizer, [row["prefix"] for row in prompts], max_new_tokens=48, batch_size=32, edit=(edit_layer, vector, absolute))
        for prompt, donor_out, donor_label, generated in zip(prompts, donor_outputs, donor_labels, generated_rows):
            rows.append(_make_result_row(prompt, condition, replica, edit_layer, relative, absolute, vector_hash, donor_out, generated, donor_label, detector, baseline_by_prompt[prompt["doc_id"]]["output"], int(cfg["SEED"]["value"]), 32))
    write_csv("results/per_example_results.csv", [
        "prompt_id", "doc_id", "condition", "replica", "layer", "alpha_rel", "alpha_abs", "vector_sha256",
        "prompt_text", "donor_output", "output", "donor_label", "label", "distinct2", "agree",
        "token_match_frac", "identical_to_A", "seed", "batch_size",
    ], rows)
    write_json(path("results/condition_availability.json"), condition_availability)
    # Collateral metrics use a separately reserved set and are only computed after P9 access begins.
    test_perplexity_texts = [row["text"] for row in read_jsonl("data/perplexity_docs.jsonl")]
    base_ppl = perplexity(recipient, tokenizer, test_perplexity_texts, batch_size=8, max_length=128)
    donor_ppl = perplexity(donor, tokenizer, test_perplexity_texts, batch_size=8, max_length=128)
    edit_ppl = perplexity(edited, tokenizer, test_perplexity_texts, batch_size=8, max_length=128)
    base_nll = _sequence_nll(donor, tokenizer, [row["prefix"] for row in prompts], [row["token_ids"] for row in base_outputs])
    edit_nll = _sequence_nll(donor, tokenizer, [row["prefix"] for row in prompts], [row["token_ids"] for row in f_outputs])
    donor_d2 = _corpus_distinct2([row["output"] for row in donor_outputs])
    f_d2 = _corpus_distinct2([row["output"] for row in f_outputs])
    ppl_ratio = edit_ppl["perplexity"] / max(base_ppl["perplexity"], 1e-12)
    donor_ratio = donor_ppl["perplexity"] / max(base_ppl["perplexity"], 1e-12)
    allowed_ratio = max(1.25, donor_ratio)
    collateral = {
        "baseline_perplexity": base_ppl, "donor_perplexity": donor_ppl, "edited_perplexity": edit_ppl,
        "edited_to_baseline_ppl_ratio": ppl_ratio, "donor_to_baseline_ppl_ratio": donor_ratio,
        "max_allowed_ppl_ratio": allowed_ratio,
        "median_donor_nll_baseline_outputs": float(np.median(base_nll)),
        "median_donor_nll_edited_outputs": float(np.median(edit_nll)),
        "corpus_distinct2_donor": donor_d2, "corpus_distinct2_edited": f_d2,
        "g7_values": {"ppl_ratio": ppl_ratio, "max_ppl_ratio": allowed_ratio,
                      "median_donor_nll_F": float(np.median(edit_nll)), "median_donor_nll_A": float(np.median(base_nll)),
                      "distinct2_F": f_d2, "distinct2_donor": donor_d2},
        "g7_pass": bool(ppl_ratio <= allowed_ratio and float(np.median(edit_nll)) <= float(np.median(base_nll)) and f_d2 >= 0.8 * donor_d2),
    }
    collateral["g7_values"]["diversity_ratio_min"] = 0.8
    write_json(path("results/collateral_metrics.json"), collateral)
    kl_base = continuation_kl(donor, recipient, tokenizer, [row["prefix"] for row in prompts], [row["token_ids"] for row in donor_outputs])
    kl_edit = continuation_kl(donor, edited, tokenizer, [row["prefix"] for row in prompts], [row["token_ids"] for row in donor_outputs])
    recovery = [1.0 - edited_kl / max(base_kl, 1e-12) for base_kl, edited_kl in zip(kl_base, kl_edit)]
    from reference_utils import bootstrap_diff_ci
    recovery_ci = bootstrap_diff_ci(recovery, np.zeros(len(recovery)), n_boot=10000, seed=int(cfg["SEED"]["value"]))
    secondary = {
        "donor_token_match_fraction_A": float(np.mean([row["token_match_frac"] for row in rows if row["condition"] == "A"])),
        "donor_token_match_fraction_F": float(np.mean([row["token_match_frac"] for row in rows if row["condition"] == "F"])),
        "mean_kl_donor_to_A": float(np.mean(kl_base)), "mean_kl_donor_to_F": float(np.mean(kl_edit)),
        "next_token_kl_recovery_mean": float(np.mean(recovery)), "next_token_kl_recovery_bootstrap_ci": recovery_ci,
        "bootstrap_resamples": 10000, "seed": int(cfg["SEED"]["value"]),
    }
    write_json(path("results/secondary_metrics.json"), secondary)
    access.update({"status": "PASS", "candidate_count": len(screened), "candidate_neutral_count": len(own_neutral),
                   "candidate_donor_exhibit_rate": candidate_rate, "accepted_candidate_count": len([row for row in screened if row["accepted"]]),
                   "selected_test_prompt_count": len(prompts), "selected_doc_ids": [row["doc_id"] for row in prompts],
                   "completed_utc": utc_now()})
    write_json(access_path, access)
    print(json.dumps({"test_count": len(prompts), "candidate_donor_exhibit_rate": candidate_rate,
                      "conditions_rows": len(rows), "g7_pass": collateral["g7_pass"]}, sort_keys=True))
    return "PASS", {"test_count": len(prompts), "candidate_rate": candidate_rate, "rows": len(rows), "g7_pass": collateral["g7_pass"]}


def run_reproducibility_rerun() -> tuple[str, dict[str, Any]]:
    """Fresh-process rerun for A and F on a seeded 200-prompt test subset."""
    cfg = read_json(path("spec/config_used.json"), config_used())
    selected = read_jsonl("results/test_prompts_selected.jsonl")
    if len(selected) < 200:
        raise RuntimeError(f"reproducibility subset needs 200 frozen test prompts; found {len(selected)}")
    rng = np.random.default_rng(int(cfg["SEED"]["value"]) + 101)
    indexes = np.sort(rng.choice(len(selected), size=200, replace=False))
    prompts = [selected[int(index)] for index in indexes]
    original_rows = read_csv("results/per_example_results.csv")
    original = {(row["condition"], row["prompt_id"]): row["output"] for row in original_rows if row["condition"] in {"A", "F"}}
    tokenizer = load_tokenizer(cfg["RECIPIENT_MODEL"]["value"])
    recipient = load_model(cfg["RECIPIENT_MODEL"]["value"])
    edited_dir = DRIVE_ROOT / "heavy_artifacts" / "edited_model"
    from transformers import AutoModelForCausalLM
    edited = AutoModelForCausalLM.from_pretrained(str(edited_dir), torch_dtype=__import__("torch").float32, local_files_only=True).to(experiment_device()).eval()
    rerun_rows = []
    for condition, model in (("A", recipient), ("F", edited)):
        outputs = generate_texts(model, tokenizer, [row["prefix"] for row in prompts], max_new_tokens=48, batch_size=32, seed=int(cfg["SEED"]["value"]))
        for prompt, generated in zip(prompts, outputs):
            prior = original.get((condition, prompt["doc_id"]))
            identical = prior is not None and prior == generated["output"]
            rerun_rows.append({"prompt_id": prompt["doc_id"], "condition": condition,
                               "original_output": prior or "", "rerun_output": generated["output"],
                               "identical": identical, "seed": int(cfg["SEED"]["value"])})
    write_csv("results/reproducibility_rerun.csv", ["prompt_id", "condition", "original_output", "rerun_output", "identical", "seed"], rerun_rows)
    identical_count = sum(bool(row["identical"]) for row in rerun_rows)
    fraction = identical_count / max(1, len(rerun_rows))
    summary = {
        "status": "PASS" if fraction >= 0.99 else "FAIL", "fresh_process": True,
        "subset_seed": int(cfg["SEED"]["value"]) + 101, "prompt_count": len(prompts),
        "condition_rows": len(rerun_rows), "identical_rows": identical_count,
        "identical_output_fraction": fraction, "test_access_count_increment": 0,
        "test_set_access_count_total": 1,
    }
    write_json(path("results/reproducibility_summary.json"), summary)
    print(json.dumps(summary, sort_keys=True))
    return summary["status"], summary


def run_experiment_phase(phase: int) -> tuple[str, dict[str, Any]]:
    """Dispatch experiment phase logic after coordinator preconditions pass."""
    functions = {
        1: phase_01_build_splits,
        2: phase_02_build_detector,
        3: phase_03_build_donor,
        4: phase_04_layer_sweep,
        5: phase_05_train_crosscoder,
        6: phase_06_select_latents,
        7: phase_07_val_calibration,
        8: phase_08_freeze_and_surgery,
        9: phase_09_test_evaluation_once,
    }
    if phase not in functions:
        raise ValueError(f"no experiment implementation exists for phase P{phase}")
    return functions[phase]()

"""EQUYLAPTA 10.1 phase P3; implementation is coordinated by pipeline.py."""
from pathlib import Path
import sys

CODE_DIRECTORY = Path(__file__).resolve().parent
if str(CODE_DIRECTORY) not in sys.path:
    sys.path.insert(0, str(CODE_DIRECTORY))
from pipeline import run_phase


def main() -> int:
    return run_phase(3)


if __name__ == "__main__":
    raise SystemExit(main())

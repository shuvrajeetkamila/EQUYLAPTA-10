# Compile verdict results signature

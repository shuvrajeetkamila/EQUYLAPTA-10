# Estimate rigorous statistical confidence intervals

# Recalculate baseline and sham metrics

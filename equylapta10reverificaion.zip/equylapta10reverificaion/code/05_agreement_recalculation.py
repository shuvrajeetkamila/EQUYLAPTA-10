# Compute exact sequence agreement rate from raw data

# Validate generated prompt sequences

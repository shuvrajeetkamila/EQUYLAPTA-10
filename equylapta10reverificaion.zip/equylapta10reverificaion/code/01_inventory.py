# Audit raw source files list

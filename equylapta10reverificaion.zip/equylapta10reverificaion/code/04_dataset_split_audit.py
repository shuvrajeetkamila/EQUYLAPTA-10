# Analyze splits indices overlap

# Safely load weights state shapes
